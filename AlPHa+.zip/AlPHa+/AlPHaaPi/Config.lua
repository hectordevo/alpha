
do local _ = {
  BotName = "Nulli Plus", ---نام ربات
  Bot_id = 923815659,--- ایدی سودو
  Bot_idapi = 985273212,----idcli
  Alpha = "10", ----NumberDataBase
  SUDO = 923815659,--- ایدی سودو
  UsernameApi = "NulliPlusBot",-----userpanelapi
  UsernameCli = "NulliPlus", --usercli
 admins = {
    {
      923815659,
      "@NulliPlus"
    }
  },
  bot_token = "985273212:AAEef2oIAFt6YAd3hSxFbvJhhTZ4E8OuCc4", ---Token
  channel_inline = "NullHack",---linkchannel
  channel_username = "NullHack",---linkchannel
  gp_sudo = 923815659,--- ایدی سودو
  link_poshtibani = "https://t.me/joinchat/NxBO6xYr3S_489HBjm5NVA", --linksupport
  linkpardakht = "https://idpay.ir/PouriaZec", ---idpay
  sudo_username = "@isPython",--یوزرنیم سودو
  sudo_users = {
    923815659,923815659,765751442   -----[idsuod-idapi-idcli]
  }, 
  sudoinline_username = "isPython",--یوزرنیم سودو
  userpasswd = "1313" 
  
}
return _  
end