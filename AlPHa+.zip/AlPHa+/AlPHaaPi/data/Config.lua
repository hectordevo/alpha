do local _ = {
  Alpha = "10",
  BotName = "Roobot",
  Bot_id = 746633345,
  Bot_idapi = 746633970,
  SUDO = 664556468,
  UsernameApi = "Toomplus999bot",
  UsernameCli = "Toomplus",
  admins = {
    {
      664556468,
      "@toomplusss"
    }
  },
  bot_token = "746633970:AAEv_aVA2rTExngSIBbk3QDi3U3YDp2ITPk",
  channel_inline = "Toompluscch",
  channel_username = "Toompluscch",
  gp_sudo = 664556468,
  link_poshtibani = "https://t.me/joinchat/I8LCDQ4muBxMGTf6GrFtsQ",
  linkpardakht = "https://t.me/Toompluscch",
  sudo_username = "@toomplusss",
  sudo_users = {
    746633970,
    746633970
  },
  sudoinline_username = "toomplusss",
  userpasswd = "13"
}
return _
end