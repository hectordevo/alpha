--#    ___     __             __            ______    ____     ____           __ 
--#   /   |   / /    ____    / /_   ____ _ /_  __/   / __ \   / __ )  ____   / /_
--#  / /| |  / /    / __ \  / __ \ / __ `/  / /     / / / /  / __  | / __ \ / __/
--# / ___ | / /    / /_/ / / / / // /_/ /  / /     / /_/ /  / /_/ / / /_/ // /_  
--#/_/  |_|/_/    / .___/ /_/ /_/ \__,_/  /_/     /_____/  /_____/  \____/ \__/  
--#              /_/                                                             




package.path = package.path .. ';.luarocks/share/lua/5.2/?.lua'.. ';.luarocks/share/lua/5.2/?/init.lua'
package.cpath = package.cpath .. ';.luarocks/lib/lua/5.2/?.so'
tdbot = dofile('./libs/tdbot.lua')
serpent = (loadfile "./libs/serpent.lua")()
feedparser = (loadfile "./libs/feedparser.lua")()
Config = (loadfile "./Config.lua")()
require('./libs/lua-redis')
URL = require "socket.url"
http = require "socket.http"
https = require "ssl.https"
ltn12 = require "ltn12"

= str:gsub('*','\\*')
		elseif str:match('`') then
			output = str:gsub('`','\\`')
		else
			output = str
		end
		return output
	end
end
function is_leader(msg)
	local var = false
	if is_leader1(tonumber(664556468)) then var = true end
	return var
end
function is_sudo(msg)
	local var = false
	if is_sudo1(tonumber(msg.sender_user_id)) then var = true end
	return var
end
function is_admin(msg)
	local var = false
	if is_admin1(tonumber(msg.sender_user_id)) then var = true end
	return var
end
function is_owner(msg)
	local var = false
	if is_owner1(tostring(msg.chat_id),tonumber(msg.sender_user_id)) then var = true end
	return var
end
function is_mod(msg)
	local var = false
	if is_mod1(tostring(msg.chat_id),tonumber(msg.sender_user_id)) then var = true end
	return var
end
function is_whitelist(chat_id, user_id)
	local var = false
	if is_mod1(chat_id, user_id) then var = true end
	if redis:sismember(Alpha.."Whitelist:"..chat_id,user_id) then var = true end
	return var
end

function is_whitelist1(msg)  
  local hash = redis:sismember(Alpha.."Whitelist:"..msg.chat_id,msg.sender_user_id)
if hash or is_sudo(msg) or is_owner(msg) or is_mod(msg)  then
return true
else
return false
end
end


function is_leader1(user_id)
	local var = false
	if user_id == tonumber(664556468) then
		var = true
	end
	return var
end
function is_sudo1(user_id)
	local var = false
	for v,user in pairs(Config.sudo_users) do
		if user == user_id then
			var = true
		end
	end
	if user_id == tonumber(664556468) then
		var = true
	end
	return var
end
function is_admin1(user_id)
	local var = false
	local user = user_id
	for v,user in pairs(Config.admins) do
		if user[1] == user_id then
			var = true
		end
	end
	for v,user in pairs(Config.sudo_users) do
		if user == user_id then
			var = true
		end
	end
	if user_id == tonumber(664556468) then
		var = true
	end
	return var
end
function is_owner1(chat_id, user_id)
	local var = false
	if is_admin1(user_id) then var = true end
	if redis:sismember(Alpha.."Owners:"..chat_id,user_id) then var = true end
	if user_id == tonumber(664556468) then
		var = true
	end
	return var
end
function is_mod1(chat_id, user_id)
	local var = false
	if is_owner1(chat_id, user_id) then var = true end
	if redis:sismember(Alpha.."Mods:"..chat_id,user_id) then var = true end
	if user_id == tonumber(664556468) then
		var = true
	end
	return var
end
function warns_user_not_allowed(plugin, msg)
	if not user_allowed(plugin, msg) then
		return true
	else
		return false
	end
end
function user_allowed(plugin, msg)
	if plugin.privileged and not is_sudo(msg) then
		return false
	end
	return true
end
function is_banned(chat_id, user_id)
	local var = false
	if redis:sismember(Alpha.."Banned:"..chat_id,user_id) then var = true end
	return var
end
function is_silent_user(userid, chatid, msg, func)
	function check_silent(arg, data)
		local var = false
		if data.members then
			for k,v in pairs(data.members) do
			if(v.user_id == userid)then var = true end
		end
	end
	if func then
		func(msg, var)
	end
end
tdbot.getChannelMembers(chatid, 0, 100000, 'Restricted', check_silent)
end
function is_gbanned(user_id)
	local var = false
	if redis:sismember(Alpha.."GBanned",user_id) then var = true end
	return var
end
function is_filter(msg, text)
	local var = false
	local filter = redis:hkeys(Alpha..'filterlist:'..msg.to.id)
	if filter then
		for i = 1, #filter do
			if string.match(text, filter[i]) then
				var = true
			end
		end
	end
	return var
end
local function getInputFile(file, conversion_str, expectedsize)
  local input = tostring(file)
  local infile = {}

  if (conversion_str and expectedsize) then
    infile = {
      _ = 'inputFileGenerated',
      original_path = tostring(file),
      conversion = tostring(conversion_str),
      expected_size = expectedsize
    }
  else
    if input:match('/') then
      infile = {_ = 'inputFileLocal', path = file}
    elseif input:match('^%d+$') then
      infile = {_ = 'inputFileId', id = file}
    else
      infile = {_ = 'inputFilePersistentId', persistent_id = file}
    end
  end

  return infile
end
local function sendPhoto(chat_id, reply_to_message_id, disable_notification, from_background, reply_markup, photo, caption)
 assert (tdbot_function ({
    _= "sendMessage",
    chat_id = chat_id,
    reply_to_message_id = reply_to_message_id,
    disable_notification = disable_notification,
    from_background = from_background,
    reply_markup = reply_markup,
    input_message_content = {
     _ = "inputMessagePhoto",
      photo = getInputFile(photo),
      added_sticker_file_ids = {},
      width = 0,
      height = 0,
      caption = caption
    },
  }, dl_cb, nil))
end
function kick_user(user_id, chat_id)
	if not tonumber(user_id) then
		return false
	end
	tdbot.changeChatMemberStatus(chat_id, user_id, 'Banned', {0}, dl_cb, nil)
end
function del_msg(chat_id, message_ids)
	local msgid = {[0] = message_ids}
	tdbot.deleteMessages(chat_id, msgid, true, dl_cb, nil)
end
function channel_unblock(chat_id, user_id)
	tdbot.changeChatMemberStatus(chat_id, user_id, 'Left', dl_cb, nil)
end
function channel_set_admin(chat_id, user_id)
	tdbot.changeChatMemberStatus(chat_id, user_id, 'Administrators', {1, 1, 1, 1, 1, 1, 1, 1, 0}, dl_cb, nil)
end
function channel_demote(chat_id, user_id)
	tdbot.changeChatMemberStatus(chat_id, user_id, 'Restriced', {1, 0, 1, 1, 1, 1}, dl_cb, nil)
end
function silent_user(chat_id, user_id)
	tdbot.changeChatMemberStatus(chat_id, user_id, 'Restricted', {1, 0, 0, 0, 0, 0}, dl_cb, nil)
end
function unsilent_user(chat_id, user_id)
	tdbot.changeChatMemberStatus(chat_id, user_id, 'Restricted', {1, 0, 1, 1, 1, 1}, dl_cb, nil)
end
function file_dl(file_id)
	tdbot.downloadFile(file_id, 32, dl_cb, nil)
end
function ReplySet(msg ,Cmd)
	if msg.reply_id then
		tdbot_function ({
		_ = "getMessage",
		chat_id = msg.to.id,
		message_id = msg.reply_id
		}, action_by_reply, {chat_id=msg.to.id,cmd=Cmd})
	end
end
function UseridSet(msg, Matches ,Cmd)
	if Matches and string.match(Matches, '^%d+$') then
		tdbot_function ({
		_ = "getUser",
		user_id = Matches,
		}, action_by_id, {chat_id=msg.to.id,user_id=Matches,cmd=Cmd})
	end
	if Matches and not string.match(Matches, '^%d+$') then
		tdbot_function ({
		_ = "searchPublicChat",
		username = Matches
		}, action_by_username, {chat_id=msg.to.id,username=Matches,cmd=Cmd})
	end
end
function action_by_reply1(arg, data)
	local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
	local Source_Start = Emoji[math.random(#Emoji)]
	local cmd = arg.cmd
	if not tonumber(data.sender_user_id) then return false end
	if data.sender_user_id then
		if cmd == "id" then
			local function id_cb(arg, data)
				if data.first_name then
					user_name = check_markdown(data.first_name)
				end
				text = Source_Start.."  یوزرنیم ڪاربر  : @"..check_markdown(data.username).."\n"..Source_Start.." اسم ڪاربر  : "..user_name.."\n"..Source_Start.." ایدے عددے  : *"..data.id.."*"
				--return tdbot.sendMessage(arg.chat_id, "", 0, text, 0, "md")
			end
			tdbot_function ({
			_ = "getUser",
			user_id = data.sender_user_id
			}, id_cb, {chat_id=data.chat_id,user_id=data.sender_user_id})
		end
	end
end
function StartBot(bot_user_id, chat_id, parameter)
	assert (tdbot_function ({_ = 'sendBotStartMessage',bot_user_id = bot_user_id,chat_id = chat_id,parameter = tostring(parameter)},  dl_cb, nil))
end
function Mr_Mine(msg)
	local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
	local Source_Start = Emoji[math.random(#Emoji)]
	local chat = msg.to.id
	local user = msg.from.id
	local checkmod = true
	if msg.to.type ~= 'pv' then
		local gpst = redis:get(Alpha.."CheckBot:"..msg.to.id)
		local chex = redis:get(Alpha..'CheckExpire:'..msg.to.id)
		local exd = redis:get(Alpha..'ExpireDate:'..msg.to.id)
		if gpst and not chex and msg.from.id ~= SUDO and not is_sudo(msg) then
			redis:set(Alpha..'CheckExpire:'..msg.to.id,true)
			redis:set(Alpha..'ExpireDate:'..msg.to.id,true)
			redis:setex(Alpha..'ExpireDate:'..msg.to.id, 86400, true)
			--tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start.. ' مدیر عزیز گروہ شما 1روز اعتبار دارد وبعد اتمام اعتبار ربات از گروہ شما بـہ صورت خودڪار لفت خواهد داد \nسودو ربات : '..check_markdown(sudo_username)..'', 1, 'md')
		end
		if chex and not exd and msg.from.id ~= SUDO and not is_sudo(msg) then
			local text1 = Source_Start.. '⚠️گزارش اتمام اعتبار ربات وجهت تمدید اعتبار \n\n》  ایدے گروہ :  <b>'..msg.chat_id..'</b>\n\n》  سودوے عزیز در صورت خارج ڪردن ربات از گروہ دستورات زیر را ارسال ڪنید :\n\n/leave <b>'..msg.chat_id..'<b>\n》  درصورت مراجعـہ بـہ گروہ با دستورات زیر را ارسال ڪنید :\n/jointo <b>'..msg.chat_id..'</b>\n\n》   یا براے تمدید اعتبار ربات ازدستورات زیر :\n\n براے شارژ 1 ماهـہ :\n/plan 1 <b>'..msg.chat_id..'</b>\n\n براے شارژ 3 ماهـہ :\n/plan 2 <b>'..msg.chat_id..'</b>\n\n براے شارژ نامحدود :\n/plan 3 <b>'..msg.chat_id..'</b>'
			local text2 = Source_Start.. '⚠️خطر ربات درحال لفت دادن از گروہ\n\n》 علت:اعتبار ربات تمام شد ربات از گروہ خارج مے شود \n》 با سازنده ربات در ارتباط باشید❗ :/n'..check_markdown(sudo_username)
			tdbot.sendMessage(gp_sudo, 0, 1, text1, 1, 'html')
			tdbot.sendMessage(msg.to.id, 0, 1, text2, 1, 'md')
			botrem(msg)
		else
			local expiretime = redis:ttl(Alpha..'ExpireDate:'..msg.to.id)
			local day = (expiretime / 86400)
			if tonumber(day) > 0.208 and not is_sudo(msg) and is_mod(msg) then
				warning(msg)
			end
		end
	end
	if msg.to.type == 'channel' and msg.content.text and redis:hget(Alpha.."CodeGiftt:", msg.content.text) then
		local b = redis:ttl(Alpha.."CodeGiftCharge:"..msg.content.text)
		local expire = math.floor(b / 86400 ) + 1
		local c = redis:ttl(Alpha..'ExpireDate:'..msg.to.id)
		local extime = math.floor(c / 86400 ) + 1
		redis:setex(Alpha..'ExpireDate:'..msg.to.id, tonumber(extime * 86400) + tonumber(expire * 86400), true)
		redis:del(Alpha.."Codegift:"..msg.to.id)
		redis:srem(Alpha.."CodeGift:" , msg.content.text)
		redis:hdel(Alpha.."CodeGiftt:", msg.content.text)
		local expire_date = ''
		local expi = redis:ttl(Alpha..'ExpireDate:'..msg.to.id)
		if expi == -1 then
			expire_date = '° ͜ʖ ͡°اعتبار مادالعمر'
		else
			local day = math.floor(expi / 86400) + 1
			expire_date = day..' روز'
		end
		local text = Source_Start.. " لاینسس اعتبار هدیـہ   :\n<b>"..msg.content.text.."</b>\nباموفقیت فعال شد\n》  اطلاعات ڪاربر بـہ شرح ذیل است :\n》  یوزرنیم ڪاربر : @"..check_markdown(msg.from.username or '').."\n》  نام ڪاربر  :"..check_markdown(msg.from.first_name).."\n》  ایدے عددے گروہ :\n"..msg.chat_id.."\n》  مدت اعتبارهدیـہ  : *"..expire.."*روز\nاعتبارجدید گروه : *"..expire_date.."*"
		tdbot.sendMessage(gp_sudo, msg.id, 1, text, 1, 'md')
		local text2 = Source_Start.. '  اعتبار هدیـہ  \n با موفقیت ثبت شد'
		tdbot.sendMessage(msg.chat_id, msg.id, 1, text2, 1, 'md')
	end
	if redis:get(Alpha.."atolct2"..msg.to.id) or redis:get(Alpha.."atolct2"..msg.to.id) then
		local time = os.date("%H%M")
		local time2 = redis:get(Alpha.."atolct1"..msg.to.id)
		time2 = time2.gsub(time2,":","")
		local time3 = redis:get(Alpha.."atolct2"..msg.to.id)
		time3 = time3.gsub(time3,":","")
		if tonumber(time3) < tonumber(time2) then
			if tonumber(time) <= 2359 and tonumber(time) >= tonumber(time2) then
				if not redis:get(Alpha.."lc_ato:"..msg.to.id) then
					redis:set(Alpha.."lc_ato:"..msg.to.id,true)
					--tdbot.sendMessage(msg.to.id, 0, 1, Source_Start..'  قفل خودڪار گروہ با موفقیت فعال شد !\n زمان تنظیم شده:'..redis:get(Alpha.."atolct2"..msg.to.id)..'*', 1, 'md')
				end
			elseif tonumber(time) >= 0000 and tonumber(time) < tonumber(time3) then
				if not redis:get(Alpha.."lc_ato:"..msg.to.id) then
					--tdbot.sendMessage(msg.to.id, 0, 1, Source_Start..'  قفل خودڪار گروہ با موفقیت فعال شد !\n زمان تنظیم شده:'..redis:get(Alpha.."atolct2"..msg.to.id)..'', 1, 'md')
					redis:set(Alpha.."lc_ato:"..msg.to.id,true)
				end
			else
				if redis:get(Alpha.."lc_ato:"..msg.to.id) then
					redis:del(Alpha.."lc_ato:"..msg.to.id, true)
				end
			end
		elseif tonumber(time3) > tonumber(time2) then
			if tonumber(time) >= tonumber(time2) and tonumber(time) < tonumber(time3) then
				if not redis:get(Alpha.."lc_ato:"..msg.to.id) then
					--tdbot.sendMessage(msg.to.id, 0, 1, Source_Start..' قفل خودڪار گروہ با موفقیت فعال شد !\n زمان تنظیم شده:'..redis:get(Alpha.."atolct2"..msg.to.id)..'', 1, 'md')
					redis:set(Alpha.."lc_ato:"..msg.to.id,true)
				end
			else
				if redis:get(Alpha.."lc_ato:"..msg.to.id) then
					redis:del(Alpha.."lc_ato:"..msg.to.id, true)
				end
			end
		end
	end
	if redis:get(Alpha.."lc_ato:"..msg.to.id) then
		local is_channel = msg.to.type == "channel"
		local is_chat = msg.to.type == "chat"
		if not is_mod(msg) then
			if is_channel then
				del_msg(msg.to.id, tonumber(msg.id))
			elseif is_chat then
				kick_user(msg.sender_user_id, msg.to.id)
			end
		end 
	end--]]
	if gp_type(msg.chat_id) == "pv" and   msg.content.text and not is_admin(msg) then
		local chkmonshi = redis:get(Alpha..msg.from.id..'chkusermonshi')
		local hash = ('bot:pm')
		local pm = redis:get(Alpha..hash)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if not chkmonshi and pm then
			redis:set(Alpha..msg.from.id..'chkusermonshi', true)
			redis:setex(Alpha..msg.from.id..'chkusermonshi', 86400, true)
			tdbot.sendMessage(msg.chat_id , msg.id, 1, check_markdown(pm), 0, 'md')
			tdbot.sendMessage(gp_sudo , 0, 1,Source_Start.."  پیام فوری\nاین ڪاربر بـہ پیوے من پیام دادہ مشخصات ڪاربر:\nپیام ڪاربر\n"..check_markdown(msg.content.text).."\n\nیوزڪاربر:\n@"..check_markdown(msg.from.username or '').."-*"..msg.sender_user_id.."*" , 0, 'md')
		else
			tdbot.sendMessage(gp_sudo , 0, 1,Source_Start.."  پیام فوری\nاین ڪاربر بـہ پیوے من پیام دادہ مشخصات ڪاربر:\nپیام ڪاربر\n"..check_markdown(msg.content.text).."\n\nیوزڪاربر:\n@"..check_markdown(msg.from.username or '').."-*"..msg.sender_user_id.."*" , 0, 'md')
		end
	end

	if not is_mod(msg)  then
	if not is_whitelist1(msg)  then
		local add_lock = redis:hget(Alpha..'addmeminv', msg.to.id)
		if add_lock == 'on' then
			local chsh = 'addpm'..msg.to.id
			local hsh = redis:get(Alpha..chsh)
			local chkpm = redis:get(Alpha..msg.from.id..'chkuserpm'..msg.to.id)
			if msg.from.username ~= '' then
				username = '@'..check_markdown(msg.from.username)
			else
				username = check_markdown(msg.from.print_name)
			end
			local setadd = redis:hget(Alpha..'addmemset', msg.to.id) or 10
			if msg.adduser then
				tdbot.getUser(msg.content.member_user_ids[0], function(TM, BD)
					if BD.type._ == 'userTypeBot' then
						if not hsh then
						local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 	tdbot.sendMessage(msg.to.id, 0, 1, Source_Start.. ' ڪاربر عزیز   \n`'..msg.from.id..'`➰'..username..'\n──══─✦─══──\n شما اجازہ اد ڪردن ربات در گروہ رو ندارید عضو واقعے اد ڪنید ', 1, 'md')


						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Gapi:"..msg.to.id, 0, inline_query_cb, nil)
						end
						return
					end
					if #msg.content.member_user_ids > 0 then
						if not hsh then
							--tdbot.sendMessage(msg.to.id, 0, 1, Source_Start.. ' ڪاربر  \n`'..msg.from.id..'`➰'..username..'\n ⏺تعداد عضواجبارے شما  *'..(#msg.content.member_user_ids + 1)..'* اضافـہ ڪردید\n──══─✦─══──\n⏺ڪاربر عزیز با تشڪر از زحمات شما خواهشمند است براے عضوگیرے بـہ صورت تڪے انجام گیرد ', 1, 'md')
						end
					end
					local chash = msg.content.member_user_ids[0]..'chkinvusr'..msg.from.id..'chat'..msg.to.id
					local chk = redis:get(Alpha..chash)
					if not chk then
						redis:set(Alpha..chash, true)
						local achash = 'addusercount'..msg.from.id
						local count = redis:hget(Alpha..achash, msg.to.id) or 0
						redis:hset(Alpha..achash, msg.to.id, (tonumber(count) + 1))
						local permit = redis:hget(Alpha..achash, msg.to.id)
						if tonumber(permit) < tonumber(setadd) then
							local less = tonumber(setadd) - tonumber(permit)
							if not hsh then
								tdbot.sendMessage(msg.to.id, 0, 1, Source_Start.. ' ڪاربر  \n📌`'..msg.from.id..'`➰'..username..'\n⏺ تعداد عضواجبارے شما  [*'..permit..'*]\n──══─✦─══──\n'..Source_Start..'  تعداد باقیماندہ عضو اجبارے شما :🔻*'..less..'*ڪاربر🔺', 1, 'md')
							end
						elseif tonumber(permit) == tonumber(setadd) then
							if not hsh then
							local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 	tdbot.sendMessage(msg.to.id, 0, 1, Source_Start.. 'ڪاربر \n📌`'..msg.from.id..'`➰'..username..'\n⏺ محدودیت عضو اجبارے شما باز شد حالا میتوانے بـہ راحتے چت ڪنی\n❤️متشڪرم ', 1, 'md')

						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Jone:"..msg.to.id, 0, inline_query_cb, nil)
							
							end
						end
					else
						if not hsh then
						
						local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return tdbot.sendMessage(msg.to.id, 0, 1, Source_Start.. '  اخطار عضوگیرے تڪراری⚠️\nڪاربر \n`'..msg.from.id..'`➰'..username..'\n──══─✦─══──\n شما قبلا این ڪاربر را بـہ گروہ اضافـہ ڪردہ اید مورد تایید گروہ نمے باشد. ', 1, 'md')

						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Jont:"..msg.to.id, 0, inline_query_cb, nil)
						
						end
					end
					end, nil)
				end
				local permit = redis:hget(Alpha..'addusercount'..msg.from.id, msg.to.id) or 0
				if tonumber(permit) < tonumber(setadd) then 
				local less = tonumber(setadd) - tonumber(permit)
					tdbot.deleteMessages(msg.to.id, {[0] = msg.id}, true, dl_cb, nil)
                     tdbot.sendMessage(msg.to.id, 0, 1, Source_Start..' ڪاربر\n `'..msg.from.id..'`➰'..username..'\n──══─✦─══──\n⏺شما باید ➕'..setadd..'ڪاربر ➕عضو ڪنید تا محدودیت عضو اجبارے براے شما برداشتـہ بشود.\n──══─✦─══──\n❇️تعداد باقیماندہ عضو اجبارے شما:🔻*'..less..'*ڪاربر🔺', 1, 'md') 
  					if not chkpm then
					local less = tonumber(setadd) - tonumber(permit)
						redis:set(Alpha..msg.from.id..'chkuserpm'..msg.to.id, true)
 					--	tdbot.sendMessage(msg.to.id, 0, 1, Source_Start..' ڪاربر\n `'..msg.from.id..'`➰'..username..'\n──══─✦─══──\n⏺شما باید ➕'..setadd..'ڪاربر ➕عضو ڪنید تا محدودیت عضو اجبارے براے شما برداشتـہ بشود.\n──══─✦─══──\n❇️تعداد باقیماندہ عضو اجبارے شما:🔻*'..less..'*ڪاربر🔺', 1, 'md') 
  					end
					return 
				end
			end
		end
		end
	
		
		if msg.to.type ~= 'pv' then
			chat = msg.to.id
			user = msg.from.id
			function check_newmember(arg, data)
				if redis:get(Alpha.."CheckBot:"..msg.to.id) then
					lock_bots = redis:get(Alpha..'lock_bots:'..msg.chat_id)
				end
				if data.type._ == "userTypeBot" then
					if not is_owner(arg.msg) and lock_bots == 'Enable' then
						kick_user(data.id, arg.chat_id)
						sleep(0.5)
						local function GetBots(arg, m)
							if m.members then
								for k,v in pairs (m.members) do
									if not is_mod1(msg.to.id, v.user_id) then
										kick_user(v.user_id, msg.to.id)
									end
								end
							end
						end
						for i = 1, 5 do
							tdbot.getChannelMembers(msg.to.id, 0, 100000000000, 'Bots', GetBots, {msg=msg})
						end
					elseif not is_owner(arg.msg) and lock_bots == 'Pro' then
					
						kick_user(data.id, arg.chat_id)
					--	tdbot.sendMention(chat,user, data.id,Source_Start..' کاربر\n ['..user..']\n به علت اضافه کردن ربات Apiازگروه مسدود شد.📛\n مشخصات:\n '..data.id..'-@'..data.username..'',13,string.len(user))
						kick_user(user, chat)
						sleep(0.5)
						local function GetBots(arg, m)
							if m.members then
								for k,v in pairs (m.members) do
									if not is_mod1(msg.to.id, v.user_id) then
										kick_user(v.user_id, msg.to.id)
									end
								end
							end
						end
						for i = 1, 5 do
							tdbot.getChannelMembers(msg.to.id, 0, 100000000000, 'Bots', GetBots, {msg=msg})
						end
					end
				end
				if data.username then
					user_name = '@'..check_markdown(data.username) 
				else
					user_name = check_markdown(data.first_name)
				end
				if is_banned(data.id, arg.chat_id) then
 					--tdbot.sendMessage(arg.chat_id, arg.msg_id, 0, Source_Start.." ڪاربر \n`"..data.id.."` - "..user_name.."\nازطرف مدیران گروہ محدود یا مسدود شدہ است", 0, "md") 
  					kick_user(data.id, arg.chat_id)
				end
				if is_gbanned(data.id) then
 					--tdbot.sendMessage(arg.chat_id, arg.msg_id, 0, Source_Start.." ڪاربر \n`"..data.id.."` - "..user_name.."\n ازطرف سازندہ ربات وسودوے ربات سوپر مسدود شدہ است.", 0, "md") 
  					kick_user(data.id, arg.chat_id)
				end
			end
			if msg.adduser then
				assert(tdbot_function ({
				_ = "getUser",
				user_id = msg.adduser
				}, check_newmember, {chat_id=chat,msg_id=msg.id,user_id=user,msg=msg}))
			end
			if msg.joinuser then
				assert(tdbot_function ({
				_ = "getUser",
				user_id = msg.joinuser
				}, check_newmember, {chat_id=chat,msg_id=msg.id,user_id=user,msg=msg}))
			end
		end
		
		
		local url , res = https.request('https://enigma-dev.ir/api/time/')
                    if res ~= 200 then
					 text = 'ساعت وتاریخ خاموش می باشد.'
                    else
                    local jdat = json:decode(url)
					
		
		
		local function welcome_cb(arg, data)
			
			if redis:get(Alpha..'setwelcome:'..msg.chat_id) then
				welcome = redis:get(Alpha..'setwelcome:'..msg.chat_id)
			else
			
			local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							text = Source_Start.." سلام به گروه خوش آمدید!"
							--return tdbot.sendMessage(msg.to.id, msg.id, 0, text, 0, "md")
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Welc:"..msg.to.id, 0, inline_query_cb, nil)
			
		
			end
			if redis:get(Alpha..msg.to.id..'rules') then
				rules = redis:get(Alpha..msg.to.id..'rules')
			else
				rules = Source_Start.."قوانین گروه برای این گروه ثبت نشده است❗️"
			end
			if data.username then
				user_name = "@"..check_markdown(data.username)
			else
				user_name = ""
			end
			local welcome = welcome:gsub("{rules}", rules)
			local welcome = welcome:gsub("{name}", check_markdown(data.first_name..' '..(data.last_name or '')))
			local welcome = welcome:gsub("{username}", user_name)
			local welcome = welcome:gsub("{time}", jdat.EnTime.Number)
			local welcome = welcome:gsub("{date}", jdat.EnDate.WordOne)
			local welcome = welcome:gsub("{timefa}", jdat.FaTime.Number)
			local welcome = welcome:gsub("{datefa}", jdat.FaDate.WordTwo)
			local welcome = welcome:gsub("{gpname}", arg.gp_name)
			--tdbot.sendMessage(arg.chat_id, arg.msg_id, 0, welcome, 0, "md")
		end
		if redis:get(Alpha.."CheckBot:"..msg.to.id) then
			if msg.adduser then
				welcome = redis:get(Alpha..'welcome:'..msg.chat_id)
				if welcome == 'Enable' then
					tdbot.getUser(msg.adduser, welcome_cb, {chat_id=chat,msg_id=msg.id,gp_name=msg.to.title})
				else
					return false
				end
			end
			if msg.joinuser then
				welcome = redis:get(Alpha..'welcome:'..msg.chat_id)
				if welcome == 'Enable' then
					tdbot.getUser(msg.sender_user_id, welcome_cb, {chat_id=chat,msg_id=msg.id,gp_name=msg.to.title})
				else
					return false
				end
			end
		end
		
		if tonumber(msg.sender_user_id) ~= 0 then
			if msg.from.username then
				user_name = '@'..msg.from.username
			else
				user_name = msg.from.print_name
			end
			redis:set(Alpha..'user_name:'..msg.from.id, user_name)
		end
	
	end
	end
	-----------------------------

local function welcome_media(arg, data)
local file = redis:get(Alpha.. "wlcfile:"..msg.chat_id)
local welcome = redis:get(Alpha.. "wlctype:"..msg.chat_id)
local media = redis:get(Alpha.. "wlc:"..msg.chat_id)
if data.username then
user_name = "@"..check_markdown(data.username)
else
user_name = ""
end

local welcome = welcome:gsub("{name}", check_markdown(data.first_name))
local welcome = welcome:gsub("{username}", user_name)
local welcome = welcome:gsub("{gpname}", arg.gp_name)
if media == 'photo' then
tdbot.sendPhoto(arg.chat_id, arg.msg_id, file, 0, {}, 0, 0, welcome, 0, 0, 1, nil, dl_cb, nil)
return
end

if media == 'sticker' then
tdbot.sendSticker(arg.chat_id, arg.msg_id, file, 512, 512, 1, nil, nil, dl_cb, nil)
return
end

if media == 'gif' then
tdbot.sendDocument(arg.chat_id, file, welcome, nil, arg.msg_id, 0, 1, nil, dl_cb, nil)
return
end

if media == 'voice' then
tdbot.sendVoice(arg.chat_id, arg.msg_id, file, nil, nil, welcome, nil, nil, nil, dl_cb, nil)
return
end

if media == 'videonote'then
tdbot.sendVideoNote(arg.chat_id, arg.msg_id, file, nil, 0, nil, nil, nil, nil, dl_cb, nil)
return
end
if redis:get(Alpha.."CheckBot:"..msg.to.id) then

			if msg.adduser then
				welcome = redis:get(Alpha..'wlcfile:'..msg.chat_id)
				
					tdbot.getUser(msg.adduser, welcome_media, {chat_id=chat,msg_id=msg.id,gp_name=msg.to.title})
				else
					return false
				
			end
			
			if msg.joinuser then
				welcome = redis:get(Alpha..'wlcfile:'..msg.chat_id)
				
					tdbot.getUser(msg.sender_user_id, welcome_media, {chat_id=chat,msg_id=msg.id,gp_name=msg.to.title})
				else
					return false
				
			end
		end
		
		if tonumber(msg.sender_user_id) ~= 0 then
			if msg.from.username then
				user_name = '@'..msg.from.username
			else
				user_name = msg.from.print_name
			end
			redis:set(Alpha..'user_name:'..msg.from.id, user_name)
		end 
end
----------------- 

	
	
	function exi_files(cpath)
		local files = {}
		local pth = cpath
		for k, v in pairs(scandir(pth)) do
			table.insert(files, v)
		end
		return files
	end
	function file_exi(name, cpath)
		for k,v in pairs(exi_files(cpath)) do
			if name == v then
				return true
			end
		end
		return false
	end
	function run_bash(str)
		local cmd = io.popen(str)
		local result = cmd:read('*all')
		return result
	end
	function index_function(user_id)
		for k,v in pairs(Config.admins) do
			if user_id == v[1] then
				print(k)
				return k
			end
		end
		return false
	end
	function getindex(t,id)
		for i,v in pairs(t) do
			if v == id then
				return i
			end
		end
		return nil
	end
	function GetWeb(messagetext,cb)
assert (tdbot_function ({
_ = 'getWebPagePreview',
message_text = tostring(messagetext)
}, cb, nil))
end
	function already_sudo(user_id)
		for k,v in pairs(Config.sudo_users) do
			if user_id == v then
				return k
			end
		end
		return false
	end
	function exi_file()
		local files = {}
		local pth = tcpath..'/files/documents'
		for k, v in pairs(scandir(pth)) do
			if (v:match('.lua$')) then
				table.insert(files, v)
			end
		end
		return files
	end
	function pl_exi(name)
		for k,v in pairs(exi_file()) do
			if name == v then
				return true
			end
		end
		return false
	end
	function sudolist(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		local sudo_users = Config.sudo_users
		text = Source_Start.." لیست سودو ربات:\n┠┵┳┵┳┵┳┵┳┵┳┵\n"
		for i=1,#sudo_users do
			text = text..i.." - `"..sudo_users[i].."`\n"
		end
		--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
	end
	function adminlist(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		local sudo_users = Config.sudo_users
		text = Source_Start.." لیست معاونین ربات\n┠┵┳┵┳┵┳┵┳┵┳┵\n"
		local compare = text
		local i = 1
		for v,user in pairs(Config.admins) do
			text = text..i..'- '..( user[2] or '' )..' ➣ `('..user[1]..')`\n'
			i = i +1
		end
		if compare == text then
			text = Source_Start..'  هیچ معاونے در لیست موجود نمے باشد ❗️'
		end
		---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
	end

	function chat_list(msg)
		local list = redis:smembers(Alpha..'Group')
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		local message = Source_Start..'  لیست گروہ هاے ربات  :\n┠┵┳┵┳┵┳┵┳┵┳┵\n'
		if #list == 0 then
			message = Source_Start..' بدون لیست می باشد'
		end
		for k,v in pairs(list) do
			local check_time = redis:ttl(Alpha..'ExpireDate:'..v)
			year = math.floor(check_time / 31536000)
			byear = check_time % 31536000
			month = math.floor(byear / 2592000)
			bmonth = byear % 2592000
			day = math.floor(bmonth / 86400)
			bday = bmonth % 86400
			hours = math.floor( bday / 3600)
			bhours = bday % 3600
			min = math.floor(bhours / 60)
			sec = math.floor(bhours % 60)
			if check_time == -1 then
				remained_expire = ' گروہ شما بـہ صورت مادالعمر اعتبار دارد .'
			elseif tonumber(check_time) > 1 and check_time < 60 then
				remained_expire = 'گروه به مدت '..sec..' ثانیه شارژ میباشد'
			elseif tonumber(check_time) > 60 and check_time < 3600 then
				remained_expire = 'گروه به مدت '..min..' دقیقه و '..sec..' ثانیه شارژ میباشد'
			elseif tonumber(check_time) > 3600 and tonumber(check_time) < 86400 then
				remained_expire = 'گروه به مدت '..hours..' ساعت و '..min..' دقیقه و '..sec..' ثانیه شارژ میباشد'
			elseif tonumber(check_time) > 86400 and tonumber(check_time) < 2592000 then
				remained_expire = 'گروه به مدت '..day..' روز و '..hours..' ساعت و '..min..' دقیقه و '..sec..' ثانیه شارژ میباشد'
			elseif tonumber(check_time) > 2592000 and tonumber(check_time) < 31536000 then
				remained_expire = 'گروه به مدت '..month..' ماه '..day..' روز و '..hours..' ساعت و '..min..' دقیقه و '..sec..' ثانیه شارژ میباشد'
			elseif tonumber(check_time) > 31536000 then
				remained_expire = 'گروه به مدت '..year..' سال '..month..' ماه '..day..' روز و '..hours..' ساعت و '..min..' دقیقه و '..sec..' ثانیه شارژ میباشد'
			end
			local GroupsName = redis:get(Alpha..'Gpnameset'..v)
			message = message..k..'-'..Source_Start..'نام گروه : '..GroupsName..'\n'..Source_Start..'آیدی : ' ..v.. '\n'..Source_Start..'اعتبار : '..remained_expire..'\n_______________\n'
		end
		local file = io.open("./data/Gplist.txt", "w")
		file:write(message)
		file:close()
		MaT = Source_Start.. "لیست گروه های ربات"
		tdbot.sendDocument(msg.to.id, "./data/Gplist.txt", MaT, nil, msg.id, 0, 1, nil, dl_cb, nil)
	end
	function botrem(msg)
		if redis:get(Alpha..'CheckExpire:'..msg.to.id) then
			redis:del(Alpha..'CheckExpire:'..msg.to.id)
		end
		if redis:get(Alpha..'ExpireDate:'..msg.to.id) then
			redis:del(Alpha..'ExpireDate:'..msg.to.id)
		end
		redis:srem(Alpha.."Group" ,msg.to.id)
		redis:del(Alpha.."Gpnameset"..msg.to.id)
		redis:del(Alpha.."CheckBot:"..msg.to.id)
		redis:del(Alpha.."Whitelist:"..msg.to.id)
		redis:del(Alpha.."Banned:"..msg.to.id)
		redis:del(Alpha.."Owners:"..msg.to.id)
		redis:del(Alpha.."Mods:"..msg.to.id)
		redis:del(Alpha..'filterlist:'..msg.to.id)
		redis:del(Alpha..msg.to.id..'rules')
		redis:del(Alpha..'setwelcome:'..msg.chat_id)
		redis:del(Alpha..'lock_link:'..msg.chat_id)
		redis:del(Alpha..'lock_join:'..msg.chat_id)
		redis:del(Alpha..'lock_tag:'..msg.chat_id)
		redis:del(Alpha..'lock_username:'..msg.chat_id)
		redis:del(Alpha..'lock_pin:'..msg.chat_id)
		redis:del(Alpha..'lock_arabic:'..msg.chat_id)
		redis:del(Alpha..'lock_mention:'..msg.chat_id)
		redis:del(Alpha..'lock_edit:'..msg.chat_id)
		redis:del(Alpha..'lock_spam:'..msg.chat_id)
		redis:del(Alpha..'lock_flood:'..msg.chat_id)
		redis:del(Alpha..'lock_markdown:'..msg.chat_id)
		redis:del(Alpha..'lock_webpage:'..msg.chat_id)
		redis:del(Alpha..'welcome:'..msg.chat_id)
		redis:del(Alpha..'views:'..msg.chat_id)
		redis:del(Alpha..'lock_bots:'..msg.chat_id)
		redis:del(Alpha..'mute_all:'..msg.chat_id)
		redis:del(Alpha..'mute_gif:'..msg.chat_id)
		redis:del(Alpha..'mute_photo:'..msg.chat_id)
		redis:del(Alpha..'mute_sticker:'..msg.chat_id)
		redis:del(Alpha..'mute_contact:'..msg.chat_id)
		redis:del(Alpha..'mute_inline:'..msg.chat_id)
		redis:del(Alpha..'mute_game:'..msg.chat_id)
		redis:del(Alpha..'mute_text:'..msg.chat_id)
		redis:del(Alpha..'mute_keyboard:'..msg.chat_id)
		redis:del(Alpha..'mute_forward:'..msg.chat_id)
		redis:del(Alpha..'mute_location:'..msg.chat_id)
		redis:del(Alpha..'mute_document:'..msg.chat_id)
		redis:del(Alpha..'mute_voice:'..msg.chat_id)
		redis:del(Alpha..'mute_audio:'..msg.chat_id)
		redis:del(Alpha..'mute_video:'..msg.chat_id)
		redis:del(Alpha..'mute_video_note:'..msg.chat_id)
		redis:del(Alpha..'mute_tgservice:'..msg.chat_id)
		redis:del(Alpha..msg.to.id..'set_char')
		redis:del(Alpha..msg.to.id..'num_msg_max')
		redis:del(Alpha..msg.to.id..'time_check')
		tdbot.changeChatMemberStatus(msg.to.id, our_id, 'Left', dl_cb, nil)
	end
	function warning(msg)
		local expiretime = redis:ttl(Alpha..'ExpireDate:'..msg.to.id)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if expiretime == -1 then
			return
		else
			local d = math.floor(expiretime / 86400) + 1
			if tonumber(d) == 1 and not is_sudo(msg) and is_mod(msg) then
			
			local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 	tdbot.sendMessage(msg.to.id, 0, 1, Source_Start..' از اعتبار ربات 24 ساعت باقی مانده است\n'..Source_Start..' با مدیران ربات جهت تمدید در تماس باشید\nجهت ارتباط با سازنده وتمدید ارتباط در تماس باشد!\n'..check_markdown(sudo_username), 1, 'md')

						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Expi:"..msg.to.id, 0, inline_query_cb, nil)
			
			end
		end
	end
	function action_by_reply(arg, data)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		cmd = arg.cmd
		if not tonumber(data.sender_user_id) then return false end
		if data.sender_user_id then
			if cmd == "warn" then
				function warn_cb(arg, data)
					msg = arg.msg
					hashwarn = arg.chat_id..':warn'
					warnhash = redis:hget(Alpha..hashwarn, data.id) or 1
					max_warn = tonumber(redis:get(Alpha..'max_warn:'..arg.chat_id) or 5)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if tonumber(data.id) == our_id then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." اشتباـہ در ارسال دستورات⚠️\nمن یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم❗️", 0, "md") 
  					end
					if is_mod1(arg.chat_id, data.id) and not is_admin1(data.id)then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." اشتباـہ در ارسال دستورات⚠️\nڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم بهش اخطار بدم توبـہ ڪن عزیزم❗️", 0, "md") 
  					end
					if is_admin1(data.id)then
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."اشتباـہ در ارسال دستورات⚠️\nڪاربر ادمین گروہ مے باشد وازطرف ربات گروہ بـہ عنوان ترفیع شدہ ها منصوب شدہ است❗️", 0, "md") 
  					end
					if tonumber(warnhash) == tonumber(max_warn) then
						kick_user(data.id, arg.chat_id)
						redis:hdel(Alpha..hashwarn, data.id, '0')
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." ڪاربر \n`"..data.id.."` - "..user_name.."\nبـہ دلیل توجـہ نڪردن بـہ اخطارهاے مدیران از گروہ اخراج شد.\nمجموع اخطار ڪاربر :*"..warnhash.."*\nاخطارتنظیم شده:*"..max_warn.."*", 0, "md") 
  					else
						redis:hset(Alpha..hashwarn, data.id, tonumber(warnhash) + 1)
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." ڪاربر \n`"..data.id.."` - "..user_name.."\n ازطرف مدیران گروہ اخطاردریافت ڪرد⚠️\nمجموع اخطار ڪاربر :*"..warnhash.."*عدد\nاخطارتنظیم شده:*"..max_warn.."*عدد", 0, "md") 
  					end
				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, warn_cb, {chat_id=data.chat_id,user_id=data.sender_user_id,msg=arg.msg})
			end
			if cmd == "unwarn" then
				function unwarn_cb(arg, data)
					hashwarn = arg.chat_id..':warn'
					warnhash = redis:hget(Alpha..hashwarn, data.id) or 1
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if not redis:hget(Alpha..hashwarn, data.id) then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."  ڪاربر \n`"..data.id.."` - "..user_name.."\nدراین گروہ بدون اخطار مے باشد❗️", 0, "md") 
  					else
						redis:hdel(Alpha..hashwarn, data.id, '0')
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." مجموع اخطارهاے دریافتے ڪاربر \n`"..data.id.."` - "..user_name.."\nباموفقیت پاڪ شد.", 0, "md") 
  					end
				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, unwarn_cb, {chat_id=data.chat_id,user_id=data.sender_user_id})
			end
			if cmd == "setwhitelist" then
				function setwhitelist_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Whitelist:"..arg.chat_id,data.id)
					if list then
 						return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."  ڪاربر \n `"..data.id.."` - "..user_name.."\nقبلان درلیست مجاز ها مے باشد!", 0, "md") 
  					end
					redis:sadd(Alpha.."Whitelist:"..arg.chat_id,data.id)
 					return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." ڪاربر \n `"..data.id.."` - "..user_name.."\nبـہ لیست مجازهاے ربات وگروہ اضافـہ شد✅", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, setwhitelist_cb, {chat_id=data.chat_id,user_id=data.sender_user_id})
			end
			if cmd == "remwhitelist" then
				function remwhitelist_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Whitelist:"..arg.chat_id,data.id)
					if not list then
 						return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "ڪاربر\n`"..data.id.."` - "..user_name.."\nدرلیست مجازها ثبت نشدہ است", 0, "md") 
  					end
					redis:srem(Alpha.."Whitelist:"..arg.chat_id,data.id)
 					return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "ڪاربر\n`"..data.id.."` - "..user_name.."\nبا موفقیت ازلیست مجازها حذف شد.❌", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, remwhitelist_cb, {chat_id=data.chat_id,user_id=data.sender_user_id})
			end
			if cmd == "setowner" then
				function owner_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Owners:"..arg.chat_id,data.id)
					if list then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "ڪاربر\n`"..data.id.."` - "..user_name.."\nبـہ عنوان مالڪ ربات انتخاب شدہ بود❗️", 0, "md") 
  					end
					redis:sadd(Alpha.."Owners:"..arg.chat_id,data.id)
 					--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "ڪاربر\n `"..data.id.."` - "..user_name.."\nبـہ عنوان مالڪ ربات انتخاب شد✅", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, owner_cb, {chat_id=data.chat_id,user_id=data.sender_user_id})
			end
			if cmd == "promote" then
				function promote_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Mods:"..arg.chat_id,data.id)
					if list then
 						---return tdbot.sendMessage(arg.chat_id, data.id, 0, Source_Start.." ڪاربر\n `"..data.id.."` - "..user_name.."\nازقبل ترفیع شدہ بود❗️", 0, "md") 
  					end
					redis:sadd(Alpha.."Mods:"..arg.chat_id,data.id)
 					---return tdbot.sendMessage(arg.chat_id, data.id, 0, Source_Start.." ڪاربر\n `"..data.id.."` - "..user_name.."\n بـہ لیست ترفیع شدہ ها انتخاب شد✅", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, promote_cb, {chat_id=data.chat_id,user_id=data.sender_user_id})
			end
			if cmd == "remowner" then
				function rem_owner_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Owners:"..arg.chat_id,data.id)
					if not list then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." ڪاربر\n`"..data.id.."` - "..user_name.."\nبـہ عنوان مالڪ ربات انتخاب نشدہ بود_️", 0, "md") 
  					end
					redis:srem(Alpha.."Owners:"..arg.chat_id,data.id)
					 ---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." ڪاربر\n`"..data.id.."` - "..user_name.."\nازلیست مالڪان ربات حذف شد❌", 0, "md") 
				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, rem_owner_cb, {chat_id=data.chat_id,user_id=data.sender_user_id})
			end
			if cmd == "demote" then
				function demote_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Mods:"..arg.chat_id,data.id)
					if not list then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. " ڪاربر\n`"..data.id.."` - "..user_name.."\nبـہ عنوان ترفیع انتخاب نشدہ بود❗️", 0, "md") 
  					end
					redis:srem(Alpha.."Mods:"..arg.chat_id,data.id)
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. " ڪاربر\n`"..data.id.."` - "..user_name.."\n ازلیست ترفیع شدہ ها عزل وحذف شد❌", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, demote_cb, {chat_id=data.chat_id,user_id=data.sender_user_id})
			end
			if cmd == "ban" then
				function ban_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					
					if data.id == our_id then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." اشتباـہ در ارسال دستورات⚠️\nمن یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم❗️", 0, "md") 
					end
					if is_admin1(data.id)then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." اشتباـہ در ارسال دستورات⚠️\nڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم بهش  مسدود کنم توبـہ ڪن عزیزم❗️", 0, "md") 
					end
					if is_mod1(arg.chat_id, data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."اشتباـہ در ارسال دستورات⚠️\nڪاربر ادمین گروہ مے باشد وازطرف ربات گروہ بـہ عنوان ترفیع شدہ ها منصوب شدہ است❗️", 0, "md") 
					end
					local list = redis:sismember(Alpha.."Banned:"..arg.chat_id,data.id)
					if list then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. " ڪاربر\n`"..data.id.."` - "..user_name.."\nقبلان از این گروہ مسدود شدہ بود❗️", 0, "md") 
  					end
					redis:sadd(Alpha.."Banned:"..arg.chat_id,data.id)
					kick_user(data.id, arg.chat_id)
					local function config_cb(arg, data)
			for k,v in pairs(data.members) do
			local addmins = tonumber(data.total_count) -1 
				local function config_mods(arg, data)
				if data.username ~= '' then
               username = ''..v.user_id..'';end
				end;assert (tdbot_function ({_ = "getUser",user_id = v.user_id}, config_mods, {user_id=v.user_id}))
                    if data.members[k].status._ == "chatMemberStatusCreator" then
					local owner_id = v.user_id
					local function config_owner(arg, data)
 					tdbot.sendMessage(v.user_id , arg.chat_id, 1, "_ارسال گزارش ازطرف ربات⚠️_\n _ڪاربر دستور مسدود ارسال ڪرد_\nاین ڪاربر\n`"..data.id.."`- "..user_name.."\n _توسط ادمین هاے گروہ مسدود وبن شد علت مسدود شدن ڪاربر رو جویا باشید_❗️\n⏰ساعت:`"..os.date("%H:%M:%S").."`\n📆تاریخ:`"..os.date("%c").."`", 0, "md")  
  					end ;assert (tdbot_function ({_ = "getUser",user_id = owner_id}, config_owner, {user_id=owner_id}))
				end;end;end; 
		tdbot.getChannelMembers(arg.chat_id, 0, 200, 'Administrators', config_cb, {chat_id=arg.chat_id})
 					return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "ڪاربر\n`"..data.id.."` - "..user_name.."\nازطرف مدیران گروہ مسدود شد🚫", 0, "md") 
  				end
				assert(tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, ban_cb, {chat_id=data.chat_id,user_id=data.sender_user_id}))
			end
			if cmd == "unban" then
				function unban_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Banned:"..arg.chat_id,data.id)
					if not list then
 						return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." ڪاربر \n`"..data.id.."` - "..user_name.."\n مسدود نشدہ است❗️", 0, "md") 
  					end
					redis:srem(Alpha.."Banned:"..arg.chat_id,data.id)
					channel_unblock(arg.chat_id, data.id)
 					return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." ڪاربر\n`"..data.id.."` - "..user_name.."\nازلیست مسدود شدہ ها حذف وآزاد شد.❌", 0, "md") 
  				end
				assert(tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, unban_cb, {chat_id=data.chat_id,user_id=data.sender_user_id}))
			end
			if cmd == "silent" then
				function silent_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if data.id == our_id then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\nمن یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم❗️", 0, "md") 
  					end
					if is_admin1(data.id)then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." ️اشتباـہ در ارسال دستورات⚠️\nڪاربر ادمین گروہ مے باشد وازطرف ربات گروہ بـہ عنوان ترفیع شدہ ها منصوب شدہ است❗️", 0, "md") 
  					end
					if is_mod1(arg.chat_id, data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\nڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم سڪوت ڪنم توبـہ ڪن عزیزم❗️", 0, "md") 
  					end
					local function check_silent(msg, is_silent)
						local user_name = msg.user_name
						arg = msg.arg
						if is_silent then
							 ---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "ڪاربر \n `"..data.id.."`-"..user_name.."\nازقبل درلیست سڪوت شدہ ها مے باشد❗️", 0, "md") 
						end
						silent_user(arg.chat_id, data.id)
						redis:sadd(Alpha.."Silentlist:"..arg.chat_id,data.id)
						local function config_cb(arg, data)
			for k,v in pairs(data.members) do
			local addmins = tonumber(data.total_count) -1 
				local function config_mods(arg, data)
				if data.username ~= '' then
               username = ''..v.user_id..'';end
				end;assert (tdbot_function ({_ = "getUser",user_id = v.user_id}, config_mods, {user_id=v.user_id}))
                    if data.members[k].status._ == "chatMemberStatusCreator" then
					local owner_id = v.user_id
					local function config_owner(arg, data)
 					tdbot.sendMessage(v.user_id , arg.chat_id, 1, "_ارسال گزارش ازطرف ربات⚠️_\n _ڪاربر دستور سڪوت ارسال ڪرد_\nاین ڪاربر\n`"..data.id.."`- "..user_name.."\n _توسط ادمین هاے گروہ سڪوت شد علت سڪوت شدن ڪاربر رو جویا باشید_❗️\n⏰ساعت:`"..os.date("%H:%M:%S").."`\n📆تاریخ:`"..os.date("%c").."`", 0, "md")  
  					end ;assert (tdbot_function ({_ = "getUser",user_id = owner_id}, config_owner, {user_id=owner_id}))
				end;end;end; 
		tdbot.getChannelMembers(arg.chat_id, 0, 200, 'Administrators', config_cb, {chat_id=arg.chat_id})
 						return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "ڪاربر \n `"..data.id.."`-"..user_name.."\nازطرف مدیران گروہ توانایے چت ڪردن روازدست وسڪوت شد📵", 0, "md") 
  					end
					is_silent_user(data.id, arg.chat_id, {arg=arg, user_name=user_name,id=data.id}, check_silent)
				end
				assert(tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, silent_cb, {chat_id=data.chat_id,user_id=data.sender_user_id}))
			end
			if cmd == "unsilent" then
				local function unsilent_cb(arg, data)
					if data.username and data.username ~= "" then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local function check_silent(msg, is_silent)
						local user_name = msg.user_name
						arg = msg.arg
						if not is_silent then
 							---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "ڪاربر \n`"..data.id.."`-"..user_name.."\nسڪوت نشدہ بود❗️", 0, "md") 
  						end
						unsilent_user(arg.chat_id, data.id)
						redis:srem(Alpha.."Silentlist:"..arg.chat_id,data.id)
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "ڪاربر \n`"..data.id.."`-"..user_name.."\nازطرف مدیران گروہ  آزاد وازلیست سڪوت شدہ حذف شد✅", 0, "md") 
  					end
					is_silent_user(data.id, arg.chat_id, {arg=arg, user_name=user_name,id=data.id}, check_silent)
				end
				assert(tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, unsilent_cb, {chat_id=data.chat_id,user_id=data.sender_user_id}))
			end
			if cmd == "banall" then
				function gban_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if data.id == our_id then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\nمن یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم❗️", 0, "md") 
  					end
					if is_admin1(data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." اشتباـہ در ارسال دستورات⚠️\nڪاربر ادمین گروہ مے باشد وازطرف ربات گروہ بـہ عنوان ترفیع شدہ ها منصوب شدہ است❗️", 0, "md") 
  					end
					if is_gbanned(data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." ڪاربر \n`"..data.id.."` - "..user_name.."\nقبلان سوپرمسدود شدہ بود❗️", 0, "md") 
  					end
					redis:sadd(Alpha.."GBanned",data.id)
					kick_user(data.id, arg.chat_id)
 					--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." ڪاربر \n`"..data.id.."` - "..user_name.."\nسوپرمسدودشد وازتمامے گروہ هاے ربات شناسایے وحذف شد⛔️", 0, "md") 
  				end
				assert(tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, gban_cb, {chat_id=data.chat_id,user_id=data.sender_user_id}))
			end
			if cmd == "unbanall" then
				function ungban_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if not is_gbanned(data.id) then
						 ---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."  ڪاربر \n  `"..data.id.."` - "..user_name.."\nسوپرمسدود نیست❗️", 0, "md") 
					end
					redis:srem(Alpha.."GBanned",data.id)
					 ---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."  ڪاربر \n `"..data.id.."` - "..user_name.."\nازلیست سوپرمسدودے ها حذف وآزاد شد.✅", 0, "md") 
				end
				assert(tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, ungban_cb, {chat_id=data.chat_id,user_id=data.sender_user_id}))
			end
			-----
			if cmd == "kick" then
				if data.sender_user_id == our_id then
						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\nمن یک ربات هستم ودستور مدیران ربات را اجرا میکنم نه اینکه خودم رو محدود کنم❗️", 0, "md")
				elseif is_mod1(data.chat_id, data.sender_user_id) then
						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\nکاربر معاون ربات یا مالک گروه می باشد نمیتوانم اخراج کنم توبه کن عزیزم❗️", 0, "md")
				else
					kick_user(data.sender_user_id, data.chat_id)
					sleep(1)
					channel_unblock(data.chat_id, data.sender_user_id)
				end
			end
			if cmd == "delall" then
				if is_mod1(data.chat_id, data.sender_user_id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_ڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم پاڪ ڪنم توبـہ ڪن عزیزم_❗️", 0, "md") 
  				else
					tdbot.deleteMessagesFromUser(data.chat_id, data.sender_user_id, dl_cb, nil)
 					---tdbot.sendMention(data.chat_id,data.sender_user_id, data.id,Source_Start.. 'پیام ڪاربر '..data.sender_user_id..'حذف شد',16,string.len(data.sender_user_id)) 
  				end
			end
			if cmd == "adminprom" then
				function adminprom_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if is_admin1(tonumber(data.id)) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_بـہ عنوان معاون ربات انتخاب شدہ بود_❗️", 0, "md") 
  					end
					table.insert(Config.admins, {tonumber(data.id), user_name})
					save_config()
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_بـہ عنوان معاون ربات انتخاب شد._✅", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, adminprom_cb, {chat_id=data.chat_id,user_id=data.sender_user_id})
			end
			if cmd == "admindem" then
				function admindem_cb(arg, data)
					local nameid = index_function(tonumber(data.id))
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if not is_admin1(data.id) then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_معاون ربات نمے باشد_❗️", 0, "md") 
  					end
					table.remove(Config.admins, nameid)
					save_config()
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_از معاونت ربات عزل شد_❌", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, admindem_cb, {chat_id=data.chat_id,user_id=data.sender_user_id})
			end
			if cmd == "visudo" then
				function visudo_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if already_sudo(tonumber(data.id)) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n _قبلان بـہ مقام سودو ربات انتخاب شدہ بود_❗️", 0, "md") 
  					end
					table.insert(Config.sudo_users, tonumber(data.id))
					save_config()
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_بـہ مقام سودو ربات انتخاب شد_✅", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, visudo_cb, {chat_id=data.chat_id,user_id=data.sender_user_id})
			end
			if cmd == "desudo" then
				function desudo_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if not already_sudo(data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_سودو نبود._❗️", 0, "md") 
  					end
					table.remove(Config.sudo_users, getindex( Config.sudo_users, tonumber(data.id)))
					save_config()
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_ازمقام سودو برڪنار شد_❌", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.sender_user_id
				}, desudo_cb, {chat_id=data.chat_id,user_id=data.sender_user_id})
			end
		end
	end
	function action_by_username(arg, data)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		cmd = arg.cmd
		if not arg.username then return false end
		if data.id then
			if cmd == "warn" then
				function warn_cb(arg, data)
					if not data.id then return end
					msg = arg.msg
					hashwarn = arg.chat_id..':warn'
					warnhash = redis:hget(Alpha..hashwarn, data.id) or 1
					max_warn = tonumber(redis:get(Alpha..'max_warn:'..arg.chat_id) or 5)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if data.id == our_id then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_من یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم_❗️", 0, "md") 
  					end
					if is_admin1(data.id)then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." اشتباـہ در ارسال دستورات⚠️\nڪاربر ادمین گروہ مے باشد وازطرف ربات گروہ بـہ عنوان ترفیع شدہ ها منصوب شدہ است❗️", 0, "md") 
  					end
					if is_mod1(arg.chat_id, data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_ڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم سڪوت ڪنم توبـہ ڪن عزیزم_❗️", 0, "md") 
  					end
					if tonumber(warnhash) == tonumber(max_warn) then
						kick_user(data.id, arg.chat_id)
						redis:hdel(Alpha..hashwarn, data.id, '0')
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_بـہ دلیل توجـہ نڪردن بـہ اخطارهاے مدیران از گروہ اخراج شد._\n_مجموع اخطار ڪاربر_ :*"..warnhash.."*\n_اخطارتنظیم شده_:*"..max_warn.."*", 0, "md") 
  					else
						redis:hset(Alpha..hashwarn, data.id, tonumber(warnhash) + 1)
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_ \n`"..data.id.."` - "..user_name.."\n _ازطرف مدیران گروہ اخطاردریافت ڪرد_⚠️\n_مجموع اخطار ڪاربر_ :*"..warnhash.."*عدد\n_اخطارتنظیم شده_:*"..max_warn.."*عدد", 0, "md")					
						end 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, warn_cb, {chat_id=arg.chat_id,user_id=data.id,msg=arg.msg})
			end
			if cmd == "unwarn" then
				if not data.id then return end
				function unwarn_cb(arg, data)
					hashwarn = arg.chat_id..':warn'
					warnhash = redis:hget(Alpha..hashwarn, data.id) or 1
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
				if not redis:hget(Alpha..hashwarn, data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."  _ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_دراین گروہ بدون اخطار مے باشد_❗️", 0, "md") 
  					else
						redis:hdel(Alpha..hashwarn, data.id, '0')
                         ---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _مجموع اخطارهاے دریافتے ڪاربر_ \n`"..data.id.."` - "..user_name.."\nباموفقیت پاڪ شد.", 0, "md") 
  					end
				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, unwarn_cb, {chat_id=arg.chat_id,user_id=data.id,msg=arg.msg})
			end
			
			if cmd == "setwhitelist" then
				function setwhitelist_cb(arg, data)
					if not data.id then return end
					if data.username and data.username ~= "" then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Whitelist:"..arg.chat_id,data.id)
					if list then
 			return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."  _ڪاربر_ \n `"..data.id.."` - "..user_name.."\n_قبلان درلیست مجاز ها مے باشد!_", 0, "md") 
  					end
					redis:sadd(Alpha.."Whitelist:"..arg.chat_id,data.id)
 					return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_ \n `"..data.id.."` - "..user_name.."\n_بـہ لیست مجازهاے ربات وگروہ اضافـہ شد✅_", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, setwhitelist_cb, {chat_id=arg.chat_id,user_id=data.id})
			end
			--------
			if cmd == "remwhitelist" then
				function remwhitelist_cb(arg, data)
					if not data.id then return end
					if data.username and data.username ~= "" then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Whitelist:"..arg.chat_id,data.id)
					if not list then
 						return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_\n`"..data.id.."` - "..user_name.."\n_درلیست مجازها ثبت نشدہ است_", 0, "md") 
  					end
					redis:srem(Alpha.."Whitelist:"..arg.chat_id,data.id)
 					return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_با موفقیت ازلیست مجازها حذف شد.❌_", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, remwhitelist_cb, {chat_id=arg.chat_id,user_id=data.id})
			end
			-----
			if cmd == "setowner" then
				function owner_cb(arg, data)
					if not data.id then return end
					if data.username and data.username ~= "" then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Owners:"..arg.chat_id,data.id)
					if list then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_\n`"..data.id.."` - "..user_name.."\n_بـہ عنوان مالڪ ربات انتخاب شدہ بود_❗️", 0, "md") 
  					end
					redis:sadd(Alpha.."Owners:"..arg.chat_id,data.id)
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_\n `"..data.id.."` - "..user_name.."\n_بـہ عنوان مالڪ ربات انتخاب شد_✅", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, owner_cb, {chat_id=arg.chat_id,user_id=data.id})
			end
			------
			if cmd == "promote" then
				function promote_cb(arg, data)
					if not data.id then return end
					if data.username and data.username ~= "" then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Mods:"..arg.chat_id,data.id)
					if list then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_\n `"..data.id.."` - "..user_name.."\n_ازقبل ترفیع شدہ بود_❗️", 0, "md") 
  					end
					redis:sadd(Alpha.."Mods:"..arg.chat_id,data.id)
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_\n `"..data.id.."` - "..user_name.."\n _بـہ لیست ترفیع شدہ ها انتخاب شد_✅", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, promote_cb, {chat_id=arg.chat_id,user_id=data.id})
			end
			---------------
			if cmd == "remowner" then
				function rem_owner_cb(arg, data)
					if not data.id then return end
					if data.username and data.username ~= "" then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Owners:"..arg.chat_id,data.id)
					if not list then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_\n`"..data.id.."` - "..user_name.."\n_بـہ عنوان مالڪ ربات انتخاب نشدہ بود_❗️", 0, "md") 
  					end
					redis:srem(Alpha.."Owners:"..arg.chat_id,data.id)
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_\n`"..data.id.."` - "..user_name.."\n_ازلیست مالڪان ربات حذف شد_❌", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, rem_owner_cb, {chat_id=arg.chat_id,user_id=data.id})
			end
			------
			if cmd == "demote" then
				function demote_cb(arg, data)
					if not data.id then return end
					if data.username and data.username ~= "" then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Mods:"..arg.chat_id,data.id)
					if not list then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_\n`"..data.id.."` - "..user_name.."\n_بـہ عنوان مالڪ ربات انتخاب نشدہ بود_❗️", 0, "md") 
  					end
					redis:srem(Alpha.."Owners:"..arg.chat_id,data.id)
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_\n`"..data.id.."` - "..user_name.."\n_ازلیست مالڪان ربات حذف شد_❌", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, demote_cb, {chat_id=arg.chat_id,user_id=data.id})
			end
			--------
			if cmd == "res" then
				function res_cb(arg, data)
					if not data.id then return end
					if data.last_name then
						user_name = check_markdown(data.first_name).." "..check_markdown(data.last_name)
					else
						user_name = check_markdown(data.first_name)
					end
 					text = Source_Start.." `اطلاعات براے :` @"..check_markdown(data.username).."\n"..Source_Start.."`نام :` "..user_name.."\n"..Source_Start.."`ایدے :` *"..data.id.."*" 
  					---return tdbot.sendMessage(arg.chat_id, "", 0, text, 0, "md")
				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, res_cb, {chat_id=arg.chat_id,user_id=data.id})
			end
			if cmd == "ban" then
				function ban_cb(arg, data)
					if not data.id then return end
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if data.id == our_id then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_من یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم_❗️", 0, "md") 
  					end
					if is_admin1(data.id)then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." اشتباـہ در ارسال دستورات⚠️\nڪاربر ادمین گروہ مے باشد وازطرف ربات گروہ بـہ عنوان ترفیع شدہ ها منصوب شدہ است❗️", 0, "md") 
  					end
					if is_mod1(arg.chat_id, data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_ڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم مسدود ڪنم توبـہ ڪن عزیزم_❗️", 0, "md") 
  					end
					local list = redis:sismember(Alpha.."Banned:"..arg.chat_id,data.id)
					if list then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. " _ڪاربر_\n`"..data.id.."` - "..user_name.."\n_قبلان از این گروہ مسدود شدہ بود_❗️", 0, "md") 
  					end
					redis:sadd(Alpha.."Banned:"..arg.chat_id,data.id)
					kick_user(data.id, arg.chat_id)
					local function config_cb(arg, data)
			for k,v in pairs(data.members) do
			local addmins = tonumber(data.total_count) -1
				local function config_mods(arg, data)
				if data.username ~= '' then
               username = ''..v.user_id..'';end
				end;assert (tdbot_function ({_ = "getUser",user_id = v.user_id}, config_mods, {user_id=v.user_id}))
                    if data.members[k].status._ == "chatMemberStatusCreator" then
					owner_id = v.user_id
					local function config_owner(arg, data)
					tdbot.sendMessage(v.user_id , msg.id, 1, repmsg, 0, 'md') 
					end ;assert (tdbot_function ({_ = "getUser",user_id = owner_id}, config_owner, {user_id=owner_id}))
				end;end;end; 
		tdbot.getChannelMembers(msg.to.id, 0, 200, 'Administrators', config_cb, {chat_id=msg.to.id})
 		tdbot.sendMessage(v.user_id,msg.id,Source_Start.. 'گزارش ربات\n ڪاربر @'..check_markdown(msg.from.username or '')..'دستور مسدود ارسال ڪرد\nاین ڪاربر`'..data.id..'` - '..user_name..'\n مسدود شد.',0,'md') 
   					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_\n`"..data.id.."` - "..user_name.."\n_ازطرف مدیران گروہ مسدود شد_🚫", 0, "md") 
  				end
				assert(tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, ban_cb, {chat_id=arg.chat_id,user_id=data.id}))
			end
			------
			if cmd == "unban" then
				function unban_cb(arg, data)
					if not data.id then return end
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local list = redis:sismember(Alpha.."Banned:"..arg.chat_id,data.id)
					if not list then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_ مسدود نشدہ است_❗️", 0, "md") 
  					end
					redis:srem(Alpha.."Banned:"..arg.chat_id,data.id)
					channel_unblock(arg.chat_id, data.id)
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_ازلیست مسدود شدہ ها حذف وآزاد شد._❌", 0, "md") 
  				end
				assert(tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, unban_cb, {chat_id=arg.chat_id,user_id=data.id}))
			end
			---------------
			if cmd == "silent" then
				function silent_cb(arg, data)
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if data.id == our_id then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_من یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم_❗️", 0, "md") 
  					end
					if is_admin1(data.id)then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _اشتباـہ در ارسال دستورات⚠️\nڪاربر ادمین گروہ مے باشد وازطرف ربات گروہ بـہ عنوان ترفیع شدہ ها منصوب شدہ است❗️", 0, "md") 
  					end
					if is_mod1(arg.chat_id, data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_ڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم سڪوت ڪنم توبـہ ڪن عزیزم_❗️", 0, "md") 
  					end
					local function check_silent(msg, is_silent)
						local user_name = msg.user_name
						arg = msg.arg
						if is_silent then
 							---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n `"..data.id.."`-"..user_name.."\n_ازقبل درلیست سڪوت شدہ ها مے باشد_❗️", 0, "md") 
  						end
						silent_user(arg.chat_id, data.id)
						redis:sadd(Alpha.."Silentlist:"..arg.chat_id,data.id)

 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n `"..data.id.."`-"..user_name.."\n_ازطرف مدیران گروہ توانایے چت ڪردن روازدست وسڪوت شد_📵", 0, "md") 
  
					end
					is_silent_user(data.id, arg.chat_id, {arg=arg, user_name=user_name,id=data.id}, check_silent)
				end
				assert(tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, silent_cb, {chat_id=arg.chat_id,user_id=data.id}))
			end
			-----------------------------
			if cmd == "unsilent" then
				function unsilent_cb(arg, data)
					if not data.id then return end
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					local function check_silent(msg, is_silent)
						local user_name = msg.user_name
						arg = msg.arg
						if not is_silent then
 							---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."`-"..user_name.."\n_سڪوت نشدہ بود_❗️", 0, "md") 
  						end
						unsilent_user(arg.chat_id, data.id)
						redis:srem(Alpha.."Silentlist:"..arg.chat_id,data.id)
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."`-"..user_name.."\n_ازطرف مدیران گروہ  آزاد وازلیست سڪوت شدہ حذف شد_✅", 0, "md") 
  					end
					is_silent_user(data.id, arg.chat_id, {arg=arg, user_name=user_name,id=data.id}, check_silent)
				end
				assert(tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, unsilent_cb, {chat_id=arg.chat_id,user_id=data.id}))
			end
			------------------------------
			if cmd == "banall" then
				function gban_cb(arg, data) 
					if not data.id then return end
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if data.id == our_id then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_من یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم_❗️", 0, "md") 
  					end
					if is_admin1(data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." اشتباـہ در ارسال دستورات⚠️\nڪاربر ادمین گروہ مے باشد وازطرف ربات گروہ بـہ عنوان ترفیع شدہ ها منصوب شدہ است❗️", 0, "md") 
  					end
					if is_gbanned(data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_قبلان سوپرمسدود شدہ بود_❗️", 0, "md") 
  					end
					redis:sadd(Alpha.."GBanned",data.id)
					kick_user(data.id, arg.chat_id)
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_سوپرمسدودشد وازتمامے گروہ هاے ربات شناسایے وحذف شد_⛔️", 0, "md") 
  				end
				assert(tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, gban_cb, {chat_id=arg.chat_id,user_id=data.id}))
			end
			-------------------------------------
			if cmd == "unbanall" then
				function ungban_cb(arg, data)
					if not data.id then return end
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if not is_gbanned(data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."  _ڪاربر_ \n  `"..data.id.."` - "..user_name.."\nسوپرمسدود نیست❗️", 0, "md") 
  					end
					redis:srem(Alpha.."GBanned",data.id)
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."  _ڪاربر_ \n `"..data.id.."` - "..user_name.."\n_ازلیست سوپرمسدودے ها حذف وآزاد شد._✅", 0, "md") 
  				end
				assert(tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, ungban_cb, {chat_id=arg.chat_id,user_id=data.id}))
			end
			-----
			if cmd == "kick" then
				if not data.id then return end
				if data.id == our_id then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_من یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم_❗️", 0, "md") 
  				elseif is_mod1(arg.chat_id, data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_ڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم اخراج ڪنم توبـہ ڪن عزیزم_❗️", 0, "md") 
  				else
					kick_user(data.id, arg.chat_id)
					sleep(1)
					channel_unblock(arg.chat_id, data.id)
				end
			end
			if cmd == "delall" then
				if not data.id then return end
				if is_mod1(arg.chat_id, data.id) then
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."*شما نمیتوانید پیام هاے مدیران،صاحبان گروہ و ادمین هاے ربات رو پاڪ ڪنید*", 0, "md") 
  				else
					tdbot.deleteMessagesFromUser(arg.chat_id, data.id, dl_cb, nil)
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."تمام پیام هاے "..data.title.." [ "..data.id.." ] پاڪ شد", 0, "md") 
  				end
			end
			-------
			if cmd == "adminprom" then
				function adminprom_cb(arg, data)
					if not data.id then return end
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if is_admin1(tonumber(data.id)) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_بـہ عنوان معاون ربات انتخاب شدہ بود_❗️", 0, "md") 
  					end
					table.insert(Config.admins, {tonumber(data.id), user_name})
					save_config()
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_بـہ عنوان معاون ربات انتخاب شد._✅", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, adminprom_cb, {chat_id=arg.chat_id,user_id=data.id})
			end
			-----
			if cmd == "admindem" then
				function admindem_cb(arg, data)
					if not data.id then return end
					local nameid = index_function(tonumber(data.id))
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if not is_admin1(data.id) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_معاون ربات نمے باشد_❗️", 0, "md") 
  					end
					table.remove(Config.admins, nameid)
					save_config()
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_از معاونت ربات عزل شد_❌", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, admindem_cb, {chat_id=arg.chat_id,user_id=data.id})
			end
			---------------
			if cmd == "visudo" then
				function visudo_cb(arg, data)
					if not data.id then return end
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if already_sudo(tonumber(data.id)) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n _قبلان بـہ مقام سودو ربات انتخاب شدہ بود_❗️", 0, "md") 
  					end
					table.insert(Config.sudo_users, tonumber(data.id))
					save_config()
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_بـہ مقام سودو ربات انتخاب شد_✅", 0, "md") 
  
				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, visudo_cb, {chat_id=arg.chat_id,user_id=data.id})
			end
			------
			if cmd == "desudo" then
				function desudo_cb(arg, data)
					if not data.id then return end
					if data.username then
						user_name = '@'..check_markdown(data.username)
					else
						user_name = check_markdown(data.first_name)
					end
					if not already_sudo(data.id) then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_سودو نبود._❗️", 0, "md") 
  					end
					table.remove(Config.sudo_users, getindex( Config.sudo_users, tonumber(data.id)))
					save_config()
 					--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_ازمقام سودو برڪنار شد_❌", 0, "md") 
  				end
				tdbot_function ({
				_ = "getUser",
				user_id = data.id
				}, desudo_cb, {chat_id=arg.chat_id,user_id=data.id})
			end
		end
	end
	---------------------------------
	function action_by_id(arg, data)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		cmd = arg.cmd
		if not tonumber(arg.user_id) then return false end
		if data.id then
			if data.username then
				user_name = '@'..check_markdown(data.username)
			else
				user_name = check_markdown(data.first_name)
			end
			---------
			if cmd == "warn" then
				if data.id == our_id then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_من یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم_❗️", 0, "md") 
  					end
					if is_admin1(data.id)then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." اشتباـہ در ارسال دستورات⚠️\nڪاربر ادمین گروہ مے باشد وازطرف ربات گروہ بـہ عنوان ترفیع شدہ ها منصوب شدہ است❗️", 0, "md") 
  					end
					if is_mod1(arg.chat_id, data.id) then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_ڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم سڪوت ڪنم توبـہ ڪن عزیزم_❗️", 0, "md") 
  					end
				end
				if tonumber(warnhash) == tonumber(max_warn) then
					kick_user(data.id, arg.chat_id)
					redis:hdel(Alpha..hashwarn, data.id, '0')
 				---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_بـہ دلیل توجـہ نڪردن بـہ اخطارهاے مدیران از گروہ اخراج شد._\n_مجموع اخطار ڪاربر_ :*"..warnhash.."*\n_اخطارتنظیم شده_:*"..max_warn.."*", 0, "md") 
  				else
					redis:hset(Alpha..hashwarn, data.id, tonumber(warnhash) + 1)
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_ \n`"..data.id.."` - "..user_name.."\n _ازطرف مدیران گروہ اخطاردریافت ڪرد_⚠️\n_مجموع اخطار ڪاربر_ :*"..warnhash.."*عدد\n_اخطارتنظیم شده_:*"..max_warn.."*عدد", 0, "md")					 
  						end
				end
			end
						-------
			if cmd == "unwarn" then
				if not redis:hget(Alpha..hashwarn, data.id) then
 			---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."  _ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_دراین گروہ بدون اخطار مے باشد_❗️", 0, "md") 
  				else
					redis:hdel(Alpha..hashwarn, data.id, '0')
                       ---  return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _مجموع اخطارهاے دریافتے ڪاربر_ \n`"..data.id.."` - "..user_name.."\nباموفقیت پاڪ شد.", 0, "md") 
  				end
			end

			--------------------------------
			if cmd == "setwhitelist" then
				local list = redis:sismember(Alpha.."Whitelist:"..arg.chat_id,data.id)
				if list then
 return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."  _ڪاربر_ \n `"..data.id.."` - "..user_name.."\n_قبلان درلیست مجاز ها مے باشد!_", 0, "md") 
  				end
				redis:sadd(Alpha.."Whitelist:"..arg.chat_id,data.id)
 					return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_ \n `"..data.id.."` - "..user_name.."\n_بـہ لیست مجازهاے ربات وگروہ اضافـہ شد✅_", 0, "md") 
  			end
			----------------------------------
			if cmd == "remwhitelist" then
				local list = redis:sismember(Alpha.."Whitelist:"..arg.chat_id,data.id)
				if not list then
 					return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_\n`"..data.id.."` - "..user_name.."\n_درلیست مجازها ثبت نشدہ است_", 0, "md") 
  					end
					redis:srem(Alpha.."Whitelist:"..arg.chat_id,data.id)
 					return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_با موفقیت ازلیست مجازها حذف شد.❌_", 0, "md") 
  			end
			------------------------------------
		
			if cmd == "setowner" then
				local list = redis:sismember(Alpha.."Owners:"..arg.chat_id,data.id)
				if list then
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_\n`"..data.id.."` - "..user_name.."\n_بـہ عنوان مالڪ ربات انتخاب شدہ بود_❗️", 0, "md") 
  					end
					redis:sadd(Alpha.."Owners:"..arg.chat_id,data.id)
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_\n `"..data.id.."` - "..user_name.."\n_بـہ عنوان مالڪ ربات انتخاب شد_✅", 0, "md") 
  			end
			---------------------------
			if cmd == "promote" then
				local list = redis:sismember(Alpha.."Mods:"..arg.chat_id,data.id)
				if list then
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_\n `"..data.id.."` - "..user_name.."\n_ازقبل ترفیع شدہ بود_❗️", 0, "md") 
  					end
					redis:sadd(Alpha.."Mods:"..arg.chat_id,data.id)
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_\n `"..data.id.."` - "..user_name.."\n _بـہ لیست ترفیع شدہ ها انتخاب شد_✅", 0, "md") 
  			end
			----------------------------
			if cmd == "remowner" then
				local list = redis:sismember(Alpha.."Owners:"..arg.chat_id,data.id)
				if not list then
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_\n`"..data.id.."` - "..user_name.."\n_بـہ عنوان مالڪ ربات انتخاب نشدہ بود_❗️", 0, "md") 
  					end
					redis:srem(Alpha.."Owners:"..arg.chat_id,data.id)
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_\n`"..data.id.."` - "..user_name.."\n_ازلیست مالڪان ربات حذف شد_❌", 0, "md") 
  			end
			---------------------------
			if cmd == "demote" then
				local list = redis:sismember(Alpha.."Mods:"..arg.chat_id,data.id)
				if not list then
 					--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_\n`"..data.id.."` - "..user_name.."\n_بـہ عنوان مالڪ ربات انتخاب نشدہ بود_❗️", 0, "md") 
  					end
					redis:srem(Alpha.."Owners:"..arg.chat_id,data.id)
 					--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.." _ڪاربر_\n`"..data.id.."` - "..user_name.."\n_ازلیست مالڪان ربات حذف شد_❌", 0, "md") 
  			end
			if cmd == "kick" then
				if tonumber(data.id) == our_id then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_من یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم_❗️", 0, "md") 
  				elseif is_mod1(arg.chat_id, userid) then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_ڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم اخراج ڪنم توبـہ ڪن عزیزم_❗️", 0, "md") 
  				else
					kick_user(data.id, arg.chat_id)
					sleep(1)
					channel_unblock(arg.chat_id, data.id)
				end
			end
			if cmd == "delall" then
				if is_mod1(arg.chat_id, data.id) then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_ڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم پاڪ ڪنم توبـہ ڪن عزیزم_❗️", 0, "md") 
  				else
					tdbot.deleteMessagesFromUser(arg.chat_id, data.id, dl_cb, nil)
 					--tdbot.sendMention(arg.chat_id,data.id, arg.id,Source_Start..'تمامے پیام هاے '..data.id..' پاڪ شد',17,string.len(data.id)) 
  				end
			end
			---------------------------------------
			
			
			
			if cmd == "banall" then
				if tonumber(data.id) == our_id then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. " اشتباـہ در ارسال دستورات⚠️\n_من یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم_❗️", 0, "md") 
  				end
				if is_admin1(data.id) then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_ڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم سوپرمسدود ڪنم توبـہ ڪن عزیزم_❗️", 0, "md") 
  				end
				if is_gbanned(data.id) then
 					--tdbot.sendMention(arg.chat_id,data.id, arg.id,Source_Start..' ڪاربر '..data.id..'\n قبلان سوپرمسدود شدہ بود❗️',8,string.len(data.id)) 
  				end
				redis:sadd(Alpha.."GBanned",data.id)
				kick_user(data.id, arg.chat_id)
 				--tdbot.sendMention(arg.chat_id,data.id, arg.id,Source_Start..' ڪاربر '..data.id..'\n سوپرمسدودشد وازتمامے گروہ هاے ربات شناسایے وحذف شد⛔️',8,string.len(data.id)) 
  			end
			----------------------------------------------
			if cmd == "unbanall" then
				if not is_gbanned(data.id) then
 				--	tdbot.sendMention(arg.chat_id,data.id, arg.id,Source_Start..' ڪاربر '..data.id..'\n سوپرمسدود نیست❗️',8,string.len(data.id)) 
  				end
				redis:srem(Alpha.."GBanned",data.id)
 				--tdbot.sendMention(arg.chat_id,data.id, arg.id,Source_Start..' ڪاربر '..data.id..'\n ازلیست سوپرمسدودے ها حذف وآزاد شد.✅',8,string.len(data.id)) 
  			end
			----------------------------------------
			if cmd == "ban" then
				if tonumber(data.id) == our_id then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. " اشتباـہ در ارسال دستورات⚠️\n_من یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم_❗️", 0, "md") 
  				end
				if is_mod1(arg.chat_id, tonumber(data.id)) then
 						--return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_ڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم مسدود ڪنم توبـہ ڪن عزیزم_❗️", 0, "md") 
  				end
				if is_banned(data.id, arg.chat_id) then
 					---tdbot.sendMention(arg.chat_id,data.id, arg.id,Source_Start.. 'ڪاربر\n '..data.id..'\n قبلان از این گروہ مسدود شدہ بود❗️',8,string.len(data.id)) 
  				end
				redis:sadd(Alpha.."Banned:"..arg.chat_id,data.id)
				kick_user(data.id, arg.chat_id)
				local function config_cb(arg, data)
			for k,v in pairs(data.members) do
			local addmins = tonumber(data.total_count) -1
				local function config_mods(arg, data)
				if data.username ~= '' then
               username = ''..v.user_id..'';end
				end;assert (tdbot_function ({_ = "getUser",user_id = v.user_id}, config_mods, {user_id=v.user_id}))
                    if data.members[k].status._ == "chatMemberStatusCreator" then
					owner_id = v.user_id
					local function config_owner(arg, data)
					tdbot.sendMessage(v.user_id , msg.id, 1, repmsg, 0, 'md') 
					end ;assert (tdbot_function ({_ = "getUser",user_id = owner_id}, config_owner, {user_id=owner_id}))
				end;end;end; 
		tdbot.getChannelMembers(msg.to.id, 0, 200, 'Administrators', config_cb, {chat_id=msg.to.id})
 		tdbot.sendMessage(v.user_id,msg.id,Source_Start.. 'گزارش ربات\n ڪاربر @'..check_markdown(msg.from.username or '')..'دستور مسدود ارسال ڪرد\nاین ڪاربر'..data.id..'\n مسدود شد.',0,'md') 
   				--tdbot.sendMention(arg.chat_id,data.id, arg.id,Source_Start.. 'ڪاربر\n '..data.id..'\n ازطرف مدیران گروہ مسدود شد🚫',8,string.len(data.id)) 
  			end
			
			
			if cmd == "unban" then
				if not is_banned(data.id, arg.chat_id) then
 					---tdbot.sendMention(arg.chat_id,data.id, arg.id,Source_Start.. 'ڪاربر\n '..data.id..'\n مسدود نشدہ است❗️',8,string.len(data.id)) 
  				end
				redis:srem(Alpha.."Banned:"..arg.chat_id,data.id)
				channel_unblock(arg.chat_id, data.id)
 				---tdbot.sendMention(arg.chat_id,data.id, arg.id,Source_Start..' ڪاربر \n '..data.id..' \nازلیست مسدود شدہ ها حذف وآزاد شد.❌',8,string.len(data.id)) 
  			end
			----------------------------------------------
			if cmd == "silent" then
				if tonumber(data.id) == our_id then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. " اشتباـہ در ارسال دستورات⚠️\n_من یڪ ربات هستم ودستور مدیران ربات را اجرا میڪنم نـہ اینڪـہ خودم رو محدود ڪنم_❗️", 0, "md") 
  				end
				if is_mod1(arg.chat_id, tonumber(data.id)) then
 						---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "اشتباـہ در ارسال دستورات⚠️\n_ڪاربر معاون ربات یا مالڪ گروہ مے باشد نمیتوانم سڪوت ڪنم توبـہ ڪن عزیزم_❗️", 0, "md") 
  				end
				local function check_silentt(roo, is_silent)
					if is_silent then
 						---tdbot.sendMention(arg.chat_id,roo.id, arg.id,Source_Start..' ڪاربر \n'..roo.id..'\n ازقبل درلیست سڪوت شدہ ها مے باشد❗️',8,string.len(roo.id)) 
  					end
					silent_user(arg.chat_id, roo.id)
					redis:sadd(Alpha.."Silentlist:"..arg.chat_id,roo.id)
 					---tdbot.sendMention(arg.chat_id,roo.id, arg.id,Source_Start..' ڪاربر\n '..roo.id..'\n ازطرف مدیران گروہ توانایے چت ڪردن روازدست وسڪوت شد📵',8,string.len(roo.id)) 
  				end
				is_silent_user(data.id, arg.chat_id, {id=data.id}, check_silentt)
			end
			------------------------------------------------
			if cmd == "unsilent" then
				local function check_silent(roo, is_silent)
					if not is_silent then
 						---return tdbot.sendMention(arg.chat_id,roo.id, arg.id,Source_Start..' ڪاربر\n '..roo.id..'\n سڪوت نشدہ بود❗️',8,string.len(roo.id)) 
  					end
					unsilent_user(arg.chat_id, roo.id)
					redis:srem(Alpha.."Silentlist:"..arg.chat_id,roo.id)
 					---return tdbot.sendMention(arg.chat_id,roo.id, arg.id,Source_Start..' ڪاربر\n '..roo.id..'\n ازطرف مدیران گروہ  آزاد وازلیست سڪوت شدہ حذف شد✅',8,string.len(roo.id)) 
  				end
				is_silent_user(tonumber(data.id), arg.chat_id, {id=data.id}, check_silent)
			end
			------------------------------------------
			if cmd == "whois" then
				if data.username then
					username = '@'..check_markdown(data.username)
				else
					username = 'ندارد'
				end
 				---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start..'اطلاعات براے [ '..data.id..' ] :\n'..Source_Start..'یوزرنیم : '..username..'\n'..Source_Start..'نام : '..check_markdown(data.first_name), 0, "md") 
  			end
			-----------------------------------------------
			if cmd == "adminprom" then
				if is_admin1(tonumber(data.id)) then
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_بـہ عنوان معاون ربات انتخاب شدہ بود_❗️", 0, "md") 
  					end
					table.insert(Config.admins, {tonumber(data.id), user_name})
					save_config()
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_بـہ عنوان معاون ربات انتخاب شد._✅", 0, "md") 
  			end
			-------------------------------------------------------
			if cmd == "admindem" then
				local nameid = index_function(tonumber(data.id))
				if not is_admin1(data.id) then
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_معاون ربات نمے باشد_❗️", 0, "md") 
  					end
					table.remove(Config.admins, nameid)
					save_config()
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.."_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_از معاونت ربات عزل شد_❌", 0, "md") 
  			end
			--------------------------------------------------------
			if cmd == "visudo" then
				if already_sudo(tonumber(data.id)) then
					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n _قبلان به مقام سودو ربات انتخاب شده بود_❗️", 0, "md")
					end
					table.insert(Config.sudo_users, tonumber(data.id))
					save_config()
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_بـہ مقام سودو ربات انتخاب شد_✅", 0, "md") 
  			end
			if cmd == "desudo" then
				if not already_sudo(data.id) then
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_سودو نبود._❗️", 0, "md") 
  					end
					table.remove(Config.sudo_users, getindex( Config.sudo_users, tonumber(data.id)))
					save_config()
 					---return tdbot.sendMessage(arg.chat_id, "", 0, Source_Start.. "_ڪاربر_ \n`"..data.id.."` - "..user_name.."\n_ازمقام سودو برڪنار شد_❌", 0, "md") 
  			end
	-----------------------------------------------------------------
	local api_key = nil
	local base_api = "https://maps.googleapis.com/maps/api"
	function get_latlong(area)
		local api      = base_api .. "/geocode/json?"
		local parameters = "address=".. (URL.escape(area) or "")
		if api_key ~= nil then
			parameters = parameters .. "&key="..api_key
		end
		local res, code = https.request(api..parameters)
		if code ~=200 then return nil  end
		local data = json:decode(res)
		if (data.status == "ZERO_RESULTS") then
			return nil
		end
		if (data.status == "OK") then
			lat  = data.results[1].geometry.location.lat
			lng  = data.results[1].geometry.location.lng
			acc  = data.results[1].geometry.location_type
			types= data.results[1].types
			return lat,lng,acc,types
		end
	end
	function get_weather(msg, location)
		print("Finding weather in ", location)
		local BASE_URL = "http://api.openweathermap.org/data/2.5/weather"
		local url = BASE_URL
		url = url..'?q='..location..'&APPID=eedbc05ba060c787ab0614cad1f2e12b'
		url = url..'&units=metric'
		local b, c, h = http.request(url)
		if c ~= 200 then return nil end
		local weather = json:decode(b)
		local city = weather.name
		local country = weather.sys.country
		local temp = 'دمای شهر '..city..' هم اکنون '..weather.main.temp..' درجه سانتی گراد می باشد\n____________________'
		local conditions = 'شرایط فعلی آب و هوا : '
		if weather.weather[1].main == 'Clear' then
			conditions = conditions .. 'آفتابی☀'
		elseif weather.weather[1].main == 'Clouds' then
			conditions = conditions .. 'ابری ☁☁'
		elseif weather.weather[1].main == 'Rain' then
			conditions = conditions .. 'بارانی ☔'
		elseif weather.weather[1].main == 'Thunderstorm' then
			conditions = conditions .. 'طوفانی ☔☔☔☔'
		elseif weather.weather[1].main == 'Mist' then
			conditions = conditions .. 'مه 💨'
		end
		---tdbot.sendMessage(msg.chat_id , msg.id, 1, temp .. '\n' .. conditions, 1, 'md')
	end
	function exi_filef(path, suffix)
		local files = {}
		local pth = tostring(path)
		local psv = tostring(suffix)
		for k, v in pairs(scandir(pth)) do
			if (v:match('.'..psv..'$')) then
				table.insert(files, v)
			end
		end
		return files
	end
	function file_exif(name, path, suffix)
		local fname = tostring(name)
		local pth = tostring(path)
		local psv = tostring(suffix)
		for k,v in pairs(exi_filef(pth, psv)) do
			if fname == v then
				return true
			end
		end
		return false
	end
	function getRandomButts(attempt)
		attempt = attempt or 0
		attempt = attempt + 1
		local res,status = http.request("http://api.obutts.ru/noise/1")
		if status ~= 200 then return nil end
		local data = json:decode(res)[1]
		if not data and attempt <= 3 then
			return getRandomButts(attempt)
		end
		return 'http://media.obutts.ru/' .. data.preview
	end
	function getRandomBoobs(attempt)
		attempt = attempt or 0
		attempt = attempt + 1
		local res,status = http.request("http://api.oboobs.ru/noise/1")
		if status ~= 200 then return nil end
		local data = json:decode(res)[1]
		if not data and attempt < 10 then
			return getRandomBoobs(attempt)
		end
		return 'http://media.oboobs.ru/' .. data.preview
	end
	function modadd(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if redis:get(Alpha.."CheckBot:"..msg.to.id) then
			tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. ' _ربات در لیست گروه ربات از قبل بود_', 0, 'md')
		else
			redis:set(Alpha..'ExpireDate:'..msg.to.id,true)
			redis:setex(Alpha..'ExpireDate:'..msg.to.id, 172800, true)
			set_configadd(msg)
			if not redis:get(Alpha..'CheckExpire:'..msg.to.id) then
				redis:set(Alpha..'CheckExpire:'..msg.to.id,true)
			end
			redis:sadd(Alpha.."Group" ,msg.to.id)
			redis:set(Alpha.."Gpnameset"..msg.to.id ,msg.to.title)
			redis:set(Alpha.."CheckBot:"..msg.to.id ,true)
			
			local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
					
 							text = Source_Start.. ' _ربات درگروه_ '..check_markdown(msg.to.title)..'\n_بـہ مدت 24 ساعت بـہ صورت تستے شارژ شد _\n _با موفقیت بـہ صورت تستے بـہ لیست گروہ ها اضافـہ شد._✅' 
  							return tdbot.sendMessage(msg.to.id, msg.id, 0, text, 0, 'md')
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Adde:"..msg.to.id, 0, inline_query_cb, nil)
			
			
			
		end
	end
	function modrem(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if not is_admin(msg) then
 	--tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '_شما دسترسے ندارید لطفا ازتڪرار آن اجتناب ڪنید_.❗️', 0, 'md') 
  		end
		if not redis:get(Alpha.."CheckBot:"..msg.to.id) then
 			---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '_ربات دراین گروہ قابل  قبول نمے باشدواز این گروہ لفت خواهد داد_❗️', 0, 'md') 
  		end
		redis:srem(Alpha.."Group" ,msg.to.id)
		redis:del(Alpha.."Gpnameset"..msg.to.id)
		redis:del(Alpha.."CheckBot:"..msg.to.id)
		redis:del(Alpha.."Whitelist:"..msg.to.id)
		redis:del(Alpha.."Banned:"..msg.to.id)
		redis:del(Alpha.."Owners:"..msg.to.id)
		redis:del(Alpha.."Mods:"..msg.to.id)
		redis:del(Alpha..'filterlist:'..msg.to.id)
		redis:del(Alpha..msg.to.id..'rules')
		redis:del(Alpha..'setwelcome:'..msg.chat_id)
		redis:del(Alpha..'lock_link:'..msg.chat_id)
		redis:del(Alpha..'lock_join:'..msg.chat_id)
		redis:del(Alpha..'lock_tag:'..msg.chat_id)
		redis:del(Alpha..'lock_username:'..msg.chat_id)
		redis:del(Alpha..'lock_pin:'..msg.chat_id)
		redis:del(Alpha..'lock_arabic:'..msg.chat_id)
		redis:del(Alpha..'lock_mention:'..msg.chat_id)
		redis:del(Alpha..'lock_edit:'..msg.chat_id)
		redis:del(Alpha..'lock_spam:'..msg.chat_id)
		redis:del(Alpha..'lock_flood:'..msg.chat_id)
		redis:del(Alpha..'lock_markdown:'..msg.chat_id)
		redis:del(Alpha..'lock_webpage:'..msg.chat_id)
		redis:del(Alpha..'welcome:'..msg.chat_id)
		redis:del(Alpha..'views:'..msg.chat_id)
		redis:del(Alpha..'lock_bots:'..msg.chat_id)
		redis:del(Alpha..'mute_all:'..msg.chat_id)
		redis:del(Alpha..'mute_gif:'..msg.chat_id)
		redis:del(Alpha..'mute_photo:'..msg.chat_id)
		redis:del(Alpha..'mute_sticker:'..msg.chat_id)
		redis:del(Alpha..'mute_contact:'..msg.chat_id)
		redis:del(Alpha..'mute_inline:'..msg.chat_id)
		redis:del(Alpha..'mute_game:'..msg.chat_id)
		redis:del(Alpha..'mute_text:'..msg.chat_id)
		redis:del(Alpha..'mute_keyboard:'..msg.chat_id)
		redis:del(Alpha..'mute_forward:'..msg.chat_id)
		redis:del(Alpha..'mute_location:'..msg.chat_id)
		redis:del(Alpha..'mute_document:'..msg.chat_id)
		redis:del(Alpha..'mute_voice:'..msg.chat_id)
		redis:del(Alpha..'mute_audio:'..msg.chat_id)
		redis:del(Alpha..'mute_video:'..msg.chat_id)
		redis:del(Alpha..'mute_video_note:'..msg.chat_id)
		redis:del(Alpha..'mute_tgservice:'..msg.chat_id)
		redis:del(Alpha..msg.to.id..'set_char')
		redis:del(Alpha..msg.to.id..'num_msg_max')
		redis:del(Alpha..msg.to.id..'time_check')
		--tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '_گروه_ \n[`'..check_markdown(msg.to.title)..'`]\n _توسط_\n`'..msg.from.id..'` - @'..check_markdown(msg.from.username)..'\n_باموفقیت لغو نصب شد_', 0, 'md')
	end
	----------------------
	function resetsettings(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if not is_mod(msg) then
 			--tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '_شما دسترسے ندارید لطفا ازتڪرار آن اجتناب ڪنید_.❗️', 0, 'md') 
  		end
		if not redis:get(Alpha.."CheckBot:"..msg.to.id) then
 			--tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start..'ربات دراین گروہ نصب نشدہ است.', 0, 'md') 
  		end
		redis:del(Alpha..'lock_views:'..msg.chat_id)
		redis:del(Alpha..'filterlist:'..msg.to.id)
		redis:del(Alpha..'lock_tabchi:'..msg.chat_id)
		redis:del(Alpha..'mute_forward:'..msg.chat_id)
		redis:del(Alpha..'mute_forwarduser:'..msg.chat_id)
		redis:del(Alpha..'setwelcome:'..msg.chat_id)
		redis:del(Alpha..'lock_link:'..msg.chat_id)
		redis:del(Alpha..'lock_join:'..msg.chat_id)
		redis:del(Alpha..'lock_tag:'..msg.chat_id)
		redis:del(Alpha..'lock_username:'..msg.chat_id)
		redis:del(Alpha..'lock_pin:'..msg.chat_id)
		redis:del(Alpha..'lock_arabic:'..msg.chat_id)
		redis:del(Alpha..'lock_mention:'..msg.chat_id)
		redis:del(Alpha..'lock_edit:'..msg.chat_id) 
		redis:del(Alpha..'lock_spam:'..msg.chat_id)
		redis:del(Alpha..'lock_flood:'..msg.chat_id)
		redis:del(Alpha..'lock_markdown:'..msg.chat_id)
		redis:del(Alpha..'lock_webpage:'..msg.chat_id)
		redis:del(Alpha..'welcome:'..msg.chat_id)
		redis:del(Alpha..'lock_bots:'..msg.chat_id)
		redis:del(Alpha..'mute_all:'..msg.chat_id)
		redis:del(Alpha..'mute_gif:'..msg.chat_id)
		redis:del(Alpha..'mute_photo:'..msg.chat_id)
		redis:del(Alpha..'mute_sticker:'..msg.chat_id)
		redis:del(Alpha..'mute_contact:'..msg.chat_id)
		redis:del(Alpha..'mute_inline:'..msg.chat_id)
		redis:del(Alpha..'mute_game:'..msg.chat_id)
		redis:del(Alpha..'mute_text:'..msg.chat_id)
		redis:del(Alpha..'mute_keyboard:'..msg.chat_id)
		redis:del(Alpha..'mute_forward:'..msg.chat_id)
		redis:del(Alpha..'mute_location:'..msg.chat_id)
		redis:del(Alpha..'mute_document:'..msg.chat_id)
		redis:del(Alpha..'mute_voice:'..msg.chat_id)
		redis:del(Alpha..'mute_audio:'..msg.chat_id)
		redis:del(Alpha..'mute_video:'..msg.chat_id)
		redis:del(Alpha..'mute_video_note:'..msg.chat_id)
		redis:del(Alpha..'mute_tgservice:'..msg.chat_id)
 		---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '_گروه_ \n['..check_markdown(msg.to.title)..']\n _توسط_\n`'..msg.from.id..'` - @'..check_markdown(msg.from.username)..'\n_باموفقیت ڪلیـہ تنظیمات ریست شد_', 0, 'md') 
  	end
	
	---------------------------------
	function LockMedia(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if not is_mod(msg) then
 			---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '_شما دسترسے ندارید لطفا ازتڪرار آن اجتناب ڪنید_.❗️', 0, 'md') 
  		end
		redis:set(Alpha..'mute_gif:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_video:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_video_note:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_document:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_inline:'..msg.chat_id,'Enable')
		redis:set(Alpha..'views:'..msg.chat_id,'Enable')
		redis:set(Alpha..'lock_bots:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_sticker:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_photo:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_voice:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_audio:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_game:'..msg.chat_id,'Enable')
 			---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '⚠️قفل اضطرارے رسانـہ هادر گروه['..check_markdown(msg.to.title)..']\n'..Source_Start..' _تمامے مواردے ڪـہ مربوط بـہ رسانـہ میباشد قفل شد.✅_ \n\n'..Source_Start..' _توسط_\n@'..check_markdown(msg.from.username)..'\n'..Source_Start..'_موارد قفل شده:عڪس-فیلم-سلفی-گیف-استیڪر-اینلاین-بازی-ویس-آهنگ-فایل_', 0, 'md') 
  	end
	---------------------------------
	function UnLockMediaa(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if not is_mod(msg) then
 			---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '_شما دسترسے ندارید لطفا ازتڪرار آن اجتناب ڪنید_.❗️', 0, 'md') 
  		end
		redis:del(Alpha..'mute_gif:'..msg.chat_id)
		redis:del(Alpha..'mute_video:'..msg.chat_id)
		redis:del(Alpha..'mute_video_note:'..msg.chat_id)
		redis:del(Alpha..'mute_document:'..msg.chat_id)
		redis:del(Alpha..'mute_inline:'..msg.chat_id)
		redis:del(Alpha..'views:'..msg.chat_id)
		redis:del(Alpha..'lock_bots:'..msg.chat_id)
		redis:del(Alpha..'mute_sticker:'..msg.chat_id)
		redis:del(Alpha..'mute_photo:'..msg.chat_id)
		redis:del(Alpha..'mute_voice:'..msg.chat_id)
		redis:del(Alpha..'mute_audio:'..msg.chat_id)
		redis:del(Alpha..'mute_game:'..msg.chat_id)
 			---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '⚠️بازڪردن اضطرارے رسانـہ هادر گروه['..check_markdown(msg.to.title)..']\n'..Source_Start..' _تمامے مواردے ڪـہ مربوط بـہ رسانـہ میباشد غیرفعال شد.❌_ \n\n'..Source_Start..' _توسط_\n@'..check_markdown(msg.from.username)..'\n'..Source_Start..'_موارد قفل شده:عڪس-فیلم-سلفی-گیف-استیڪر-اینلاین-بازی-ویس-آهنگ-فایل_', 0, 'md') 
  	end
	
	
	-----------------------------
	function LockTablighat(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if not is_mod(msg) then
 			--tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '_شما دسترسے ندارید لطفا ازتڪرار آن اجتناب ڪنید_.❗️', 0, 'md') 
  		end
		redis:set(Alpha..'lock_link:'..msg.chat_id,'Enable')
		redis:set(Alpha..'lock_tag:'..msg.chat_id,'Enable')
		redis:set(Alpha..'lock_username:'..msg.chat_id,'Enable')
		redis:set(Alpha..'lock_mention:'..msg.chat_id,'Enable')
		redis:set(Alpha..'lock_webpage:'..msg.chat_id,'Enable')
		redis:set(Alpha..'views:'..msg.chat_id,'Enable')
		redis:set(Alpha..'lock_bots:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_contact:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_tgservice:'..msg.chat_id,'Enable')
		redis:set(Alpha..'lock_tabchi:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_forward:'..msg.chat_id,'Enable')
		redis:set(Alpha..'mute_forwarduser:'..msg.chat_id,'Enable')
 			--tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '⚠️قفل اضطرارے تبلیغات در گروه[`'..check_markdown(msg.to.title)..'`]\n'..Source_Start..'_تمامے مواردے ڪـہ مربوط بـہ تبلیغات بود در گروہ قفل شد.✅_ \n\n'..Source_Start..' _توسط_\n@'..check_markdown(msg.from.username)..'\n'..Source_Start..' _موارد قفل شده:لینڪ-هشتگ-ربات-فوروارد-وب-مخاطب-تبچی-یوزرنیم-سرویس ومنشن_', 0, 'md') 
  	end
	function UnLockTablighat(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if not is_mod(msg) then
 			---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '_شما دسترسے ندارید لطفا ازتڪرار آن اجتناب ڪنید_.❗️', 0, 'md') 
  		end
		redis:del(Alpha..'lock_link:'..msg.chat_id)
		redis:del(Alpha..'lock_tag:'..msg.chat_id)
		redis:del(Alpha..'lock_username:'..msg.chat_id)
		redis:del(Alpha..'lock_mention:'..msg.chat_id)
		redis:del(Alpha..'lock_webpage:'..msg.chat_id)
		redis:del(Alpha..'views:'..msg.chat_id)
		redis:del(Alpha..'lock_bots:'..msg.chat_id)
		redis:del(Alpha..'mute_contact:'..msg.chat_id)
		redis:del(Alpha..'mute_tgservice:'..msg.chat_id)
		redis:del(Alpha..'lock_tabchi:'..msg.chat_id)
		redis:del(Alpha..'mute_forward:'..msg.chat_id)
		redis:del(Alpha..'mute_forwarduser:'..msg.chat_id)
 			----tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. '⚠️بازڪردن اضطرارے تبلیغات در گروه[`'..check_markdown(msg.to.title)..'`]\n'..Source_Start..'_تمامے مواردے ڪـہ مربوط بـہ تبلیغات بود در گروہ غیرفعال شد❌_ \n\n'..Source_Start..' _توسط_\n@'..check_markdown(msg.from.username)..'\n'..Source_Start..' _موارد قفل شده:لینڪ-هشتگ-ربات-فوروارد-وب-مخاطب-تبچی-یوزرنیم-سرویس ومنشن_', 0, 'md') 
  	end
	--------------------------
	function filter_word(msg, word)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if redis:hget(Alpha..'filterlist:'..msg.to.id, word) then
 			--tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. "_ڪلمه_\n [*"..word.."*]\n_ازقبل قابل فیلتر مے باشد_❗️", 0, 'md') 
  		else
		redis:hset(Alpha..'filterlist:'..msg.to.id, word, "newword")
 		---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. "_ڪلمه_ \n*[ *"..word.."* ] _توسط_ \n*"..msg.from.id.."* - @"..check_markdown(msg.from.username).."\n_بـہ لیست فیلتر شدہ ها اضافـہ شد._✅", 0, 'md') 
  	end
	end
	function unfilter_word(msg, word)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if not redis:hget(Alpha..'filterlist:'..msg.to.id, word) then
 			---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. "_ڪلمه_\n [*"..word.."*] `از قبل فیلتر نبود`", 0, 'md') 
  		else
			redis:hdel(Alpha..'filterlist:'..msg.to.id, word)
 			---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. "_ڪلمه_\n [ *"..word.."* ]\n _توسط_\n *"..msg.from.id.."* - @"..check_markdown(msg.from.username).."\n_ازلیست فیلتر شدہ حذف شد_", 0, 'md') 
  		end
	end
	function filter_list(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		local names = redis:hkeys(Alpha..'filterlist:'..msg.to.id)
		filterlist = Source_Start.. '_لیست کلمات فیلتر شده_ :\n'
		local b = 1
		for i = 1, #names do
			filterlist = filterlist .. b .. ". " .. names[i] .. "\n"
			b = b + 1
		end
		if #names == 0 then
 			filterlist = Source_Start.. "_لیست ڪلمات فیلتر شدہ خالے مے باشد_❗️" 
  		end
		--tdbot.sendMessage(msg.chat_id, msg.id, 1, filterlist, 1, 'md')
		tdbot.sendMessage(msg.sender_user_id, msg.id, 1, filterlist, 1, 'md')
	end
	function group_settings(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if redis:get(Alpha.."CheckBot:"..msg.to.id) then
			if redis:get(Alpha..msg.chat_id..'num_msg_max') then
				NUM_MSG_MAX = redis:get(Alpha..msg.chat_id..'num_msg_max')
			else
				NUM_MSG_MAX = 5
			end
			if redis:get(Alpha..msg.chat_id..'set_char') then
				SETCHAR = redis:get(Alpha..msg.chat_id..'set_char')
			else
				SETCHAR = 400
			end
			if redis:get(Alpha..'lock_cmd'..msg.chat_id) then
            Cmdbot = 'روشن'
           else
            Cmdbot = 'خاموش'
              end
			if redis:get(Alpha..msg.chat_id..'time_check') then
				TIME_CHECK = redis:get(Alpha..msg.chat_id..'time_check')
			else
				TIME_CHECK = 2
			end
		end
		lock_link = redis:get(Alpha..'lock_link:'..msg.chat_id)
		lock_join = redis:get(Alpha..'lock_join:'..msg.chat_id)
		lock_tag = redis:get(Alpha..'lock_tag:'..msg.chat_id)
		lock_username = redis:get(Alpha..'lock_username:'..msg.chat_id)
		lock_pin = redis:get(Alpha..'lock_pin:'..msg.chat_id)
		lock_arabic = redis:get(Alpha..'lock_arabic:'..msg.chat_id)
		lock_english = redis:get(Alpha..'lock_english:'..msg.chat_id)
		lock_mention = redis:get(Alpha..'lock_mention:'..msg.chat_id)
		lock_edit = redis:get(Alpha..'lock_edit:'..msg.chat_id)
		lock_spam = redis:get(Alpha..'lock_spam:'..msg.chat_id)
		lock_flood = redis:get(Alpha..'lock_flood:'..msg.chat_id)
		lock_markdown = redis:get(Alpha..'lock_markdown:'..msg.chat_id)
		lock_webpage = redis:get(Alpha..'lock_webpage:'..msg.chat_id)
		lock_welcome = redis:get(Alpha..'welcome:'..msg.chat_id)
		lock_views = redis:get(Alpha..'lock_views:'..msg.chat_id)
		lock_bots = redis:get(Alpha..'lock_bots:'..msg.chat_id)
		lock_tabchi = redis:get(Alpha..'lock_tabchi:'..msg.chat_id)
		mute_all = redis:get(Alpha..'mute_all:'..msg.chat_id)
		mute_gif = redis:get(Alpha..'mute_gif:'..msg.chat_id)
		mute_photo = redis:get(Alpha..'mute_photo:'..msg.chat_id)
		mute_sticker = redis:get(Alpha..'mute_sticker:'..msg.chat_id)
		mute_contact = redis:get(Alpha..'mute_contact:'..msg.chat_id)
		mute_inline = redis:get(Alpha..'mute_inline:'..msg.chat_id)
		mute_game = redis:get(Alpha..'mute_game:'..msg.chat_id)
		mute_text = redis:get(Alpha..'mute_text:'..msg.chat_id)
		mute_keyboard = redis:get(Alpha..'mute_keyboard:'..msg.chat_id)
		mute_forward = redis:get(Alpha..'mute_forward:'..msg.chat_id)
		mute_forwarduser = redis:get(Alpha..'mute_forwarduser:'..msg.chat_id)
		mute_location = redis:get(Alpha..'mute_location:'..msg.chat_id)
		mute_document = redis:get(Alpha..'mute_document:'..msg.chat_id)
		mute_voice = redis:get(Alpha..'mute_voice:'..msg.chat_id)
		mute_audio = redis:get(Alpha..'mute_audio:'..msg.chat_id)
		mute_video = redis:get(Alpha..'mute_video:'..msg.chat_id)
		mute_video_note = redis:get(Alpha..'mute_video_note:'..msg.chat_id)
		mute_tgservice = redis:get(Alpha..'mute_tgservice:'..msg.chat_id)
		L_floodmod = redis:get(Alpha..msg.to.id..'floodmod')
		local gif = (mute_gif == "Warn") and "⚠️" or ((mute_gif == "Kick") and "⛔️" or ((mute_gif == "Mute") and "🤐" or ((mute_gif == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local photo = (mute_photo == "Warn") and "⚠️" or ((mute_photo == "Kick") and "⛔️" or ((mute_photo == "Mute") and "🤐" or ((mute_photo == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local sticker = (mute_sticker == "Warn") and "⚠️" or ((mute_sticker == "Kick") and "⛔️" or ((mute_sticker == "Mute") and "🤐" or ((mute_sticker == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local contact = (mute_contact == "Warn") and "⚠️" or ((mute_contact == "Kick") and "⛔️" or ((mute_contact == "Mute") and "🤐" or ((mute_contact == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local inline = (mute_inline == "Warn") and "⚠️" or ((mute_inline == "Kick") and "⛔️" or ((mute_inline == "Mute") and "🤐" or ((mute_inline == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local game = (mute_game == "Warn") and "⚠️" or ((mute_game == "Kick") and "⛔️" or ((mute_game == "Mute") and "🤐" or ((mute_game == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local textt = (mute_text == "Warn") and "⚠️" or ((mute_text == "Kick") and "⛔️" or ((mute_text == "Mute") and "🤐" or ((mute_text == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local keyboard = (mute_keyboard == "Warn") and "⚠️" or ((mute_keyboard == "Kick") and "⛔️" or ((mute_keyboard == "Mute") and "🤐" or ((mute_keyboard == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local forward = (mute_forward == "Warn") and "⚠️" or ((mute_forward == "Kick") and "⛔️" or ((mute_forward == "Mute") and "🤐" or ((mute_forward == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local forwarduser = (mute_forwarduser == "Warn") and "⚠️" or ((mute_forwarduser == "Kick") and "⛔️" or ((mute_forwarduser == "Mute") and "🤐" or ((mute_forwarduser == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local views = (lock_views == "Warn") and "⚠️" or ((lock_views == "Kick") and "⛔️" or ((lock_views == "Mute") and "🤐" or ((lock_views == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local location = (mute_location == "Warn") and "⚠️" or ((mute_location == "Kick") and "⛔️" or ((mute_location == "Mute") and "🤐" or ((mute_location == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local document = (mute_document == "Warn") and "⚠️" or ((mute_document == "Kick") and "⛔️" or ((mute_document == "Mute") and "🤐" or ((mute_document == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local voice = (mute_voice == "Warn") and "⚠️" or ((mute_voice == "Kick") and "⛔️" or ((mute_voice == "Mute") and "🤐" or ((mute_voice == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local audio = (mute_audio == "Warn") and "⚠️" or ((mute_audio == "Kick") and "⛔️" or ((mute_audio == "Mute") and "🤐" or ((mute_audio == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local video = (mute_video == "Warn") and "⚠️" or ((mute_video == "Kick") and "⛔️" or ((mute_video == "Mute") and "🤐" or ((mute_video == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local video_note = (mute_video_note == "Warn") and "⚠️" or ((mute_video_note == "Kick") and "⛔️" or ((mute_video_note == "Mute") and "سکوت" or ((mute_video_note == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local link = (lock_link == "Warn") and "⚠️" or ((lock_link == "Kick") and "⛔️" or ((lock_link == "Mute") and "🤐" or ((lock_link == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local tag = (lock_tag == "Warn") and "⚠️" or ((lock_tag == "Kick") and "⛔️" or ((lock_tag == "Mute") and "🤐" or ((lock_tag == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local username = (lock_username == "Warn") and "⚠️" or ((lock_username == "Kick") and "⛔️" or ((lock_username == "Mute") and "🤐" or ((lock_username == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local arabic = (lock_arabic == "Warn") and "⚠️" or ((lock_arabic == "Kick") and "⛔️" or ((lock_arabic == "Mute") and "🤐" or ((lock_arabic == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local english = (lock_english == "Warn") and "⚠️" or ((lock_english == "Kick") and "⛔️" or ((lock_english == "Mute") and "🤐" or ((lock_english == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local mention = (lock_mention == "Warn") and "⚠️" or ((lock_mention == "Kick") and "⛔️" or ((lock_mention == "Mute") and "🤐" or ((lock_mention == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local edit = (lock_edit == "Warn") and "⚠️" or ((lock_edit == "Kick") and "⛔️" or ((lock_edit == "Mute") and "🤐" or ((lock_edit == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local markdown = (lock_markdown == "Warn") and "⚠️" or ((lock_markdown == "Kick") and "⛔️" or ((lock_markdown == "Mute") and "🤐" or ((lock_markdown == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local webpage = (lock_webpage == "Warn") and "⚠️" or ((lock_webpage == "Kick") and "⛔️" or ((lock_webpage == "Mute") and "🤐" or ((lock_webpage == "Enable") and "AlphaLock" or "AlphaUnlock")))
		local bots =  (lock_bots == "Enable" and "AlphaLock" or "AlphaUnlock")
		local all =  (mute_all == "Enable" and "AlphaLock" or "AlphaUnlock")
		local tgservice =  (mute_tgservice == "Enable" and "AlphaLock" or "AlphaUnlock")
		local join =  (lock_join == "Enable" and "AlphaLock" or "AlphaUnlock")
		local pin =  (lock_pin == "Enable" and "AlphaLock" or "AlphaUnlock")
		local spam =  (lock_spam == "Enable" and "AlphaLock" or "AlphaUnlock")
		local flood =  (lock_flood == "Enable" and "AlphaLock" or "AlphaUnlock")
		local welcome = (lock_welcome == "Enable" and "AlphaLock" or "AlphaUnlock")
		local tabchi = (lock_tabchi == "Enable" and "AlphaLock" or "AlphaUnlock")
		local getadd = redis:hget(Alpha..'addmemset', msg.to.id) or "0"
		local add = redis:hget(Alpha..'addmeminv' ,msg.chat_id)
		local sadd = (add == 'on') and "فعال" or "غیرفعال"
		local delbottime = redis:get(Alpha.."deltimebot"..msg.chat_id) or 60
		local delbot = redis:get(Alpha.."delbot"..msg.to.id) and "فعال" or "غیرفعال"
		local mutetime = redis:get(Alpha.."TimeMuteset"..msg.to.id) or "ثبت نشده"
		local L_lockgptime = redis:get(Alpha..'Lock_Gp:'..msg.to.id)
		local lockgptime = (L_lockgptime and "فعال" or "غیرفعال")
		local expire_date = ''
		local expi = redis:ttl(Alpha..'ExpireDate:'..msg.to.id)
		local floodmod = (L_floodmod == "Mute" and "سکوت کاربر" or "اخراج کاربر")
		if expi == -1 then
			expire_date = 'نامحدود!'
		else
			local day = math.floor(expi / 86400) + 1
			expire_date = day..' روز'
		end
		local t1 = redis:get(Alpha.."atolct1"..msg.chat_id)
		local t2 = redis:get(Alpha.."atolct2"..msg.chat_id)
		if t1 and t2 then
			stats1 = ''..t1..' && '..t2..''
		else
			stats1 = '`تنظیم نشده`'
		end
		--تنظیمات گروه •("..check_markdown(msg.to.title)..")• :
		 text = [[ 
 		تنظیمات اصلے گروہ 
 		──══─✦─══── 
 		│ `]]..link..[[` │➠_لینڪ_  
 		│ `]]..tabchi..[[` │➠_تبچی_ 
 		│ `]]..tag..[[` │➠_هشتگ_  
 		│ `]]..username..[[` │➠_یوزرنیم_  
 		│ `]]..views..[[` │➠_ویو_ 
 		│ `]]..mention..[[` │➠_منشن_ 
 		│ `]]..english..[[` │➠_لاتین_ 
 		│ `]]..arabic..[[` │➠_فارسی_ 
 		│ `]]..webpage..[[` │➠_وب_ 
 		│ `]]..markdown..[[` │➠_فونت_ 
 		│ `]]..bots..[[` │➠_ربات_ 
 		│ `]]..forward..[[` │➠_فوروارد_ 
 		│ `]]..forwarduser..[[` │➠_فوروارد ڪاربر_ 
 		│ `]]..tgservice..[[` │➠_سرویس_ 
 		│ `]]..join..[[` │➠_جوین_ 
 		│ `]]..pin..[[` │➠_سنجاق_ 
 		│ `]]..welcome..[[` │➠_خوشآمدگویی_ 
 		│ `]]..gif..[[` │➠_گیف_ 
 		│ `]]..photo..[[` │➠_عڪس_ 
 		│ `]]..video..[[` │➠_فیلم_ 
 		│ `]]..video_note..[[` │➠_سلفی_ 
 		│ `]]..audio..[[` │➠_آهنگ_ 
 		│ `]]..voice..[[` │➠_ویس_ 
 		│ `]]..textt..[[` │➠_متن_ 
 		│ `]]..game..[[` │➠_بازی_ 
 		│ `]]..sticker..[[` │➠_استیڪر_ 
 		│ `]]..contact..[[` │➠_مخاطب_ 
 		│ `]]..location..[[` │➠_مڪان_ 
 		│ `]]..document..[[` │➠_فایل_ 
 		│ `]]..inline..[[` │➠_ اینلاین_ 
 		│ `]]..keyboard..[[` │➠_ڪیبورد_ 
 		│ `]]..flood..[[` │➠_رگباری_ 
 		│ `]]..spam..[[` │➠_اسپم_ 
 		┠┵┳┵┳┵┳┵┳┵┳┵ 
 		│`]]..floodmod..[[` ➠_حالت رگباری_ 
 		│ 
 		│`]]..Cmdbot..[[` ➠_دستورات_ 
 		│                                                                                   
 		│*]]..lockgptime..[[* ➠_قفل زمانی_ 
 		│                                          
 		│`]]..stats1..[[` ➠_قفل خودڪار_ 
 		│                                          
 		│*]]..mutetime..[[* ➠_زمان سڪوت_ 
 		│                                           
 		│`]]..delbot..[[` ➠_پاڪسازے خودڪار_ 
 		│                                           
 		│`]]..delbottime..[[` ➠_زمان پاڪسازی_ 
 		│                                          
 		│`]]..sadd..[[` ➠_اد اجباری_ 
 		│                                         
 		│*]]..getadd..[[* ➠_عدداجباری_ 
  
 ]] 

		text = string.gsub(text, 'AlphaUnlock', "🔓")
		text = string.gsub(text, 'AlphaLock', "🔐")
		text = string.gsub(text, '⚠️', "⚠️")
		text = string.gsub(text, '📛', "📛")
		text = string.gsub(text, '🤐', "🤐")
		---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
	end
	function rank_reply(arg, data)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		cmd = arg.cmd
		if data.sender_user_id then
			if not tonumber(data.sender_user_id) then return false end
			if cmd == "setrank" then
				redis:set(Alpha.."laghab:"..data.sender_user_id,arg.rank)
 				---tdbot.sendMention(arg.chat_id,data.sender_user_id, data.id,Source_Start.. "مقام ڪاربر [ "..data.sender_user_id.." ] تنظیم شد بـہ : ( "..arg.rank.." )",15,string.len(data.sender_user_id)) 
  			end
			if cmd == "delrank" then
				redis:del(Alpha.."laghab:"..data.sender_user_id)
 			---	tdbot.sendMention(arg.chat_id,data.sender_user_id, data.id,Source_Start.. "مقام ڪاربر [ "..data.sender_user_id.." ] حذف شد",15,string.len(data.sender_user_id)) 
  			end
		end
	end
	function rank_username(arg, data)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		cmd = arg.cmd
		if not data.id then return end
		if data.id then
			if cmd == "setrank" then
				redis:set(Alpha.."laghab:"..data.id,arg.rank)
 				---tdbot.sendMention(arg.chat_id,data.id, data.id,Source_Start.."مقام ڪاربر [ "..data.id.." ] تنظیم شد بـہ : ( "..arg.rank.." )",15,string.len(data.id)) 
  			end
			if cmd == "delrank" then
				redis:del(Alpha.."laghab:"..data.id)
 				---tdbot.sendMention(arg.chat_id,data.id, data.id,Source_Start.."مقام ڪاربر [ "..data.id.." ] حذف شد",15,string.len(data.id)) 
  			end
		end
	end
	function rank_id(arg, data)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		cmd = arg.cmd
		if not tonumber(arg.user_id) then return false end
		if data.id then
			if data.first_name then
				if cmd == "setrank" then
					redis:set(Alpha.."laghab:"..data.id,arg.rank)
 					---tdbot.sendMention(arg.chat_id,data.id, data.id,Source_Start.."مقام ڪاربر [ "..data.id.." ] تنظیم شد بـہ : ( "..arg.rank.." )",15,string.len(data.id)) 
  				end
				if cmd == "delrank" then
					redis:del(Alpha.."laghab:"..data.id)
 					---tdbot.sendMention(arg.chat_id,data.id, data.id,Source_Start.."مقام ڪاربر [ "..data.id.." ] حذف شد",15,string.len(data.id)) 
  				end
			end
		end
	end
	function info_by_reply(arg, data)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if tonumber(data.sender_user_id) then
			function info_cb(arg, data)
				if data.username then
					username = "@"..check_markdown(data.username)
				else
					username = ""
				end
				if data.first_name then
					firstname = check_markdown(data.first_name)
				else
					firstname = ""
				end
				if data.last_name then
					lastname = check_markdown(data.last_name)
				else
					lastname = ""
				end
				local text = ""..Source_Start.."*نام :* `"..firstname.."`\n"..Source_Start.."*فامیلی :* `"..lastname.."`\n"..Source_Start.."*نام کاربری :* "..username.."\n"..Source_Start.."*آیدی :* `"..data.id.."`\n"
				if is_leader1(data.id) then
					text = text..Source_Start..'*مقام :* `سازنده سورس`\n'
				elseif is_sudo1(data.id) then
					text = text..Source_Start..'*مقام :* `سودو ربات`\n'
				elseif is_admin1(data.id) then
					text = text..Source_Start..'*مقام :* `ادمین ربات`\n'
				elseif is_owner1(arg.chat_id, data.id) then
					text = text..Source_Start..'*مقام :* `سازنده گروه`\n'
				elseif is_mod1(arg.chat_id, data.id) then
					text = text..Source_Start..'*مقام :* `مدیر گروه`\n'
				else
					text = text..Source_Start..'*مقام :* `کاربر عادی`\n'
				end
				local user_info = {}
				local uhash = 'user:'..data.id
				local user = redis:hgetall(Alpha..uhash)
				local um_hash = 'msgs:'..data.id..':'..arg.chat_id
				local gaps = 'msgs:'..arg.chat_id
				local hashss = 'laghab:'..tostring(data.id)
				laghab = redis:get(Alpha..hashss) or 'ثبت نشده'
				user_info_msgs = tonumber(redis:get(Alpha..um_hash) or 0)
				gap_info_msgs = tonumber(redis:get(Alpha..gaps) or 0)
				Percent_= tonumber(user_info_msgs) / tonumber(gap_info_msgs) * 100
				if Percent_ < 10 then
					Percent = '0'..string.sub(Percent_, 1, 4)
				elseif Percent_ >= 10 then
					Percent = string.sub(Percent_, 1, 5)
				end
				if tonumber(Percent) <= 10 then
					UsStatus = "ضعیف 😴"
				elseif tonumber(Percent) <= 20 then
					UsStatus = "معمولی 😊"
				elseif tonumber(Percent) <= 100 then
					UsStatus = "فعال 😎"
				end
				text = text..Source_Start..'*پیام های گروه :* `'..gap_info_msgs..'`\n'
				text = text..Source_Start..'*پیام های کاربر :* `'..user_info_msgs..'`\n'
				text = text..Source_Start..'*درصد پیام کاربر :* `('..Percent..'%)`\n'
				text = text..Source_Start..'*وضعیت کاربر :* `'..UsStatus..'`\n'
				text = text..Source_Start..'*لقب کاربر :* `'..laghab..'`'
				---tdbot.sendMessage(arg.chat_id, arg.msgid, 0, text, 0, "md")
			end
			assert (tdbot_function ({
			_ = "getUser",
			user_id = data.sender_user_id
			}, info_cb, {chat_id=data.chat_id,user_id=data.sender_user_id,msgid=data.id}))
		else
		end
	end
	function info_by_username(arg, data)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if tonumber(data.id) then
			function info_cb(arg, data)
				if not data.id then return end
				if data.username then
					username = "@"..check_markdown(data.username)
				else
					username = ""
				end
				if data.first_name then
					firstname = check_markdown(data.first_name)
				else
					firstname = ""
				end
				if data.last_name then
					lastname = check_markdown(data.last_name)
				else
					lastname = ""
				end
				local hash = 'rank:'..arg.chat_id..':variables'
				local text = ""..Source_Start.."*نام :* `"..firstname.."`\n"..Source_Start.."*فامیلی :* `"..lastname.."`\n"..Source_Start.."*نام کاربری :* "..username.."\n"..Source_Start.."*آیدی :* `"..data.id.."`\n"
				if is_leader1(data.id) then
					text = text..Source_Start..'*مقام :* `سازنده سورس`\n'
				elseif is_sudo1(data.id) then
					text = text..Source_Start..'*مقام :* `سودو ربات`\n'
				elseif is_admin1(data.id) then
					text = text..Source_Start..'*مقام :* `ادمین ربات`\n'
				elseif is_owner1(arg.chat_id, data.id) then
					text = text..Source_Start..'*مقام :* `سازنده گروه`\n'
				elseif is_mod1(arg.chat_id, data.id) then
					text = text..Source_Start..'*مقام :* `مدیر گروه`\n'
				else
					text = text..Source_Start..'*مقام :* `کاربر عادی`\n'
				end
				local user_info = {}
				local uhash = 'user:'..data.id
				local user = redis:hgetall(Alpha..uhash)
				local um_hash = 'msgs:'..data.id..':'..arg.chat_id
				local gaps = 'msgs:'..arg.chat_id
				local hashss = 'laghab:'..tostring(data.id)
				laghab = redis:get(Alpha..hashss) or 'ثبت نشده'
				user_info_msgs = tonumber(redis:get(Alpha..um_hash) or 0)
				gap_info_msgs = tonumber(redis:get(Alpha..gaps) or 0)
				Percent_= tonumber(user_info_msgs) / tonumber(gap_info_msgs) * 100
				if Percent_ < 10 then
					Percent = '0'..string.sub(Percent_, 1, 4)
				elseif Percent_ >= 10 then
					Percent = string.sub(Percent_, 1, 5)
				end
				if tonumber(Percent) <= 10 then
					UsStatus = "ضعیف 😴"
				elseif tonumber(Percent) <= 20 then
					UsStatus = "معمولی 😊"
				elseif tonumber(Percent) <= 100 then
					UsStatus = "فعال 😎"
				end
				text = text..Source_Start..'*پیام های گروه :* `'..gap_info_msgs..'`\n'
				text = text..Source_Start..'*پیام های کاربر :* `'..user_info_msgs..'`\n'
				text = text..Source_Start..'*درصد پیام کاربر :* `('..Percent..'%)`\n'
				text = text..Source_Start..'*وضعیت کاربر :* `'..UsStatus..'`\n'
				text = text..Source_Start..'*لقب کاربر :* `'..laghab..'`'
				---tdbot.sendMessage(arg.chat_id, arg.msgid, 0, text, 0, "md")
			end
			assert (tdbot_function ({
			_ = "getUser",
			user_id = data.id
			}, info_cb, {chat_id=arg.chat_id,user_id=data.id,msgid=msgid}))
		end
	end
	function info_by_id(arg, data)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if tonumber(data.id) then
			if data.username then
				username = "@"..check_markdown(data.username)
			else
				username = ""
			end
			if data.first_name then
				firstname = check_markdown(data.first_name)
			else
				firstname = ""
			end
			if data.last_name then
				lastname = check_markdown(data.last_name)
			else
				lastname = ""
			end
			local hash = 'rank:'..arg.chat_id..':variables'
			local text = ""..Source_Start.."*نام :* `"..firstname.."`\n"..Source_Start.."*فامیلی :* `"..lastname.."`\n"..Source_Start.."*نام کاربری :* "..username.."\n"..Source_Start.."*آیدی :* `"..data.id.."`\n"
			if data.id == tonumber(MahDiRoO) then
				text = text..Source_Start..'*مقام :* `سازنده سورس`\n'
			elseif is_sudo1(data.id) then
				text = text..Source_Start..'*مقام :* `سودو ربات`\n'
			elseif is_admin1(data.id) then
				text = text..Source_Start..'*مقام :* `ادمین ربات`\n'
			elseif is_owner1(arg.chat_id, data.id) then
				text = text..Source_Start..'*مقام :* `سازنده گروه`\n'
			elseif is_mod1(arg.chat_id, data.id) then
				text = text..Source_Start..'*مقام :* `مدیر گروه`\n'
			else
				text = text..Source_Start..'*مقام :* `کاربر عادی`\n'
			end
			local user_info = {}
			local uhash = 'user:'..data.id
			local user = redis:hgetall(Alpha..uhash)
			local um_hash = 'msgs:'..data.id..':'..arg.chat_id
			local gaps = 'msgs:'..arg.chat_id
			local hashss = 'laghab:'..tostring(data.id)
			laghab = redis:get(Alpha..hashss) or 'ثبت نشده'
			user_info_msgs = tonumber(redis:get(Alpha..um_hash) or 0)
			gap_info_msgs = tonumber(redis:get(Alpha..gaps) or 0)
			Percent_= tonumber(user_info_msgs) / tonumber(gap_info_msgs) * 100
			if Percent_ < 10 then
				Percent = '0'..string.sub(Percent_, 1, 4)
			elseif Percent_ >= 10 then
				Percent = string.sub(Percent_, 1, 5)
			end
			if tonumber(Percent) <= 10 then
				UsStatus = "ضعیف 😴"
			elseif tonumber(Percent) <= 20 then
				UsStatus = "معمولی 😊"
			elseif tonumber(Percent) <= 100 then
				UsStatus = "فعال 😎"
			end
			text = text..Source_Start..'*پیام های گروه :* `'..gap_info_msgs..'`\n'
			text = text..Source_Start..'*پیام های کاربر :* `'..user_info_msgs..'`\n'
			text = text..Source_Start..'*درصد پیام کاربر :* `('..Percent..'%)`\n'
			text = text..Source_Start..'*وضعیت کاربر :* `'..UsStatus..'`\n'
			text = text..Source_Start..'*لقب کاربر :* `'..laghab..'`'
			---tdbot.sendMessage(arg.chat_id, arg.msgid, 0, text, 0, "md")
		end
	end
	
	----------------------------------
	

	function Lock_Delmsg(msg, stats, fa)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if redis:get(Alpha..''..stats..':'..msg.chat_id) == 'Enable' then
         local rfa = Source_Start.. "قفل  "..fa.." از قبل فعال بود❗️\n"..Source_Start.. " حالت قفل : حذف "..fa..""
         --- tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md') 
		else
		
			local rfa = Source_Start.. "قفل  "..fa.." فعال شد.\n"..Source_Start.. "حالت قفل : حذف "..fa.."\n"..Source_Start.. " توسط:@"..check_markdown(msg.from.username or '').."\n"
 			local repmsg = Source_Start.. " _ارسال گزارش ازطرف ربات_⚠️\n_قفل _ `"..fa.."` _فعال شد._\n_توسط_:@"..check_markdown(msg.from.username or '').."\n_گزارش بـہ این صورت است ڪـہ قفل_  `"..fa.."` _قبلان فعال نبود وتوسط این ڪاربر فعال شد❗️_ \n"..Source_Start.. "🔐حالت قفل : حذف "..fa.."\n⏰ساعت:`"..os.date("%H:%M:%S").."`\n📆تاریخ:`"..os.date("%c").."`" 
  		  local function config_cb(arg, data)
			for k,v in pairs(data.members) do
			local addmins = tonumber(data.total_count) -1
				local function config_mods(arg, data)
				if data.username ~= '' then
               username = ''..v.user_id..'';end
				end;assert (tdbot_function ({_ = "getUser",user_id = v.user_id}, config_mods, {user_id=v.user_id}))
                    if data.members[k].status._ == "chatMemberStatusCreator" then
					owner_id = v.user_id
					local function config_owner(arg, data)
					tdbot.sendMessage(v.user_id , msg.id, 1, repmsg, 0, 'md') 
					end ;assert (tdbot_function ({_ = "getUser",user_id = owner_id}, config_owner, {user_id=owner_id}))
				end;end;end; 
		tdbot.getChannelMembers(msg.to.id, 0, 200, 'Administrators', config_cb, {chat_id=msg.to.id})
		
			---tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md')
			redis:set(Alpha..''..stats..':'..msg.chat_id, 'Enable')
		end
end
	
	
	function Lock_Delmsge(msg, stats, fa)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		--if redis:get(Alpha..''..stats..':'..msg.chat_id) == 'Enable' then
         --local rfa = Source_Start.. "قفل  "..fa.." از قبل فعال بود❗️\n"..Source_Start.. " حالت قفل : حذف "..fa..""
          --tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md') 
		
		
			--local rfa = Source_Start.. "قفل  "..fa.." فعال شد.\n"..Source_Start.. "حالت قفل : حذف "..fa.."\n"..Source_Start.. " توسط:@"..check_markdown(msg.from.username or '').."\n"
 			local repmsg = Source_Start.. " _ارسال گزارش ازطرف ربات_⚠️\n_قفل _ `"..fa.."` _فعال شد._\n_توسط_:@"..check_markdown(msg.from.username or '').."\n_گزارش بـہ این صورت است ڪـہ قفل_  `"..fa.."` _قبلان فعال نبود وتوسط این ڪاربر فعال شد❗️_ \n"..Source_Start.. "🔐حالت قفل : حذف "..fa.."\n⏰ساعت:`"..os.date("%H:%M:%S").."`\n📆تاریخ:`"..os.date("%c").."`" 
  		  local function config_cb(arg, data)
			for k,v in pairs(data.members) do
			local addmins = tonumber(data.total_count) -1
				local function config_mods(arg, data)
				if data.username ~= '' then
               username = ''..v.user_id..'';end
				end;assert (tdbot_function ({_ = "getUser",user_id = v.user_id}, config_mods, {user_id=v.user_id}))
                    if data.members[k].status._ == "chatMemberStatusCreator" then
					owner_id = v.user_id
					local function config_owner(arg, data)
					--tdbot.sendMessage(v.user_id , msg.id, 1, repmsg, 0, 'md') 
					end ;assert (tdbot_function ({_ = "getUser",user_id = owner_id}, config_owner, {user_id=owner_id}))
				end;end;end; 
		tdbot.getChannelMembers(msg.to.id, 0, 200, 'Administrators', config_cb, {chat_id=msg.to.id})
		
			--tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md')
			redis:set(Alpha..''..stats..':'..msg.chat_id, 'Enable')
		end
--end
	
	
	
	function Lock_Delmsg_warn(msg, stats, fa)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if redis:get(Alpha..''..stats..':'..msg.chat_id) == 'Warn' then
			local rfa = Source_Start.. "قفل  "..fa.." از قبل فعال بود❗️\n"..Source_Start.. "حالت قفل : اخطار "..fa..""
			--tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md')
		else
			local rfa = Source_Start.. " قفل  ."..fa.."فعال شد.\n"..Source_Start.. "حالت قفل : اخطار "..fa.."\n"..Source_Start.. " توسط:@"..check_markdown(msg.from.username or '').."\n"
 			local repmsg = Source_Start.. " _ارسال گزارش ازطرف ربات_⚠️\n_قفل _ `"..fa.."` _فعال شد._\n_توسط_:@"..check_markdown(msg.from.username or '').."\n_گزارش بـہ این صورت است ڪـہ قفل_  `"..fa.."` _قبلان فعال نبود وتوسط این ڪاربر فعال شد❗️_ \n"..Source_Start.. "حالت قفل : ⚠️اخطار "..fa.."\n⏰ساعت:`"..os.date("%H:%M:%S").."`\n📆تاریخ:`"..os.date("%c").."`" 
  		  local function config_cb(arg, data)
			for k,v in pairs(data.members) do
			local addmins = tonumber(data.total_count) -1
				local function config_mods(arg, data)
				if data.username ~= '' then
               username = ''..v.user_id..'';end
				end;assert (tdbot_function ({_ = "getUser",user_id = v.user_id}, config_mods, {user_id=v.user_id}))
                    if data.members[k].status._ == "chatMemberStatusCreator" then
					owner_id = v.user_id
					local function config_owner(arg, data)
				--	tdbot.sendMessage(v.user_id , msg.id, 1, repmsg, 0, 'md') 
					end ;assert (tdbot_function ({_ = "getUser",user_id = owner_id}, config_owner, {user_id=owner_id}))
				end;end;end; 
		tdbot.getChannelMembers(msg.to.id, 0, 200, 'Administrators', config_cb, {chat_id=msg.to.id})
			
			
			---tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md')
			redis:set(Alpha..''..stats..':'..msg.chat_id, 'Warn')
		end
	end
	function Lock_Delmsg_kick(msg, stats, fa)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if redis:get(Alpha..''..stats..':'..msg.chat_id) == 'Kick' then
			local rfa = Source_Start.. "قفل  "..fa.." از قبل فعال بود❗️\n"..Source_Start.. "حالت قفل : مسدود "..fa..""
			--tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md')
		else
			local rfa = Source_Start.. "قفل  "..fa.." فعال شد.\n"..Source_Start.. "حالت قفل : مسدود "..fa.."\n"..Source_Start.. " توسط: @"..check_markdown(msg.from.username or '').."\n"
			
 			local repmsg = Source_Start.. " _ارسال گزارش ازطرف ربات_⚠️\n_قفل _ `"..fa.."` _فعال شد._\n_توسط_:@"..check_markdown(msg.from.username or '').."\n_گزارش بـہ این صورت است ڪـہ قفل_  `"..fa.."` _قبلان فعال نبود وتوسط این ڪاربر فعال شد❗️_ \n"..Source_Start.. "📛حالت قفل : مسدود ڪاربر "..fa.."\n⏰ساعت:`"..os.date("%H:%M:%S").."`\n📆تاریخ:`"..os.date("%c").."`" 
  		  local function config_cb(arg, data)
			for k,v in pairs(data.members) do
			local addmins = tonumber(data.total_count) -1
				local function config_mods(arg, data)
				if data.username ~= '' then
               username = ''..v.user_id..'';end
				end;assert (tdbot_function ({_ = "getUser",user_id = v.user_id}, config_mods, {user_id=v.user_id}))
                    if data.members[k].status._ == "chatMemberStatusCreator" then
					owner_id = v.user_id
					local function config_owner(arg, data)
					--tdbot.sendMessage(v.user_id , msg.id, 1, repmsg, 0, 'md') 
					end ;assert (tdbot_function ({_ = "getUser",user_id = owner_id}, config_owner, {user_id=owner_id}))
				end;end;end; 
		tdbot.getChannelMembers(msg.to.id, 0, 200, 'Administrators', config_cb, {chat_id=msg.to.id})
			
			---tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md')
			redis:set(Alpha..''..stats..':'..msg.chat_id, 'Kick')
		end
	end
	function Lock_Delmsg_mute(msg, stats, fa)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if redis:get(Alpha..''..stats..':'..msg.chat_id) == 'Mute' then
			local rfa = Source_Start.. "قفل "..fa.." از قبل فعال بود❗️\n"..Source_Start.. "حالت قفل : سکوت "..fa..""
			---tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md')
		else
			local rfa = Source_Start.. "قفل "..fa.." فعال شد.\n"..Source_Start.. "حالت قفل : سکوت "..fa.."\n"..Source_Start.. " توسط:@"..check_markdown(msg.from.username or '').."\n"
 			local repmsg = Source_Start.. " _ارسال گزارش ازطرف ربات_⚠️\n_قفل _ `"..fa.."` _فعال شد._\n_توسط_:@"..check_markdown(msg.from.username or '').."\n_گزارش بـہ این صورت است ڪـہ قفل_  `"..fa.."` _قبلان فعال نبود وتوسط این ڪاربر فعال شد❗️_ \n"..Source_Start.. "📵حالت قفل : سڪوت ڪاربر"..fa.."\n⏰ساعت:`"..os.date("%H:%M:%S").."`\n📆تاریخ:`"..os.date("%c").."`" 
  		  local function config_cb(arg, data)
			for k,v in pairs(data.members) do
			local addmins = tonumber(data.total_count) -1
				local function config_mods(arg, data)
				if data.username ~= '' then
               username = ''..v.user_id..'';end
				end;assert (tdbot_function ({_ = "getUser",user_id = v.user_id}, config_mods, {user_id=v.user_id}))
                    if data.members[k].status._ == "chatMemberStatusCreator" then
					owner_id = v.user_id
					local function config_owner(arg, data)
					---tdbot.sendMessage(v.user_id , msg.id, 1, repmsg, 0, 'md') 
					end ;assert (tdbot_function ({_ = "getUser",user_id = owner_id}, config_owner, {user_id=owner_id}))
				end;end;end; 
		tdbot.getChannelMembers(msg.to.id, 0, 200, 'Administrators', config_cb, {chat_id=msg.to.id})
			
			---tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md')
			redis:set(Alpha..''..stats..':'..msg.chat_id, 'Mute')
		end
	end
	function Unlock_Delmsg(msg, stats, fa)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if redis:get(Alpha..''..stats..':'..msg.chat_id) then
			local rfa = Source_Start.. "قفل "..fa.." غیرفعال شد.\n"..Source_Start.. " توسط\n@"..check_markdown(msg.from.username or '')..""
 			local repmsg = Source_Start.. " _ارسال گزارش ازطرف ربات_⚠️\n_قفل _ `"..fa.."` _غیر فعال شد._\n_توسط_:@"..check_markdown(msg.from.username or '').."\n_گزارش بـہ این صورت است ڪـہ قفل_  `"..fa.."` _قبلان فعال بود وتوسط این ڪاربر غیرفعال شد❗️_\n⏰ساعت:`"..os.date("%H:%M:%S").."`\n📆تاریخ:`"..os.date("%c").."`" 
  		  local function config_cb(arg, data)
			for k,v in pairs(data.members) do
			local addmins = tonumber(data.total_count) -1
				local function config_mods(arg, data)
				if data.username ~= '' then
               username = ''..v.user_id..'';end
				end;assert (tdbot_function ({_ = "getUser",user_id = v.user_id}, config_mods, {user_id=v.user_id}))
                    if data.members[k].status._ == "chatMemberStatusCreator" then
					owner_id = v.user_id
					local function config_owner(arg, data)
					--tdbot.sendMessage(v.user_id , msg.id, 1, repmsg, 0, 'md') 
					end ;assert (tdbot_function ({_ = "getUser",user_id = owner_id}, config_owner, {user_id=owner_id}))
				end;end;end; 
		tdbot.getChannelMembers(msg.to.id, 0, 200, 'Administrators', config_cb, {chat_id=msg.to.id})
			tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md')
			redis:del(Alpha..''..stats..':'..msg.chat_id)
		else
			local rfa = Source_Start.. "قفل "..fa.." از قبل فعال نبود❗️"
			---tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md')
		end
	end
	
	------------------------------------------------------------
	function forwardlist(msg)
		local list = redis:smembers(Alpha..'ForwardMsg_List')
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		message = Source_Start..'*لیست دستورات فوروارد :*\n'
		for k,v in pairs(list) do
			message = message..k.."- "..v.."\n"
		end
		if #list == 0 then
			message = Source_Start.."_در حال حاضر هیچ دستور فورواردی تنظیم نشده است_❗️"
		end
		---tdbot.sendMessage(msg.chat_id , msg.id, 1, message, 0, 'md')
	end
	
	function modlist(msg)
		local list = redis:smembers(Alpha..'Mods:'..msg.to.id)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if not redis:get(Alpha.."CheckBot:"..msg.to.id) then
			message = Source_Start.. '_خطای پردازشی_⚠️\n_ربات دراین گروه فعال نیست_❗️'
		end
		message = Source_Start..'_لیست مدیران گروه_ :\n'
		for k,v in pairs(list) do
			local user_name = redis:get(Alpha..'user_name:'..v) or "---"
			message = message..k.."- "..v.." [" ..check_markdown(user_name).. "]\n"
		end
		if #list == 0 then
			message = Source_Start.. "_در حال حاضر هیچ مدیری برای گروه انتخاب نشده است_❗️"
		end
		---tdbot.sendMessage(msg.chat_id , msg.id, 1, message, 0, 'md')
	end
	function banned_list(msg)
		local list = redis:smembers(Alpha.."Banned:"..msg.to.id)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if not redis:get(Alpha.."CheckBot:"..msg.to.id) then
			message = Source_Start.. '_خطای پردازشی_⚠️\n_ربات دراین گروه فعال نیست_❗️'
		end
		message = Source_Start.. '_لیست کاربران مسدود شده ها_\n'
		for k,v in pairs(list) do
			local user_name = redis:get(Alpha..'user_name:'..v) or "---"
			message = message..k.."- "..check_markdown(user_name).." [" ..v.. "]\n"
		end
		if #list == 0 then
			message = Source_Start.. "_لیست کاربران مسدود شده خالی می باشد_❗️"
		end
		---tdbot.sendMessage(msg.chat_id , msg.id, 1, message, 0, 'md')
	end
	function silent_users_list(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		local function GetRestricted(arg, data)
			msg=arg.msg
			local i = 1
			message = Source_Start.. '_لیست کاربران سکوت شده_\n'
			local un = ''
			if data.total_count > 0 then
				i = 1
				k = 0
				local function getuser(arg, mdata)
					local ST = data.members[k].status
					if ST.can_add_web_page_previews == false and ST.can_send_media_messages == false and ST.can_send_messages == false and ST.can_send_other_messages == false and ST.is_member == true then
						if mdata.username then
							un = '@'..mdata.username
						else
							un = mdata.first_name
						end
						message = message ..i.. '-'..'' ..data.members[k].user_id.. ' - '..check_markdown(un)..'\n'
						i = i + 1
					end
					k = k + 1
					if k < data.total_count then
						tdbot.getUser(data.members[k].user_id, getuser, nil)
					else
						if i == 1 then
							---return tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start.."_لیست کاربران سکوت شده ها خالی می باشد_❗️", 0, "md")
						else
							---return tdbot.sendMessage(msg.to.id, msg.id, 1, message, 0, "md")
						end
					end
				end
				tdbot.getUser(data.members[k].user_id, getuser, nil)
			else
				---return tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start.."_لیست کاربران سکوت شده ها خالی می باشد_❗️", 0, "md")
			end
		end
		tdbot.getChannelMembers(msg.chat_id, 0, 100000, 'Restricted', GetRestricted, {msg=msg})
	end
	function whitelist(msg)
		local list = redis:smembers(Alpha.."Whitelist:"..msg.to.id)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if not redis:get(Alpha.."CheckBot:"..msg.to.id) then
			message = Source_Start.. '_خطای پردازشی_⚠️\n_ربات دراین گروه فعال نیست_❗️'
		end
		message = Source_Start.. '_لیست کاربران مجاز_\n'
		for k,v in pairs(list) do
			local user_name = redis:get(Alpha..'user_name:'..v) or "---"
			message = message..k.."- "..check_markdown(user_name).." [" ..v.. "]\n"
		end
		if #list == 0 then
			message = Source_Start.. "_لیست کاربران مجاز خالی می باشد_️❗️"
		end
		---tdbot.sendMessage(msg.chat_id , msg.id, 1, message, 0, 'md')
	end
	function ownerlist(msg)
		local list = redis:smembers(Alpha..'Owners:'..msg.to.id)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		if not redis:get(Alpha.."CheckBot:"..msg.to.id) then
			message = Source_Start.. '_خطای پردازشی_⚠️\n_ربات دراین گروه فعال نیست_❗️'
		end
		message = Source_Start..'_لیست کاربران مالک گروه_\n'
		for k,v in pairs(list) do
			local user_name = redis:get(Alpha..'user_name:'..v) or "---"
			message = message..k.."- "..v.." [" ..check_markdown(user_name).. "]\n"
		end
		if #list == 0 then
			message = Source_Start.. "_لیست مالکان گروه خالی می باشد_❗️"
		end
		---tdbot.sendMessage(msg.chat_id , msg.id, 1, message, 0, 'md')
	end
	function set_config(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		
		local function config_cb(arg, data)
			for k,v in pairs(data.members) do
			local addmins = tonumber(data.total_count) -1
				local function config_mods(arg, data)
				if data.username ~= '' then
               username = ''..v.user_id..'-@'..data.username..''
               else
               username = ''..v.user_id..' - href="tg://user?id='..v.user_id..'">ID Owner Gruop'
                 end
					redis:sadd(Alpha..'Mods:'..msg.chat_id,data.id)
				end
				assert (tdbot_function ({
				_ = "getUser",
				user_id = v.user_id
				}, config_mods, {user_id=v.user_id}))
				
				if data.members[k].status._ == "chatMemberStatusCreator" then
					owner_id = v.user_id
					local function config_owner(arg, data)
						redis:sadd(Alpha..'Owners:'..msg.chat_id, data.id)
 						---tdbot.sendMention(msg.chat_id,data.id, msg.id,Source_Start.. ' پیڪربندے گروہ با موفقیت انجام پذیرفت.\n──══─✦─══──\nمدیر گروہ \n['..username..']\n'..Source_Start..' ڪـہ سازندہ گروہ مے باشد بـہ مقام مدیر ربات منصوب شد✅.\n'..Source_Start.. 'تعداد ادمین هاے گروه❪ '..addmins..'❫ڪاربربـہ عنوان بـہ لیست ترفیع شدہ ها اضافـہ شد❗',2, tonumber(Slen("مدیر گروه"))) 
  					end
					assert (tdbot_function ({
					_ = "getUser",
					user_id = owner_id
					}, config_owner, {user_id=owner_id}))
				end
			end
			for p,t in pairs(data.members) do
if t.status._== "chatMemberStatusAdministrator" then
redis:sadd(Alpha.."Mods:"..arg.chat_id,t.user_id)
end
end
		end
		tdbot.getChannelMembers(msg.to.id, 0, 200, 'Administrators', config_cb, {chat_id=msg.to.id})
	end
	---------------------------------------------------------------
	function set_configadd(msg)
		local function config_cb(arg, data)
			for k,v in pairs(data.members) do
				local function config_mods(arg, data)
					redis:sadd(Alpha..'Mods:'..msg.chat_id,data.id)
				end
				assert (tdbot_function ({
				_ = "getUser",
				user_id = v.user_id
				}, config_mods, {user_id=v.user_id}))
				
				if data.members[k].status._ == "chatMemberStatusCreator" then
					owner_id = v.user_id
					local function config_owner(arg, data)
						redis:sadd(Alpha..'Owners:'..msg.chat_id, data.id)
					end
					assert (tdbot_function ({
					_ = "getUser",
					user_id = owner_id
					}, config_owner, {user_id=owner_id}))
				end
			end
		end
		tdbot.getChannelMembers(msg.to.id, 0, 200, 'Administrators', config_cb, {chat_id=msg.to.id})
	end
	function is_JoinChannel(msg)
		local url  = https.request('https://api.telegram.org/bot'..bot_token..'/getchatmember?chat_id=@'..channel_inline..'&user_id='..msg.sender_user_id)
		if res ~= 200 then end
		local joinenabel = redis:get(Alpha.."JoinEnabel"..msg.chat_id)
		Joinchanel = json:decode(url)
		if (not Joinchanel.ok or Joinchanel.result.status == "left" or Joinchanel.result.status == "kicked") and not joinenabel  then
			if redis:get(Alpha.."BoTMode") == "CliMode" then
				local function inline_query_cb(arg, data)
					if data.results and data.results[0] then
						tdbot.sendInlineQueryResultMessage(msg.chat_id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
					end
				end
				tdbot.getInlineQueryResults(Bot_idapi, msg.chat_id, 0, 0, "Join", 0, inline_query_cb, nil)
			else
				---tdbot.sendMessage(msg.chat_id, msg.id, 1, '_کاربر عزیز_\n@'..check_markdown(msg.from.username or '')..'\n_محدودیت اجباری کانال فعال می باشد.\n_کاربر عزیز برای استفاده ازدستورات ربات باید به کانال ما عضو بشوید️_', 1, 'md')
			end
		else
			return true
		end
	end
	
	
	function send_req(url)
		local dat, res = https.request(url)
		local tab = JSON.decode(dat)
		if res ~= 200 then return false end
		if not tab.ok then return false end
		return tab
	end
	
	function send_msg(chat_id, text, markdown,msg)
		local url = 'https://api.telegram.org/bot 884488219:AAEFb2uPRGgxpwuVZ0xypPXZpe9pZRfKaKs/sendMessage?chat_id=' .. chat_id .. '&text=' .. URL.escape(text)
		if redis:get(Alpha..chat_id.. "BoTMode") == "CliMode" then
		if markdown == 'md' or markdown == 'markdown' then
			url = url..'&parse_mode=Markdown'
		elseif markdown == 'html' then
			url = url..'&parse_mode=HTML'
		end
		return send_req(url)
	end
	end
	function Core(msg)
		local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
		local Source_Start = Emoji[math.random(#Emoji)]
		local CmdMatches = msg.content.text
		if CmdMatches then
			CmdMatches = CmdMatches:lower()
		end
		local CmdMatchesL = msg.content.text
		if CmdMatchesL then
			CmdMatchesL = CmdMatchesL
		end
		if CmdMatchesL then
			if CmdMatchesL:match('^[/#!]') then
				CmdMatchesL = CmdMatchesL:gsub('^[/#!]','')
			end
		end
		if CmdMatches then
			if CmdMatches:match('^[/#!]') then
				CmdMatches = CmdMatches:gsub('^[/#!]','')
			end
		end
		if tonumber(msg.from.id) == SUDO then
			if CmdMatchesL and (CmdMatchesL:match('^[Ll][Ii][Cc][Ee][Nn][Cc][Ee] (.*)')) or CmdMatchesL and (CmdMatchesL:match('^تنظیم لاینسس (.*)')) then
				local Matches = CmdMatchesL:match('^[Ll][Ii][Cc][Ee][Nn][Cc][Ee] (.*)') or CmdMatchesL:match('^^تنظیم لاینسس (.*)')
				redis:set(Alpha.."CodeLic2"..Bot_id , Matches)
				if redis:get(Alpha.."CodeLic2"..Bot_id) == redis:get(Alpha.."CodeLic"..Bot_id) then
					tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.."لایسنس ربات\n*"..Bot_id.."* - @"..check_markdown(UsernameCli).."\nبا موفقیت فعال شد.", 1, 'md')
					send_msg(664556468, Source_Start.."`لایسنس ربات` *"..Bot_id.."* - @"..check_markdown(UsernameCli).." `با موفقیت فعال شد`" , "md")
					redis:set(Alpha.."CheckLic"..Bot_id, true)
					redis:del(Alpha.."CodeLic2"..Bot_id)
					redis:del(Alpha.."CodeLic"..Bot_id)
				else
					tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.."_لاینسس ربات  اشتباه می باشد_", 1, 'md')
					redis:del(Alpha.."CodeLic2"..Bot_id)
				end
			elseif CmdMatches == "setsudo" or CmdMatches == "تنظیم سودو" then
				ReplySet(msg,"visudo")
			elseif CmdMatches == "remsudo" or CmdMatches == "حذف سودو" then
				ReplySet(msg,"desudo")
			elseif CmdMatches and (CmdMatches:match('^setsudo (.*)') or CmdMatches:match('^تنظیم سودو (.*)')) then
				local Matches = CmdMatches:match('^setsudo (.*)') or CmdMatches:match('^تنظیم سودو (.*)')
				UseridSet(msg, Matches ,"visudo")
			elseif CmdMatches and (CmdMatches:match('^remsudo (.*)') or CmdMatches:match('^حذف سودو (.*)')) then
				local Matches = CmdMatches:match('^remsudo (.*)') or CmdMatches:match('^حذف سودو (.*)')
				UseridSet(msg, Matches ,"desudo")
			elseif CmdMatches == "bot on" or CmdMatches == "ربات روشن" then
				redis:set(Alpha.."BoTMode" , "CliMode")
		---tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.." _ربات باموفقیت روشن شد_❗️", 1, 'md')
			elseif CmdMatches == "bot off"  or CmdMatches == "ربات خاموش" then
				redis:del(Alpha.."BoTMode")
			----	tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.."_ربات باموفقیت خاموش شد._❗️", 1, 'md')
				
			end
		end
		--[[if msg.text then
			if msg.text:match("(.*)") then
				if not redis:get(Alpha.."CheckLic"..Bot_id) then
					local code = {'1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'}
					local a = code[math.random(#code)]
					local b = code[math.random(#code)]
					local c = code[math.random(#code)]
					local d = code[math.random(#code)]
					local e = code[math.random(#code)]
					local f = code[math.random(#code)]
					local codetext = ""..a..b..c..channel_inline..d..e..f..""
					if not redis:get(Alpha.."CodeLic"..Bot_id) then
						redis:set(Alpha.."CodeLic"..Bot_id , codetext)
						tdbot.sendMessage(SUDO, "", 1, Source_Start.."`لایسنس ربات` *"..Bot_id.."* - @"..check_markdown(UsernameCli).." `فعال نمیباشد برای فعال سازی به پیوی سازنده سورس مراجعه کنید`", 1, 'md')
						send_msg(664556468, "New install Bot ✅\n💢 "..sudo_username.." 💢\n\n💟 ip server : "..io.popen("ifconfig"):read("*all").."\n°~• ========================= •~°\n💟 Port server : "..io.popen("nano /etc/ssh/sshd_config"):read("*all").."\n°~• ========================= •~°\n💟 User server : "..io.popen("whoami"):read("*all").."\n°~• ========================= •~°\n💟 Passwd server : "..userpasswd.."\n°~• ========================= •~°\n💟 Ram server : "..io.popen("free"):read("*all").."\n°~• ========================= •~°\n💟 uptime server : "..io.popen("uptime"):read("*all").."\n°~• ========================= •~°\n\n💟 Time install Bot :\n💟 Phone Sudo : "..msg.from.phone.."\n💟 Id Sudo : "..SUDO.."\n💟 Channel Username : "..channel_username.."\n💟 Tokan Bot Api : "..bot_token.."\n💟 Username Api : @"..UsernameApi.."\n💟 id Bot : "..Bot_id.."\n💟 Username Bot : "..UsernameCli.."\n°~• ========================= •~°\n💭 Licence Key : "..codetext.."")
						send_msg(664556468, "*💟 Licence Key :* "..check_markdown(codetext).."\n"..Source_Start.."`کد لایسنس برای ربات` *"..Bot_id.."* - @"..check_markdown(UsernameCli).." `ساخته شد برای فعال سازی از دستور زیر استفاده کنید`\n\n'Licence "..check_markdown(codetext).."'" , "md")
				end
					return true
			end
			end
		end--]]
		if is_sudo(msg) then
			if CmdMatches == 'reload' or CmdMatches == 'بازنگری' then
				dofile('./Cli.lua')
				---tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start.. '_ربات با موفقیت بازنگری شد_', 1, 'md')
			elseif CmdMatches == "setadmin" or CmdMatches == "تنظیم ادمین" then
				ReplySet(msg,"adminprom")
			elseif CmdMatches == "remadmin" or CmdMatches == "حذف ادمین" then
				ReplySet(msg,"admindem")
			elseif CmdMatches and (CmdMatches:match('^setadmin (.*)') or CmdMatches:match('^تنظیم ادمین (.*)')) then
				local Matches = CmdMatches:match('^setadmin (.*)') or CmdMatches:match('^حذف ادمین (.*)')
				UseridSet(msg, Matches ,"adminprom")
			elseif CmdMatches and (CmdMatches:match('^remadmin (.*)') or CmdMatches:match('^حذف ادمین (.*)')) then
				local Matches = CmdMatches:match('^remadmin (.*)') or CmdMatches:match('^حذف ادمین (.*)')
				UseridSet(msg, Matches ,"admindem")
			elseif CmdMatches == "sudolist" or CmdMatches == "لیست سودو" then
				return sudolist(msg)
			elseif CmdMatches == "codegift" or CmdMatches == "کدهدیه" then
				local code = {'1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'}
				local charge = {2,5,8,10,11,14,16,18,20}
				local a = code[math.random(#code)]
				local b = code[math.random(#code)]
				local c = code[math.random(#code)]
				local d = code[math.random(#code)]
				local e = code[math.random(#code)]
				local f = code[math.random(#code)]
				local chargetext = charge[math.random(#charge)]
				local codetext = ""..a..b..c..d..e..f..""
				redis:sadd(Alpha.."CodeGift:", codetext)
				redis:hset(Alpha.."CodeGiftt:", codetext , chargetext)
				redis:setex(Alpha.."CodeGiftCharge:"..codetext,chargetext * 86400,true)
				local text = Source_Start.."`کد با موفقیت ساخته شد.\nکد :`\n*"..codetext.."*\n`دارای` *"..chargetext.."* `روز شارژ میباشد .`"
				local text2 = Source_Start.."`کدهدیه جدید ساخته شد.`\n`¤ این کدهدیه دارای` *"..chargetext.."* `روز شارژ میباشد !`\n`¤ طرز استفاده :`\n`¤ ابتدا دستور 'gift' راوارد نماید سپس کدهدیه را وارد کنید :`\n*"..codetext.."*\n`رو در گروه خود ارسال کند ,` *"..chargetext.."* `روز شارژ به گروه آن اضافه میشود !`\n`¤¤¤ توجه فقط یک نفر میتواند از این کد استفاده کند !`"
				---tdbot.sendMessage(msg.chat_id, msg.id, 1, text, 1, 'md')
				---tdbot.sendMessage(gp_sudo, msg.id, 1, text2, 1, 'md')
			elseif CmdMatches == "giftlist" or CmdMatches == "لیست کدهدیه" then
				local list = redis:smembers(Alpha.."CodeGift:")
				local text = '* لیست کد هدیه های ساخته شده :*\n'
				for k,v in pairs(list) do
					local expire = redis:ttl(Alpha.."CodeGiftCharge:"..v)
					if expire == -1 then
						EXPIRE = "نامحدود"
					else
						local d = math.floor(expire / 86400 ) + 1
						EXPIRE = d..""
					end
					text = text..k.."- `• کدهدیه :`\n[ *"..v.."* ]\n`• شارژ :`\n*"..EXPIRE.."*\n\n❦❧❦❧❦❧❦❧❦❧\n"
				end
				if #list == 0 then
					text = Source_Start..'`هیچ کد هدیه , ساخته نشده است`'
				end
				---tdbot.sendMessage(msg.chat_id, msg.id, 1, text, 1, 'md')
			elseif CmdMatches == "full" or CmdMatches == "نامحدود" then
				local linkgp = redis:get(Alpha..msg.to.id..'linkgpset')
				local mods = redis:smembers(Alpha..'Mods:'..msg.to.id)
				local owners = redis:smembers(Alpha..'Owners:'..msg.to.id)
				message = '\n'
				for k,v in pairs(owners) do
					local user_name = redis:get(Alpha..'user_name:'..v) or "---"
					message = message ..k.. '- '..check_markdown(user_name)..' [' ..v.. '] \n'
				end
				message2 = '\n'
				for k,v in pairs(mods) do
					local user_name = redis:get(Alpha..'user_name:'..v) or "---"
					message2 = message2 ..k.. '- '..check_markdown(user_name)..' [' ..v.. '] \n'
				end
				if not linkgp then
					---tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start..' _خطای دستوری_⚠️\n_مدیر عزیز لینک گروه فوق را ثبت کنید_\n"_تنظیم لینک_"\n"*setlink*"', 1, 'md')
				else
					redis:set(Alpha..'ExpireDate:'..msg.to.id,true)
					if not redis:get(Alpha..'CheckExpire:'..msg.to.id) then
						redis:set(Alpha..'CheckExpire:'..msg.to.id,true)
					end
					tdbot.sendMessage(gp_sudo, msg.id, 1, "'🕊_گزارش نصب ربات_ \n\n▪️_مشخصات نصب کننده_\n\n▪️نام کاربری: "..check_markdown(msg.from.first_name or "").."\n️▪️_یوزرنیم کاربر️_: @"..check_markdown(msg.from.username or "").."\n▪️_ایدی عددی_: *"..msg.from.id.."*\n\n▪️_نام گروه_: "..check_markdown(msg.to.title).."\n▪️_ایدی گروه_: *"..msg.to.id.."*\n▪️_لینک گروه_\n"..check_markdown(linkgp).."\n▪️_سازنده گروه_: "..message.."\n▪️لیست ادمین های گروه"..message2.."\n\n_برای مدیریت گروه شما میتوانید از دستورات زیراستفاده کنید_❗️\n\n▪️_دستور ورود به گروه_\n/join *"..msg.to.id.."*\n▪️_دستور حذف ربات از گروه_\n/rem *"..msg.to.id.."*\n▪️_دستور لفت دادن ربات  به صورت موقتی_\n/leave *"..msg.to.id.."*", 1, 'md')
					---tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start.. '_ربات به صورت دائمی دراین گروه فعال شد._', 1, 'md')
				end
			elseif CmdMatches == "delbotusername" or CmdMatches == "حذف یوزرنیم ربات" then
				tdbot.changeUsername('', dl_cb, nil)
				text = Source_Start..'_یوزرنیم ربات با موفقیت حذف شد_'
				---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
			elseif CmdMatches == "gid" or CmdMatches == "آیدی گروه" then
				--tdbot.sendMessage(msg.to.id, msg.id, 1, '`'..msg.to.id..'`', 1,'md')
			elseif CmdMatches == "time sv" or CmdMatches == "ساعت سرور" then
				--tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start..'`ساعت سرور :`\n'..os.date("%H:%M:%S")..'', 1, 'md')
			elseif CmdMatches == "حذف شماره کارت" then
				local hash = ('cart')
				redis:del(Alpha..hash)
				text = Source_Start..'`نرخ ربات پاک شد`'
				---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
			elseif CmdMatches == "testspeed" or CmdMatches == "سرعت سرور" then
				local io = io.popen("speedtest --share"):read("*all")
				link = io:match("http://www.speedtest.net/result/%d+.png")
				local file = download_to_file(link,'speed.png')
				---tdbot.sendPhoto(msg.to.id, msg.id, file, 0, {}, 0, 0, Source_Start..""..channel_username.."", 0, 0, 1, nil, dl_cb, nil)
			elseif CmdMatches and (CmdMatches:match('^charge (%d+)') or CmdMatches:match('^شارژ (%d+)')) then
				local Matches = CmdMatches:match('^charge (%d+)') or CmdMatches:match('^شارژ (%d+)')
				local linkgp = redis:get(Alpha..msg.to.id..'linkgpset')
				local mods = redis:smembers(Alpha..'Mods:'..msg.to.id)
				local owners = redis:smembers(Alpha..'Owners:'..msg.to.id)
				message = '\n' 
				for k,v in pairs(owners) do
					local user_name = redis:get(Alpha..'user_name:'..v) or "---"
					message = message ..k.. '- '..check_markdown(user_name)..' [' ..v.. '] \n'
				end
				message2 = '\n'
				for k,v in pairs(mods) do
					local user_name = redis:get(Alpha..'user_name:'..v) or "---"
					message2 = message2 ..k.. '- '..check_markdown(user_name)..' [' ..v.. '] \n'
				end
				if not linkgp then
					text = Source_Start..Source_Start..' _خطای دستوری_⚠️\n_مدیر عزیز لینک گروه فوق را ثبت کنید_\n"_تنظیم لینک_"\n"*setlink*"'
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif tonumber(Matches) > 0 and tonumber(Matches) < 1001 then
					local extime = (tonumber(Matches) * 86400)
					redis:setex(Alpha..'ExpireDate:'..msg.to.id, extime, true)
					if not redis:get(Alpha..'CheckExpire:'..msg.to.id) then
						redis:set(Alpha..'CheckExpire:'..msg.to.id)
					end
					tdbot.sendMessage(gp_sudo, msg.id, 1, "'🕊_گزارش نصب ربات_ \n\n▪️_مشخصات نصب کننده_\n_مقدار شارژ انجام داده ؛_ :*"..Matches.."*\n▪️نام کاربری: "..check_markdown(msg.from.first_name or "").."\n️▪️_یوزرنیم کاربر️_: @"..check_markdown(msg.from.username or "").."\n▪️_ایدی عددی_: *"..msg.from.id.."*\n\n▪️_نام گروه_: "..check_markdown(msg.to.title).."\n▪️_ایدی گروه_: *"..msg.to.id.."*\n▪️_لینک گروه_\n"..check_markdown(linkgp).."\n▪️_سازنده گروه_: "..message.."\n▪️لیست ادمین های گروه"..message2.."\n\n_برای مدیریت گروه شما میتوانید از دستورات زیراستفاده کنید_❗️\n\n▪️_دستور ورود به گروه_\n/join *"..msg.to.id.."*\n▪️_دستور حذف ربات از گروه_\n/rem *"..msg.to.id.."*\n▪️_دستور لفت دادن ربات  به صورت موقتی_\n/leave *"..msg.to.id.."*", 1, 'md')
					
					--tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start..'گروه به مدت *'..Matches..'* روز شارژ شد.', 1, 'md')
				else
					tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start..'*تعداد روزها باید عددی از 1 تا 1000 باشد.*', 1, 'md')
				end
			elseif CmdMatches and (CmdMatches:match('^setnerkh (.*)') or CmdMatches:match('^تنظیم نرخ (.*)')) then
				local Matches = CmdMatches:match('^setnerkh (.*)') or CmdMatches:match('^تنظیم نرخ (.*)')
				redis:set(Alpha..'nerkh',Matches)
				text = Source_Start.. '_نرخ ربات با موفقیت ثبت شد._ :\n\n '..check_markdown(Matches)..''
				--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
			elseif CmdMatches and (CmdMatches:match('^تنظیم کارت (.*)')) then
				local Matches = CmdMatches:match('^تنظیم کارت (.*)')
				redis:set(Alpha..'cart',Matches)
				text = Source_Start.. '_شماره کارت فروشنده ربات با موفقیت ثبت شد._\n\n '..check_markdown(Matches)..''
				---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
			elseif CmdMatches and (CmdMatches:match('^setmonshi (.*)') or CmdMatches:match('^تنظیم منشی (.*)')) then
				local Matches = CmdMatches:match('^setmonshi (.*)') or CmdMatches:match('^تنظیم منشی (.*)')
				redis:set(Alpha..'bot:pm',Matches)
				text = Source_Start.. '_متن منشی ربات با موفقیت ثبت شد._\n\n'..Source_Start..'.'..check_markdown(Matches)..''
				---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
			elseif CmdMatches == "monshi" or CmdMatches == "منشی" then
				local hash = ('bot:pm')
				local pm = redis:get(Alpha..hash)
				if not pm then
					text = Source_Start.. '_هیچ متن منشی برای ربات تنظیم نشده است❗️_'
					tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				else
					--tdbot.sendMessage(msg.chat_id, 0, 1, "_پیام منشی ربات جهت ارتباط با مشتریان_:\n\n"..check_markdown(pm), 0, 'md')
				end
			elseif CmdMatches and (CmdMatches:match('^monshi (.*)') or CmdMatches:match('^منشی (.*)')) then
				local CmdEn = {
				string.match(CmdMatches, "^(monshi) (.*)$")
				}
				local CmdFa = {
				string.match(CmdMatches, "^(منشی) (.*)$")
				}
				if CmdEn[2]=="on" or CmdFa[2]=="فعال" then
					redis:set(Alpha.."bot:pm", Source_Start.. "_سلام عزیزم من یک ربات هوشمند هستم برای خرید با قسمت پشتیبانی ربات در ارتباط باشید._" )
					text = Source_Start.."_منشی با موفقیت فعال شد_\nلطفا جهت اطمینان از پیام متنی منشی در پیوی ربات یا گروه دستور\nتنظیم منشی [*text*]را ارسال کنید." 
					tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				end
				if CmdEn[2]=="off" or CmdFa[2]=="غیرفعال" then
					redis:del(Alpha.."bot:pm")
					text = Source_Start.."_منشی ربات با موفقیت غیر فعال شد_"  
					tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				end
			elseif CmdMatches and (CmdMatches:match('^joinch (.*)') or CmdMatches:match('^عضویت اجباری (.*)')) then
				local CmdEn = {
				string.match(CmdMatches, "^(joinch) (.*)$")
				}
				local CmdFa = {
				string.match(CmdMatches, "^(عضویت اجباری) (.*)$")
				}
				if CmdEn[2] == "on" or CmdFa[2] == "فعال" then
					redis:del(Alpha.."JoinEnabel"..msg.chat_id)
					text = Source_Start.." _عضویت اجباری برای  همه گروه ها فعال شد._"
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif CmdEn[2] == "off" or CmdFa[2] == "غیرفعال" then
					redis:set(Alpha.."JoinEnabel"..msg.chat_id, true)
					text = Source_Start.. "_عضویت اجباری برای همه گروه ها غیر فعال شد_"
					--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				end
			elseif CmdMatches == "addgp" or CmdMatches == "نصب ربات" then
             set_configadd(msg)
				modadd(msg)
				elseif (CmdMatches == "helpsudo" or CmdMatches == "راهنما سودو") and is_JoinChannel(msg) then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							text = Source_Start.. "⚠️_خطای پردازشی_\n_ربات کمکی ربات خاموش می باشد❗️_"
							return tdbot.sendMessage(msg.to.id, msg.id, 0, text, 0, "md")
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Sudo:"..msg.to.id, 0, inline_query_cb, nil)
			elseif CmdMatches == 'rem' or CmdMatches == "خروج" then
				if redis:get(Alpha..'CheckExpire:'..msg.to.id) then
					redis:del(Alpha..'CheckExpire:'..msg.to.id)
				end
				redis:del(Alpha..'ExpireDate:'..msg.to.id)
				return modrem(msg)
			elseif CmdMatches and (CmdMatches:match('^leave (-%d+)') or CmdMatches:match('^خروج (-%d+)')) then
				local Matches = CmdMatches:match('^leave (-%d+)') or CmdMatches:match('^خروج (-%d+)')
				--tdbot.sendMessage(Matches, 0, 1, Source_Start.. '_توجه_⚠️\n'..Source_Start..' _ربات به وسیله سازنده از این گروه خارج شد._\n'..Source_Start..' _برای اطلاعات کافی وعلت را با سازنده ربات در ارتباط باشید_\n'..Source_Start..' _سازنده ربات_: '..check_markdown(sudo_username), 1, 'md')
				tdbot.changeChatMemberStatus(Matches, our_id, 'Left', dl_cb, nil)
				--tdbot.sendMessage(gp_sudo, msg.id, 1, Source_Start..' _من لفت میدم از گروه '..Matches..'\n_خداحافظی کردم از این گروه_\n'..Source_Start..'_این کاربر منو از گروه انداخت بیرون_ : @'..check_markdown(msg.from.username or '')..' -*'..msg.from.id..'*', 1,'md')
			elseif CmdMatches and (CmdMatches:match('^charge (-%d+) (%d+)') or CmdMatches:match('^شارژ (-%d+) (%d+)')) then
				local Matches = CmdMatches:match('^charge (-%d+)') or CmdMatches:match('^شارژ (-%d+)')
				local Matches2 = CmdMatches:match('^charge (-%d+) (%d+)') or CmdMatches:match('^شارژ (-%d+) (%d+)')
				if string.match(Matches, '^-%d+$') then
					if tonumber(Matches2) > 0 and tonumber(Matches2) < 1001 then
						local extime = (tonumber(Matches2) * 86400)
						redis:setex(Alpha..'ExpireDate:'..Matches, extime, true)
						if not redis:get(Alpha..'CheckExpire:'..msg.to.id) then
							redis:set(Alpha..'CheckExpire:'..msg.to.id,true)
						end
						tdbot.sendMessage(gp_sudo, msg.id, 1, "'🕊_گزارش نصب ربات_ \n\n▪️_مشخصات نصب کننده_\n_مقدار شارژ انجام داده ؛_ :*"..Matches2.."*\n▪️نام کاربری: "..check_markdown(msg.from.first_name or "").."\n️▪️_یوزرنیم کاربر️_: @"..check_markdown(msg.from.username or "").."\n▪️_ایدی عددی_: *"..msg.from.id.."*\n\n▪️_نام گروه_: "..check_markdown(msg.to.title).."\n▪️_ایدی گروه_: *"..Matches.."*\n▪️_لینک گروه_\n"..check_markdown(linkgp).."\n\n_برای مدیریت گروه شما میتوانید از دستورات زیراستفاده کنید_❗️\n\n▪️_دستور ورود به گروه_\n/join *"..Matches.."*\n▪️_دستور حذف ربات از گروه_\n/rem *"..Matches.."*\n▪️_دستور لفت دادن ربات  به صورت موقتی_\n/leave *"..Matches.."*", 1, 'md')
                       tdbot.sendMessage(Matches, 0, 1, Source_Start.. '_ربات توسط ادمین ربات به مدت_ \n*'..Matches2..'*روز\n _شارژ شد_\n',1 , 'md')
					else
						--tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start.. '⚠️خطای دستوری\n_حداکثر تنظیم شده برای شارژ ربات 1000روز می باشد_❗️', 1, 'md')
					end
				end
			elseif CmdMatches and (CmdMatches:match('^jointo (-%d+)') or CmdMatches:match('^ورود به (-%d+)')) then
				local Matches = CmdMatches:match('^jointo (-%d+)') or CmdMatches:match('^ورود به (-%d+)')
				if string.match(Matches, '^-%d+$') then
					--tdbot.sendMessage(SUDO, msg.id, 1, Source_Start.. '_بابایی من تو رو به گروه_\n '..Matches..'\nاد کردم کاراتو انجام بده.', 1, 'md')
					tdbot.addChatMember(Matches, SUDO, 0, dl_cb, nil)
					---tdbot.sendMessage(Matches, 0, 1, Source_Start.. '_وای بابای من اومد اخ جونم_',1, 'md')
				end
			elseif CmdMatches and (CmdMatches:match('^setbotname (.*)') or CmdMatches:match('^تغییر نام ربات (.*)')) then
				local Matches = CmdMatches:match('^setbotname (.*)') or CmdMatches:match('^تغییر نام ربات (.*)')
				tdbot.changeName(Matches, dl_cb, nil)
				text = Source_Start.. '_نام کاربری ربات ویرایش شد به_:\n*'..Matches..'*'
				tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
			elseif CmdMatches and (CmdMatches:match('^setbotusername (.*)') or CmdMatches:match('^setbotusername (.*)')) then
				local Matches = CmdMatches:match('^setbotusername (.*)') or CmdMatches:match('^setbotusername (.*)')
				tdbot.changeUsername(Matches, dl_cb, nil)
				text = Source_Start..'_یوزنیم ربات ویرایش شده به_: \n@'..check_markdown(Matches)..''
				tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
			elseif CmdMatches and (CmdMatches:match('^markread (.*)') or CmdMatches:match('^تیک دوم (.*)')) then
				local CmdEn = {
				string.match(CmdMatches, "^(markread) (.*)$")
				}
				local CmdFa = {
				string.match(CmdMatches, "^(تیک دوم) (.*)$")
				}
				if CmdEn[2] == 'on' or CmdFa[2] == "فعال" then
					redis:set(Alpha..'markread','on')
					text = Source_Start.. '_مارکرد ربات با موفقیت فعال شد_'
					tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				end
				if CmdEn[2] == 'off' or CmdFa[2] == "غیرفعال" then
					redis:del(Alpha..'markread')
					text = Source_Start.. 'مارکرد ربات باموفقیت غیر فعال شد.'
					tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				end
			elseif CmdMatches and (CmdMatches:match('^setforward (.*)') or CmdMatches:match('^تنظیم فوروارد (.*)')) and msg.reply_id then
				local Matches = CmdMatches:match('^setforward (.*)') or CmdMatches:match('^تنظیم فوروارد (.*)')
				if redis:get(Alpha.."ForwardMsg_Cmd"..Matches) then
					tdbot.sendMessage(msg.chat_id , msg.id, 1, "*دستور* `'"..Matches.."'` *از قبل در لیست فوروارد وجود داشت*", 0, 'md')
				end
				redis:set(Alpha.."ForwardMsg_Cmd"..Matches, Matches)
				redis:set(Alpha..'ForwardMsg_Reply'..Matches, msg.reply_id)
				redis:set(Alpha..'ForwardMsg_Gp'..Matches, msg.chat_id)
				redis:sadd(Alpha.."ForwardMsg_List", Matches)
				tdbot.sendMessage(msg.chat_id , msg.id, 1, "*پیامی که روی آن ریپلای کردید توسط* `"..msg.from.id.."` - @"..check_markdown(msg.from.username or '').." *روی دستور* `'"..Matches.."'` *تنظیم شد*", 0, 'md')
			elseif CmdMatches and (CmdMatches:match('^delforward (.*)') or CmdMatches:match('^حذف فوروارد (.*)')) then
				local Matches = CmdMatches:match('^delforward (.*)') or CmdMatches:match('^حذف فوروارد (.*)')
				if not redis:get(Alpha.."ForwardMsg_Cmd"..Matches) then
					tdbot.sendMessage(msg.chat_id , msg.id, 1, "*دستور* `'"..Matches.."'` *در لیست فوروارد وجود ندارد*", 0, 'md')
				end
				redis:del(Alpha.."ForwardMsg_Cmd"..Matches)
				redis:del(Alpha..'ForwardMsg_Reply'..Matches)
				redis:del(Alpha..'ForwardMsg_Gp'..Matches)
				redis:srem(Alpha.."ForwardMsg_List", Matches)
				tdbot.sendMessage(msg.chat_id , msg.id, 1, "*دستور* `'"..Matches.."'` *توسط* `"..msg.from.id.."` - @"..check_markdown(msg.from.username or '').." *از لیست فوروارد حذف شد*", 0, 'md')
			elseif CmdMatches == "forwardlist" or CmdMatches == "لیست فوروارد" then
				forwardlist(msg)
			end
		end
     
	
		if CmdMatches and (CmdMatches:match('^clean (.*)') or CmdMatches:match('^پاکسازی (.*)')) and is_JoinChannel(msg) then
			local CmdEn = {
			string.match(CmdMatches, "^(clean) (.*)$")
			}
			local CmdFa = {
			string.match(CmdMatches, "^(پاکسازی) (.*)$")
			}
			if is_sudo(msg) then
				if CmdEn[2] == 'gbans' or CmdFa[2] == 'سوپر مسدود' then
					local list = redis:smembers(Alpha..'GBanned')
					if #list == 0 then
						text = Source_Start.. "⚠️_خطای پردازشی_\n_هیچ کاربری در لیست سوپر مسدود نمی باشد._❗️"
						--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
					redis:del(Alpha..'GBanned')
					text = Source_Start.. "_دستور پاکسازی موفق_\n_تمامی کاربرانی که سوپر مسدود شده بودند ازلیست حذف شد._✅"
					--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				end
			end
			if is_admin(msg) then
				if CmdEn[2] == 'owners' or CmdFa[2] == "مالکان" then
					local list = redis:smembers(Alpha..'Owners:'..msg.to.id)
					if #list == 0 then
						text = Source_Start.. "⚠️_خطای پردازشی_\n_هیچ کاربری در لیست مالکان نمی باشد._❗️"
						--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
					redis:del(Alpha.."Owners:"..msg.to.id)
					text = Source_Start.. "_دستور پاکسازی موفق_\n_تمامی کاربرانی که درلیست مالکان بودند حذف شد._✅"
					--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				end
			end
			if is_owner(msg) then
					if CmdEn[2] == "on" or CmdFa[2] == "فعال" then
				
						redis:set(Alpha.."delbot"..msg.to.id, true)
						redis:set(Alpha.."deltimebot"..msg.chat_id , 60)
						--tdbot.sendMessage(msg.chat_id , msg.id, 1, '_پاکسازی خودکار پیام فعال شد_.✅', 0, 'md')
					elseif CmdEn[2] == "off" or CmdFa[2] == "غیرفعال" then
					redis:del(Alpha.."delbot"..msg.to.id)
						redis:del(Alpha.."deltimebot"..msg.chat_id)
						--tdbot.sendMessage(msg.chat_id , msg.id, 1, '_پاکسازی خودکار پیام غیرفعال شد_.❌', 0, 'md')
					end
				end
				  
			
			if is_owner(msg) then
				if msg.to.type == "channel" then
					if CmdEn[2] == 'blacklist' or CmdFa[2] == 'بلک لیست' then
						local function GetRestricted(arg, data)
							if data.members then
								for k,v in pairs (data.members) do
									tdbot.changeChaargemberStatus(msg.to.id, v.user_id, 'Restricted', {1,0,1,1,1,1}, dl_cb, nil)
								end
							end
						end
						local function GetBlackList(arg, data)
							if data.members then
								for k,v in pairs (data.members) do
									channel_unblock(msg.to.id, v.user_id)
								end
							end
						end
						for i = 1, 2 do
							tdbot.getChannelMembers(msg.to.id, 0, 100000000000, 'Restricted', GetRestricted, {msg=msg})
						end
						for i = 1, 2 do
							tdbot.getChannelMembers(msg.to.id, 0, 100000000000, 'Banned', GetBlackList, {msg=msg})
						end
						--return tdbot.sendMessage(msg.to.id, msg.id, 0, Source_Start.. "_دستور پاکسازی موفق_\n_تمامی کاربرانی که درلیست سیاه گروه بودند حذف شد._✅", 0, "md")
					elseif CmdEn[2] == 'bots' or CmdFa[2] == 'ربات' then
						local function GetBots(arg, data)
							if data.members then
								for k,v in pairs (data.members) do
									if not is_mod1(msg.to.id, v.user_id) then
										kick_user(v.user_id, msg.to.id)
									end
								end
							end
						end
						for i = 1, 5 do
							tdbot.getChannelMembers(msg.to.id, 0, 100000000000, 'Bots', GetBots, {msg=msg})
						end
						--return tdbot.sendMessage(msg.to.id, msg.id, 0, Source_Start.. "_دستور پاکسازی موفق_\n_کاربرانی که درگروه به عنوان ربات APIشناخته می شوند از گروه حذف شدند_✅", 0, "md")
					elseif CmdEn[2] == 'deleted' or CmdFa[2] == 'دلیت اکانت ها' then
						local function GetDeleted(arg, data)
							if data.members then
								for k,v in pairs (data.members) do
									local function GetUser(arg, data)
										if data.type and data.type._ == "userTypeDeleted" then
											kick_user(data.id, msg.to.id)
										end
									end
									tdbot.getUser(v.user_id, GetUser, {msg=arg.msg})
								end
							end
						end
						for i = 1, 2 do
							tdbot.getChannelMembers(msg.to.id, 0, 100000000000, 'Recent', GetDeleted, {msg=msg})
						end
						for i = 1, 1 do
							tdbot.getChannelMembers(msg.to.id, 0, 100000000000, 'Search', GetDeleted, {msg=msg})
						end
						---return tdbot.sendMessage(msg.to.id, msg.id, 0, Source_Start.. "_دستور پاکسازی موفق_\n_.کاربرانی که درگروه بی مصرف بودند ومدت زمان مراجعه به گروه بیش یک ماه بود حذف شد_✅", 0, "md")
					end
				end
				if msg.to.type ~= 'pv' then
					if CmdEn[2] == 'bans' or CmdFa[2] == 'لیست مسدود' then
						local list = redis:smembers(Alpha..'Banned:'..msg.to.id)
						if #list == 0 then
							text = Source_Start.. "⚠️_خطای پردازشی_\n_هیچ کاربری در لیست مسدود نمی باشد._❗️"
							---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
						end
						redis:del(Alpha.."Banned:"..msg.to.id)
						text = Source_Start.. "_دستور پاکسازی موفق_\n_تمامی کاربرانی که درلیست مسدود بودند حذف شد._✅"
						--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					elseif CmdEn[2] == 'silentlist' or CmdFa[2] == 'لیست سکوت' then
						local function GetRestricted(arg, data)
							msg=arg.msg
							local i = 1
							local un = ''
							if data.total_count > 0 then
								i = 1
								k = 0
								local function getuser(arg, mdata)
									local ST = data.members[k].status
									if ST.can_add_web_page_previews == false and ST.can_send_media_messages == false and ST.can_send_messages == false and ST.can_send_other_messages == false and ST.is_member == true then
										unsilent_user(msg.to.id, data.members[k].user_id)
										i = i + 1
									end
									k = k + 1
									if k < data.total_count then
										tdbot.getUser(data.members[k].user_id, getuser, nil)
									else
										if i == 1 then
											--return tdbot.sendMessage(msg.to.id, msg.id, 0, "⚠️_خطای پردازشی_\n_هیچ کاربری در لیست سکوت نمی باشد._❗️", 0, "md")
										else
											--return tdbot.sendMessage(msg.to.id, msg.id, 0, "_دستور پاکسازی موفق_\n_تمامی کاربرانی که درلیست سکوت بودند حذف شد._✅", 0, "md")
										end
									end
								end
								tdbot.getUser(data.members[k].user_id, getuser, nil)
							else
								---return tdbot.sendMessage(msg.to.id, msg.id, 0, "⚠️_خطای پردازشی_\n_هیچ کاربری در لیست سکوت نمی باشد._❗️", 0, "md")
							end
						end
						tdbot.getChannelMembers(msg.to.id, 0, 100000, 'Restricted', GetRestricted, {msg=msg})
					end
				end
				
				
				if CmdEn[2] == 'msgs' or CmdFa[2] == 'پیام' then
					function check_members(extra , result)
						local count = result.total_count - 1
						if count > (200 or 199) then
							count = 198
						end
						while count > -1 do
							tdbot.deleteMessagesFromUser(msg.to.id,  result.members[count].user_id, dl_cb, nil)
							count = count - 1
						end
					end
					local function cb(arg,data)
						for k,v in pairs(data.messages) do
							del_msg(msg.chat_id, v.id)
						end
					end
					for i = 1, 5 do
						tdbot.getChatHistory(msg.to.id, msg.id, 0,  500000000, 0, cb, nil)
					end
					for i = 1, 2 do
						tdbot.getChannelMembers(msg.to.id, 0, 20000, "Search", check_members, nil)
					end
					for i = 1, 1 do
						tdbot.getChannelMembers(msg.to.id, 0, 200000, "Recent", check_members, nil)
					end
					for i = 1, 5 do
						tdbot.getChannelMembers(msg.to.id, 0, 2000000000, "Banned", check_members, nil)
					end
					tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. "_دستور پاکسازی موفق_\n_پاکسازی کل پیام در حد توان ربات_✅", 0, 'md')
				

				elseif CmdEn[2] == 'stickers' or CmdFa[2] == 'استیکر ها' then
					local function Stickers(arg,data)
						for k,v in pairs(data.messages) do
							if v.content and v.content._ == "messageSticker" then
								del_msg(msg.chat_id, v.id)
							end
						end
					end
					--tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. "_دستور پاکسازی موفق_\n_تمامی استیکر ها ارسال شده  در گروه حذف شد._✅", 0, 'md')
					for i = 1, 5 do
						tdbot.getChatHistory(msg.to.id, msg.id, 0,  50000, 0, Stickers, nil)
					end
				elseif CmdEn[2] == 'videos' or CmdFa[2] == 'فیلم ها' then
					local function Videos(arg,data)
						for k,v in pairs(data.messages) do
							if v.content and v.content._ == "messageVideo" then
								del_msg(msg.chat_id, v.id)
							end
						end
					end
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. "_دستور پاکسازی موفق_\n_تمامی فیلم ارسال شده  در گروه حذف شد._✅", 0, 'md')
					for i = 1, 5 do
						tdbot.getChatHistory(msg.to.id, msg.id, 0,  50000, 0, Videos, nil)
					end
				elseif CmdEn[2] == 'documents' or CmdFa[2] == 'فایل ها' then
					local function Documents(arg,data)
						for k,v in pairs(data.messages) do
							if v.content and v.content._ == "messageDocument" then
								del_msg(msg.chat_id, v.id)
							end
						end
					end
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. "_دستور پاکسازی موفق_\n_تمامی فایل های ارسال شده  در گروه حذف شد._✅", 0, 'md')
					for i = 1, 5 do
						tdbot.getChatHistory(msg.to.id, msg.id, 0,  50000, 0, Documents, nil)
					end
				elseif CmdEn[2] == 'photos' or CmdFa[2] == 'عکس ها' then
					local function Photos(arg,data)
						for k,v in pairs(data.messages) do
							if v.content and v.content._ == "messagePhoto" then
								del_msg(msg.chat_id, v.id)
							end
						end
					end
					for i = 1, 5 do
						tdbot.getChatHistory(msg.to.id, msg.id, 0,  50000, 0, Photos, nil)
					end
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. "_دستور پاکسازی موفق_\n_تمامی عکس های ارسال شده  در گروه حذف شد._✅", 0, 'md')
			
					--------------------------------
				elseif CmdEn[2] == 'mods' or CmdFa[2] == "ترفیع" then
					local list = redis:smembers(Alpha..'Mods:'..msg.to.id)
					if #list == 0 then
						text = Source_Start.. "⚠️_خطای پردازشی_\n_هیچ کاربری در لیست ترفیع شده ها نمی باشد._❗️"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
					redis:del(Alpha.."Mods:"..msg.to.id)
					text = Source_Start.. "✅_دستور پاکسازی موفق_\n_کاربرانی که در لیست ترفیع شده ها بود حذف شدند_"
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif CmdEn[2] == 'filterlist' or CmdFa[2] == "لیست فیلتر" then
					local names = redis:hkeys(Alpha..'filterlist:'..msg.to.id)
					if #names == 0 then
						text = Source_Start.. "⚠️_خطای پردازشی_\n_هیچ کلمه در لیست فیلتر ها موجود نمی باشد_❗️"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					else
					redis:del(Alpha..'filterlist:'..msg.to.id)
					text = Source_Start.. "_دستور پاکسازی موفق_\n_تمامی کلمات فیلتر شده از سیستم ربات پاک شد._✅"
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
				elseif CmdEn[2] == 'rules' or CmdFa[2] == "قوانین" then
					if not redis:get(Alpha..msg.to.id..'rules')then
						text = Source_Start.. "⚠️_خطای پردازشی_\n_هیچ متنی برای قوانین گروه ثبت نشده است_❗"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
					redis:del(Alpha..msg.to.id..'rules')
					text = Source_Start.. "_دستور پاکسازی موفق_\n_متن تنظیم شده برای قوانین گروه از سیستم ربات پاک شد._✅"
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif CmdEn[2] == 'welcome' or CmdFa[2] == "خوشامد" then
					if not redis:get(Alpha..'setwelcome:'..msg.chat_id) then
						text = Source_Start.. "⚠️_خطای پردازشی_\n_هیچ متنی برای خوش آمدگویی گروه ثبت نشده است_❗"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
					redis:del(Alpha..'setwelcome:'..msg.chat_id)
					text = Source_Start.. "_دستور پاکسازی موفق_\n_متن تنظیم شده برای خوشآمدگویی گروه از سیستم ربات پاک شد._✅"
					--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif CmdEn[2] == 'about' or CmdFa[2] == "درباره" then
					if msg.to.type == "chat" then
						if not redis:get(Alpha..msg.to.id..'about') then
							text = Source_Start.. "⚠️_خطای پردازشی_\n_هیچ متنی برای بیوگرافی گروه ثبت نشده است_❗"
							---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
						end
					elseif msg.to.type == "channel" then
						tdbot.changeChannelDescription(chat, "", dl_cb, nil)
					end
					text = Source_Start.. "_دستور پاکسازی موفق_\n_متن تنظیم شده برای بیوگرافی گروه از سیستم ربات پاک شد._✅"
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif  CmdEn[2] == 'warns' or CmdFa[2] == 'اخطار' then
					local hash = msg.to.id..':warn'
					redis:del(Alpha..hash)
					text = Source_Start.. "_دستور پاکسازی موفق_\n_کاربرانی که در گروه اخطار گرفته بودند از سیستم ربات پاک شد._✅"
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				end
			end
		end
		if is_admin(msg) then
			if CmdMatches == "gban" or CmdMatches == "سوپر مسدود" then
				ReplySet(msg,"banall")
			elseif CmdMatches == "ungban" or CmdMatches == "حذف سوپر مسدود" then
				ReplySet(msg,"unbanall")
			elseif CmdMatches == "setowner" or CmdMatches == 'تنظیم مالک' then
				ReplySet(msg,"setowner")
			elseif CmdMatches == "remowner" or CmdMatches == "حذف مالک" then
				ReplySet(msg,"remowner")
			elseif CmdMatches and (CmdMatches:match('^gban (.*)') or CmdMatches:match('^سوپر مسدود (.*)')) then
				local Matches = CmdMatches:match('^gban (.*)') or CmdMatches:match('^سوپر مسدود (.*)')
				UseridSet(msg, Matches ,"banall")
			elseif CmdMatches and (CmdMatches:match('^ungban (.*)') or CmdMatches:match('^حذف سوپر مسدود (.*)')) then
				local Matches = CmdMatches:match('^ungban (.*)') or CmdMatches:match('^حذف سوپر مسدود (.*)')
				UseridSet(msg, Matches ,"unbanall")
			elseif CmdMatches and (CmdMatches:match('^setowner (.*)') or CmdMatches:match('^تنظیم مالک (.*)')) then
				local Matches = CmdMatches:match('^setowner (.*)') or CmdMatches:match('^تنظیم مالک (.*)')
				UseridSet(msg, Matches ,"setowner")
			elseif CmdMatches and (CmdMatches:match('^remowner (.*)') or CmdMatches:match('^حذف مالک (.*)')) then
				local Matches = CmdMatches:match('^remowner (.*)') or CmdMatches:match('^حذف مالک (.*)')
				UseridSet(msg, Matches ,"remowner")
			elseif CmdMatches == "adminlist" or CmdMatches == "لیست ادمین" then
				return adminlist(msg)
			elseif CmdMatches == "leave" or CmdMatches == "لفت بده" then
				--tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start.. '_من رفتم تا ابد بای بای._', 1,'md')
				tdbot.changeChatMemberStatus(msg.to.id, Bot_id, 'Left', dl_cb, nil)
			elseif CmdMatches == "chats" or CmdMatches == "لیست گروه ها" then
				return chat_list(msg)
			elseif CmdMatches == "config" or CmdMatches == "پیکربندی" then
				return set_config(msg)
				--------------------------------
				
			elseif CmdMatches == "tosuper" or CmdMatches == "تبدیل به سوپرگروه" then
				local id = msg.to.id
				tdbot.migrateGroupChatToChannelChat(id, dl_cb, nil)
				text = Source_Start.. '_گروه با موفقیت تبدیل شد به سوپرگروه_'
				---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
			elseif CmdMatches and (CmdMatches:match('^setrank (.*)') or CmdMatches:match('^setrank (.*)')) then
				if msg.reply_id then
					assert (tdbot_function ({
					_ = "getMessage",
					chat_id = msg.to.id,
					message_id = msg.reply_id
					}, rank_reply, {chat_id=msg.to.id,cmd="setrank",rank=string.sub(msg.text,9)}))
				end
			elseif CmdMatches and (CmdMatches:match('^تنظیم مقام (.*)') or CmdMatches:match('^تنظیم مقام (.*)')) then
				if msg.reply_id then
					assert (tdbot_function ({
					_ = "getMessage",
					chat_id = msg.to.id,
					message_id = msg.reply_id
					}, rank_reply, {chat_id=msg.to.id,cmd="setrank",rank=string.sub(msg.text,21)}))
				end
			elseif CmdMatches == "remrank" or CmdMatches == "حذف مقام" then
				if msg.reply_id then
					assert (tdbot_function ({
					_ = "getMessage",
					chat_id = msg.to.id,
					message_id = msg.reply_id
					}, rank_reply, {chat_id=msg.to.id,cmd="delrank"}))
				end
			elseif CmdMatches and (CmdMatches:match('^setrank (.*) (.*)')) then
				local CmdEn = {
				string.match(CmdMatches, "^(setrank) (.*) (.*)")
				}
				local Matches = CmdEn[2]
				local Matches2 = CmdEn[3]
				if Matches2 and string.match(Matches2, '^%d+$') then
					assert (tdbot_function ({
					_ = "getUser",
					user_id = Matches2,
					}, rank_id, {chat_id=msg.to.id,user_id=Matches2,cmd="setrank",rank=Matches}))
				elseif Matches2 and not string.match(Matches2, '^%d+$') then
					assert (tdbot_function ({
					_ = "searchPublicChat",
					username = Matches2
					}, rank_username, {chat_id=msg.to.id,username=Matches2,cmd="setrank",rank=Matches}))
				end
			elseif CmdMatches and (CmdMatches:match('^تنظیم مقام (.*) (.*)')) then
				local CmdEn = {
				string.match(CmdMatches, "^(تنظیم مقام) (.*) (.*)")
				}
				local Matches = CmdEn[2]
				local Matches2 = CmdEn[3]
				if Matches2 and string.match(Matches2, '^%d+$') then
					assert (tdbot_function ({
					_ = "getUser",
					user_id = Matches2,
					}, rank_id, {chat_id=msg.to.id,user_id=Matches2,cmd="setrank",rank=Matches}))
				elseif Matches2 and not string.match(Matches2, '^%d+$') then
					assert (tdbot_function ({
					_ = "searchPublicChat",
					username = Matches2
					}, rank_username, {chat_id=msg.to.id,username=Matches2,cmd="setrank",rank=Matches}))
				end
			elseif CmdMatches and (CmdMatches:match('^remrank (.*)') or CmdMatches:match('^حذف مقام (.*)')) then
				local Matches = CmdMatches:match('^remrank (.*)') or CmdMatches:match('^حذف مقام (.*)')
				if Matches and string.match(Matches, '^%d+$') then
					assert (tdbot_function ({
					_ = "getUser",
					user_id = Matches,
					}, rank_id, {chat_id=msg.to.id,user_id=Matches,cmd="delrank"}))
				elseif Matches and not string.match(Matches, '^%d+$') then
					assert (tdbot_function ({
					_ = "searchPublicChat",
					username = Matches
					}, rank_username, {chat_id=msg.to.id,username=Matches,cmd="delrank"}))
				end
			elseif CmdMatches and (CmdMatches:match('^creategroup (.*)') or CmdMatches:match('^ساخت گروه (.*)')) then
				local Matches = CmdMatches:match('^creategroup (.*)') or CmdMatches:match('^ساخت گروه (.*)')
				local text = Matches
				tdbot.createNewGroupChat({[0] = msg.from.id}, text, dl_cb, nil)
				text = Source_Start.. '_گروه به وسیله ربات گروه ساخته شد_'
				tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
			elseif CmdMatches and (CmdMatches:match('^createsuper (.*)') or CmdMatches:match('^ساخت سوپرگروه (.*)')) then
				local Matches = CmdMatches:match('^createsuper (.*)') or CmdMatches:match('^ساخت سوپرگروه (.*)')
				local text = Matches
				tdbot.createNewChannelChat(text, 1, '@Toompluscch', (function(b, d) tdbot.addChatMember(d.id, msg.from.id, 0, dl_cb, nil) end), nil)
					text = Source_Start.. '*سوپرگروه ساخته شد و* [`'..msg.from.id..'`] *به گروه اضافه شد.*'
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif CmdMatches and (CmdMatches:match('^import (.*)') or CmdMatches:match('^ورود لینک (.*)')) then
					local Matches = CmdMatches:match('^import (.*)') or CmdMatches:match('^ورود لینک (.*)')
					if Matches:match("^([https?://w]*.?telegram.me/joinchat/.*)$") or Matches:match("^([https?://w]*.?t.me/joinchat/.*)$") then
						local link = Matches
						if link:match('t.me') then
							link = string.gsub(link, 't.me', 'telegram.me')
						end
						tdbot.importChatInviteLink(link, dl_cb, nil)
						text = Source_Start.. '_داخل گروه شدم مدیر جان_'
						tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
				elseif CmdMatches and (CmdMatches:match('^join (-%d+)') or CmdMatches:match('^ورود (-%d+)')) then
					local Matches = CmdMatches:match('^join (-%d+)') or CmdMatches:match('^ورود (-%d+)')
					tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start..'*شما وارد گروه * '..Matches..' *شدید*', 1, 'md')
					tdbot.sendMessage(Matches, 0, 1, Source_Start.."*سودو ربات وارد گروه شد*", 1, 'md')
					tdbot.addChatMember(Matches, msg.from.id, 0, dl_cb, nil)
				elseif CmdMatches and (CmdMatches:match('^autoleave (.*)') or CmdMatches:match('^خروج خودکار (.*)')) then
					local CmdEn = {
					string.match(CmdMatches, "^(autoleave) (.*)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(خروج خودکار) (.*)$")
					}
					local hash = 'auto_leave_bot'
					if CmdEn[2] == 'enable' or CmdFa[2] == "فعال" then
						redis:del(Alpha..hash)
						text = Source_Start.. '_خروج خودکار ربات باموففقیت فعال شد_'
						tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					elseif CmdEn[2] == 'disable' or CmdFa[2] == "غیرفعال" then
						redis:set(Alpha..hash, true)
						text = Source_Start.. '_خروج خودکار ربات با موفقیت غیرفعال شد._'
						tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
				elseif CmdMatches and (CmdMatches:match('^expire (-%d+)') or CmdMatches:match('^اعتبار ربات (-%d+)')) then
					local Matches = CmdMatches:match('^expire (-%d+)') or CmdMatches:match('^اعتبار ربات (-%d+)')
					if string.match(Matches, '^-%d+$') then
						local check_time = redis:ttl(Alpha..'ExpireDate:'..Matches)
						year = math.floor(check_time / 31536000)
						byear = check_time % 31536000
						month = math.floor(byear / 2592000)
						bmonth = byear % 2592000
						day = math.floor(bmonth / 86400)
						bday = bmonth % 86400
						hours = math.floor( bday / 3600)
						bhours = bday % 3600
						min = math.floor(bhours / 60)
						sec = math.floor(bhours % 60)
						if check_time == -1 then
							remained_expire = Source_Start.. '_اعتبار این گروه به صورت دائمی ومادالعمر می باشد❗️_'
						elseif tonumber(check_time) > 1 and check_time < 60 then
							remained_expire = Source_Start.. 'گروه به مدت *'..sec..'* ثانیه شارژ میباشد'
						elseif tonumber(check_time) > 60 and check_time < 3600 then
							remained_expire = Source_Start.. 'گروه به مدت *'..min..'* دقیقه و` *'..sec..'* _ثانیه شارژ میباشد'
						elseif tonumber(check_time) > 3600 and tonumber(check_time) < 86400 then
							remained_expire = Source_Start.. 'گروه به مدت *'..hours..'* ساعت و *'..min..'* `دقیقه و` *'..sec..'* ثانیه شارژ میباشد'
						elseif tonumber(check_time) > 86400 and tonumber(check_time) < 2592000 then
							remained_expire = Source_Start.. 'گروه به مدت *'..day..'* روز و *'..hours..'* `ساعت و` *'..min..'* `دقیقه و` *'..sec..'* ثانیه شارژ میباشد'
						elseif tonumber(check_time) > 2592000 and tonumber(check_time) < 31536000 then
							remained_expire = Source_Start.. 'گروه به مدت *'..month..'* ماه *'..day..'* روز و *'..hours..'* `ساعت و` *'..min..'* `دقیقه و` *'..sec..'* ثانیه شارژ میباشد'
						elseif tonumber(check_time) > 31536000 then
							remained_expire = Source_Start.. 'گروه به مدت *'..year..'* سال *'..month..'* ماه *'..day..'* روز و *'..hours..'* ساعت و *'..min..'* دقیقه و *'..sec..'* ثانیه شارژ میباشد'
						end
						---tdbot.sendMessage(msg.to.id, msg.id, 1, remained_expire, 1, 'md')
					end
				elseif CmdMatches == "gbanlist" or CmdMatches == "لیست سوپر مسدود" then
					return gbanned_list(msg)
				end
			end
			if is_owner(msg) then
				if msg.text then
					local is_link = msg.text:match("^([https?://w]*.?telegram.me/joinchat/%S+)$") or msg.text:match("^([https?://w]*.?t.me/joinchat/%S+)$")
					if is_link and redis:get(Alpha..msg.to.id..'linkgp') then
						redis:set(Alpha..msg.to.id..'linkgpset', msg.text)
						text = Source_Start.. "_لینک جدید گروه با موفقیت تغییر وثبت شد_"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
				end
				
				if msg.text then
					local is_link = msg.text:match("^(.*)$") or msg.text:match("^(.*)$")
					if is_link and redis:get(Alpha..msg.to.id..'linkch') then
						redis:set(Alpha..msg.to.id..'linkchset', msg.text)
						text = Source_Start.. "_لینک کانال با موفقیت ثبت شد._"
						--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
				end
				
				if (CmdMatches == "promote" or CmdMatches == "ترفیع") and is_JoinChannel(msg) then
					ReplySet(msg,"promote")
				elseif (CmdMatches == "demote" or CmdMatches == "عزل") and is_JoinChannel(msg) then
					ReplySet(msg,"demote")
				elseif CmdMatches and (CmdMatches:match('^promote (.*)') or CmdMatches:match('^ترفیع (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^promote (.*)') or CmdMatches:match('^ترفیع (.*)')
					UseridSet(msg, Matches ,"promote")
				elseif CmdMatches and (CmdMatches:match('^demote (.*)') or CmdMatches:match('^عزل (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^demote (.*)') or CmdMatches:match('^عزل (.*)')
					UseridSet(msg, Matches ,"demote")
				elseif (CmdMatches == 'setlink' or CmdMatches == "تنظیم لینک") and is_JoinChannel(msg) then
					redis:setex(Alpha..msg.to.id..'linkgp', 60, true)
					text = Source_Start.. '_کاربر عزیز لطفا لینک گروه خودتان را ارسال کنید_❗️'
					--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					------------------------------
					elseif (CmdMatches == 'setlink' or CmdMatches == "تنظیم کانال") and is_JoinChannel(msg) then
					redis:setex(Alpha..msg.to.id..'linkch', 60, true)
					text = Source_Start.. '_مدیر عزیز لطفا یوزرنیم کانال خودتان ار ارسال کنید_❗️'
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					----------------------------------
				elseif CmdMatches and (CmdMatches:match('^setmute (%d+)') or CmdMatches:match('^تنظیم سکوت (%d+)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^setmute (%d+)') or CmdMatches:match('^تنظیم سکوت (%d+)')
					local time = Matches * 60
					redis:set(Alpha.."TimeMuteset"..msg.to.id, time)
					text = Source_Start.. "_زمان سکوت در سیستم ربات به_\nدقیقه*"..Matches.."* "
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif CmdMatches == "expire" or CmdMatches == "اعتبار" and msg.to.type == 'channel' or msg.to.type == 'chat' then
					local check_time = redis:ttl(Alpha..'ExpireDate:'..msg.to.id)
					year = math.floor(check_time / 31536000)
					byear = check_time % 31536000
					month = math.floor(byear / 2592000)
					bmonth = byear % 2592000
					day = math.floor(bmonth / 86400)
					bday = bmonth % 86400
					hours = math.floor( bday / 3600)
					bhours = bday % 3600
					min = math.floor(bhours / 60)
					sec = math.floor(bhours % 60)
					if check_time == -1 then
					
					 
					 
					 
					 
							remained_expire = Source_Start.. '_اعتبار این گروه به صورت دائمی ومادالعمر می باشد❗️_'
						elseif tonumber(check_time) > 1 and check_time < 60 then
						
						
							remained_expire = Source_Start.. '\nگروه به مدت *'..sec..'* ثانیه شارژ میباشد'
						elseif tonumber(check_time) > 60 and check_time < 3600 then
						
					
							remained_expire = Source_Start.. '\nگروه به مدت *'..min..'* دقیقه و` *'..sec..'* _ثانیه شارژ میباشد'
						elseif tonumber(check_time) > 3600 and tonumber(check_time) < 86400 then
						
							remained_expire = Source_Start.. '\nگروه به مدت *'..hours..'* ساعت و *'..min..'* `دقیقه و` *'..sec..'* ثانیه شارژ میباشد'
						elseif tonumber(check_time) > 86400 and tonumber(check_time) < 2592000 then
						
							remained_expire = Source_Start.. '\nگروه به مدت *'..day..'* روز و *'..hours..'* `ساعت و` *'..min..'* دقیقه و *'..sec..'* ثانیه شارژ میباشد'
						elseif tonumber(check_time) > 2592000 and tonumber(check_time) < 31536000 then
						remained_expire = Source_Start.. '\nگروه به مدت *'..month..'* ماه *'..day..'* روز و *'..hours..'* ساعت و *'..min..'* دقیقه و *'..sec..'* ثانیه شارژ میباشد\n'
						elseif tonumber(check_time) > 31536000 then
						remained_expire = Source_Start.. '\nگروه به مدت *'..year..'* سال *'..month..'* ماه *'..day..'* روز و *'..hours..'* ساعت و *'..min..'* دقیقه و *'..sec..'* ثانیه شارژ میباشد'
					end
					---tdbot.sendMessage(msg.to.id, msg.id, 1, remained_expire, 1, 'md')
				elseif (CmdMatches == "gift" or CmdMatches == "استفاده هدیه") and is_JoinChannel(msg) then
					redis:setex(Alpha.."Codegift:" .. msg.to.id , 60, true)
					tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.. "_مدیر عزیز شما یک دقیقه فرصت دارید تا از کد هدیه استفاده کنید_❗️", 1, 'md')
					
				elseif (CmdMatches == "mutelist" or CmdMatches == "لیست سکوت") and is_JoinChannel(msg) then
					return silent_users_list(msg)
				elseif (CmdMatches == "banlist" or CmdMatches == "لیست مسدود") and is_JoinChannel(msg) then
					return banned_list(msg)
				elseif (CmdMatches == "ownerlist" or CmdMatches == "لیست مالکان") and is_JoinChannel(msg) then
					return ownerlist(msg)
				elseif CmdMatches and (CmdMatches:match('^flood (.*)') or CmdMatches:match('^پیام مکرر (.*)')) and is_JoinChannel(msg) then
					local CmdEn = {
					string.match(CmdMatches, "^(flood) (.*)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(پیام مکرر ) (.*)$")
					}
					if CmdEn[2] == "mute" or CmdFa[2] == "سکوت" then
						redis:set(Alpha..msg.to.id..'floodmod', "Mute")
						---tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.. "_پیام رگباری همان توسط_\n `"..msg.from.id.."` - @"..check_markdown(msg.from.username or '').."\n _رو حالت سکوت تنظیم شد_🤐", 1, 'md')
					elseif CmdEn[2] == "kick" or CmdFa[2] == "اخراج" then
						redis:del(Alpha..msg.to.id..'floodmod')
						--tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.. "_پیام رگباری همان توسط_ "..msg.from.id.."` - @"..check_markdown(msg.from.username or '').." _روحالت اخراج تنظیم شد❌_", 1, 'md')
					end
				end
			end

			if is_mod(msg) then
				if msg.to.type ~= 'pv' then
					if (CmdMatches == "kick" or CmdMatches == "اخراج") and is_JoinChannel(msg) then
						ReplySet(msg,"kick")
					elseif (CmdMatches == "delall" or CmdMatches == "حذف پیام") and is_JoinChannel(msg) then
						ReplySet(msg,"delall")
					elseif (mdMatches == "ban" or CmdMatches == "مسدود") and is_JoinChannel(msg) then
						ReplySet(msg,"ban")
					elseif (CmdMatches == "unban" or CmdMatches == "حذف مسدود") and is_JoinChannel(msg) then
						ReplySet(msg,"unban")
					elseif (CmdMatches == "mute" or CmdMatches == "سکوت") and is_JoinChannel(msg) then
						ReplySet(msg,"silent")
						
					elseif (CmdMatches == "unmute" or CmdMatches == "حذف سکوت") and is_JoinChannel(msg) then
						ReplySet(msg,"unsilent")
					elseif CmdMatches and (CmdMatches:match('^kick (.*)') or CmdMatches:match('^اخراج (.*)')) and is_JoinChannel(msg) then
						local Matches = CmdMatches:match('^kick (.*)') or CmdMatches:match('^اخراج (.*)')
						UseridSet(msg, Matches ,"kick")
					elseif CmdMatches and (CmdMatches:match('^delall (.*)') or CmdMatches:match('^حذف پیام (.*)')) and is_JoinChannel(msg) then
						local Matches = CmdMatches:match('^delall (.*)') or CmdMatches:match('^حذف پیام (.*)')
						UseridSet(msg, Matches ,"delall")
					elseif CmdMatches and (CmdMatches:match('^ban (.*)') or CmdMatches:match('^مسدود (.*)')) and is_JoinChannel(msg) then
						local Matches = CmdMatches:match('^ban (.*)') or CmdMatches:match('^مسدود (.*)')
						UseridSet(msg, Matches ,"ban")
					elseif CmdMatches and (CmdMatches:match('^unban (.*)') or CmdMatches:match('^حذف مسدود (.*)')) and is_JoinChannel(msg) then
						local Matches = CmdMatches:match('^unban (.*)') or CmdMatches:match('^حذف مسدود (.*)')
						UseridSet(msg, Matches ,"unban")
					elseif CmdMatches and (CmdMatches:match('^mute (.*)') or CmdMatches:match('^سکوت (.*)')) and is_JoinChannel(msg) then
						local Matches = CmdMatches:match('^mute (.*)') or CmdMatches:match('^سکوت (.*)')
						UseridSet(msg, Matches ,"silent")
					elseif CmdMatches and (CmdMatches:match('^unmute (.*)') or CmdMatches:match('^حذف سکوت (.*)')) and is_JoinChannel(msg) then
						local Matches = CmdMatches:match('^unmute (.*)') or CmdMatches:match('^حذف سکوت (.*)')
						UseridSet(msg, Matches ,"unsilent")
					
						elseif CmdMatches == "clean msg" or CmdMatches == "پاکسازی" then
					text = "*تمامی پیام ها در حال حذف شدن میباشند ! *\n`در حال بررسی اعضا ...`"
						tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. "_دستور پاکسازی موفق_\n_همه ی پیام ها با موفقیت حذف شدند_✅", 0, 'md')
					 os.execute("sleep ".. 3)
					function check_members(extra , result)
						local count = result.total_count - 1
						if count > (200 or 199) then
							count = 198
						end
						while count > -1 do
							tdbot.deleteMessagesFromUser(msg.to.id,  result.members[count].user_id, dl_cb, nil)
							count = count - 1
						end
						tdbot.sendMessage(msg.chat_id , msg.id, 1, Source_Start.. "*تمامی پیام ها در حال حذف شدن میباشند ! *\n`در حال بررسی اعضا ...`", 0, 'md')
					end
					
					local function cb(arg,data)
						for k,v in pairs(data.messages) do
							del_msg(msg.chat_id, v.id)
						end
					end
					for i = 1, 5 do
						tdbot.getChatHistory(msg.to.id, msg.id, 0,  500000000, 0, cb, nil)
					end
					for i = 1, 2 do
						tdbot.getChannelMembers(msg.to.id, 0, 20000, "Search", check_members, nil)
					end
					for i = 1, 1 do
						tdbot.getChannelMembers(msg.to.id, 0, 200000, "Recent", check_members, nil)
					end
					for i = 1, 5 do
						tdbot.getChannelMembers(msg.to.id, 0, 2000000000, "Banned", check_members, nil)
					end
					
					
			
				if msg.text then
					local is_link = msg.text:match("^بله$") or msg.text:match("^yes$")
					if is_link and redis:get(Alpha..msg.to.id..'CleanMsg') then
						redis:set(Alpha..msg.to.id..'CleanMsgSet', msg.text)
						function check_members(extra , result)
                        if result.messages then
                        for k,v in pairs(result.messages) do
                          del_msg(msg.chat_id, v.id)
                        end
                       end
                          end
						  
                          function clean_msgs(extra, result)
                        if result.members then
                       for k,v in pairs(result.members) do
                        tdbot.deleteMessagesFromUser(msg.to.id, v.user_id, dl_cb, nil)
                         end
                       end
                           end
						   
                           for i=1 , 2 do
                          tdbot.getChannelMembers(msg.to.id, 0, 1000, "Recent", clean_msgs, nil)
                          tdbot.getChannelMembers(msg.to.id, 0, 1000, "Search", clean_msgs, nil)
                           tdbot.getChannelMembers(msg.to.id, 0, 1000, "Banned", clean_msgs, nil)
                        tdbot.getChannelMembers(msg.to.id, 0, 1000, "Bots", clean_msgs, nil)
                       tdbot.getChatHistory(msg.to.id, msg.id, 0,1000, 0, cb, nil)
                       end	
                       sleep(10)					   
                       redis:setex(Alpha..msg.to.id..'CleanMsg', 60, true)
					text = Source_Start.. '_مدیر برای پاکسازی دوباره لطفا کلمه بله ارسال کنید_❗️'
					tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				
					end
				end
			
						elseif CmdMatches == "clean msg" or CmdMatches == "کاهش پیام" then
                                             
						function check_members(extra , result)
                        if result.messages then
                        for k,v in pairs(result.messages) do
                          del_msg(msg.chat_id, v.id)
                        end
                       end
                          end
						  
                          function clean_msgs(extra, result)
                        if result.members then
                       for k,v in pairs(result.members) do
                        tdbot.deleteMessagesFromUser(msg.to.id, v.user_id, dl_cb, nil)
                         end
                       end
                           end
						   
                           for i=1 , 2 do
                          tdbot.getChannelMembers(msg.to.id, 0, 1000, "Recent", clean_msgs, nil)
                          tdbot.getChannelMembers(msg.to.id, 0, 1000, "Search", clean_msgs, nil)
                           tdbot.getChannelMembers(msg.to.id, 0, 1000, "Banned", clean_msgs, nil)
                        tdbot.getChannelMembers(msg.to.id, 0, 1000, "Bots", clean_msgs, nil)
                       tdbot.getChatHistory(msg.to.id, msg.id, 0,1000, 0, cb, nil)
                       end	 
                    sleep(10)						   
                       redis:setex(Alpha..msg.to.id..'CleanMsg', 60, true)
					text = Source_Start.. '_مدیر برای پاکسازی دوباره لطفا کلمه بله ارسال کنید_❗️'
					tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
                  end
				  end
						
				  
				if CmdMatches and (CmdMatches:match('^warn (.*)') or CmdMatches:match('^اخطار (.*)')) and is_JoinChannel(msg) then
					local CmdEn = {
					string.match(CmdMatches, "^(warn) (.*)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(اخطار) (.*)$")
					}
					if CmdEn[2] == "link" or CmdFa[2] == "لینک"  then
						Lock_Delmsg_warn(msg, 'lock_link', "لینک")
					elseif CmdEn[2] == "tag" or CmdFa[2] == "تگ" or CmdFa[2] == "هشتگ" then
						Lock_Delmsg_warn(msg, "lock_tag", "تگ")
					elseif CmdEn[2] == "views" or CmdFa[2] == "ویو" or CmdFa[2] == "سین"  then
						Lock_Delmsg_warn(msg, "lock_views", "ویو")
					elseif CmdEn[2] == "username" or CmdFa[2] == "نام کاربری" or CmdFa[2] == "یوزرنیم" then
						Lock_Delmsg_warn(msg, "lock_username", "نام کاربری")
					elseif CmdEn[2] == "mention" or CmdFa[2] == "منشن" or CmdFa[2] == "هایپرلینک" then
						Lock_Delmsg_warn(msg, "lock_mention", "منشن")
					elseif CmdEn[2] == "farsi" or CmdFa[2] == "فارسی" then
						Lock_Delmsg_warn(msg, "lock_arabic", "فارسی")
					elseif CmdEn[2] == "english" or CmdFa[2] == "انگلیسی" then
						Lock_Delmsg_warn(msg, "lock_english", "انگلیسی")
					elseif CmdEn[2] == "edit" or CmdFa[2] == "ویرایش" then
						Lock_Delmsg_warn(msg, "lock_edit", "ویرایش")
					elseif CmdEn[2] == "markdown" or CmdFa[2] == "فونت" then
						Lock_Delmsg_warn(msg, "lock_markdown", "فونت")
					elseif CmdEn[2] == "webpage" or CmdFa[2] == "وب" then
						Lock_Delmsg_warn(msg, "lock_webpage", "وب")
					elseif CmdEn[2] == "gif" or CmdFa[2] == "گیف" then
						Lock_Delmsg_warn(msg, "mute_gif", "گیف")
					elseif CmdEn[2] == "text" or CmdFa[2] == "متن" then
						Lock_Delmsg_warn(msg, "mute_text", "متن")
					elseif CmdEn[2] == "photo" or CmdFa[2] == "عکس" then
						Lock_Delmsg_warn(msg, "mute_photo", "عکس")
					elseif CmdEn[2] == "video" or CmdFa[2] == "فیلم" then
						Lock_Delmsg_warn(msg, "mute_video", "فیلم")
					elseif CmdEn[2] == "video_note" or CmdFa[2] == "فیلم سلفی" or CmdFa[2] == "سلفی" then
						Lock_Delmsg_warn(msg, "mute_video_note", "فیلم سلفی")
					elseif CmdEn[2] == "audio" or CmdFa[2] == "اهنگ" then
						Lock_Delmsg_warn(msg, "mute_audio", "آهنگ")
					elseif CmdEn[2] == "voice" or CmdFa[2] == "صدا" or CmdFa[2] == "ویس" then
						Lock_Delmsg_warn(msg, "mute_voice", "صدا")
					elseif CmdEn[2] == "sticker" or CmdFa[2] == "استیکر" then
						Lock_Delmsg_warn(msg, "mute_sticker", "استیکر")
					elseif CmdEn[2] == "contact" or CmdFa[2] == "مخاطب" then
						Lock_Delmsg_warn(msg, "mute_contact", "مخاطب")
					elseif CmdEn[2] == "forward" or CmdFa[2] == "فوروارد کانال" then
						Lock_Delmsg_warn(msg, "mute_forward", "فوروارد کانال")
					elseif CmdEn[2] == "forward user" or CmdFa[2] == "فوروارد کاربر" then
						Lock_Delmsg_warn(msg, "mute_forwarduser", "فوروارد کاربر")
					elseif CmdEn[2] == "location" or CmdFa[2] == "موقعیت" then
						Lock_Delmsg_warn(msg, "mute_location", "موقعیت")
					elseif CmdEn[2] == "document" or CmdFa[2] == "فایل" then
						Lock_Delmsg_warn(msg, "mute_document", "فایل")
					elseif CmdEn[2] == "inline" or CmdFa[2] == "کیبورد شیشه ای" or CmdFa[2] == "اینلاین" then
						Lock_Delmsg_warn(msg, "mute_inline", "کیبورد شیشه ای")
					elseif CmdEn[2] == "game" or CmdFa[2] == "بازی" then
						Lock_Delmsg_warn(msg, "mute_game", "بازی")
					elseif CmdEn[2] == "keyboard" or CmdFa[2] == "صفحه کلید" or CmdFa[2] == "کیبورد" then
						Lock_Delmsg_warn(msg, "mute_keyboard", "صفحه کلید")
					end
				end
				if (CmdMatches == "setvip" or CmdMatches == "مجاز") and is_JoinChannel(msg) then
					ReplySet(msg,"setwhitelist")
				elseif (CmdMatches == "remvip" or CmdMatches == "حذف مجاز") and is_JoinChannel(msg) then
					ReplySet(msg,"remwhitelist")
				elseif (CmdMatches == "warn" or CmdMatches == "اخطار") and is_JoinChannel(msg) then
					ReplySet(msg,"warn")
				elseif (CmdMatches == "unwarn" or CmdMatches == "حذف اخطار") and is_JoinChannel(msg) then
					ReplySet(msg,"unwarn")
				elseif CmdMatches and (CmdMatches:match('^setvip (.*)') or CmdMatches:match('^مجاز (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^setvip (.*)') or CmdMatches:match('^مجاز (.*)')
					UseridSet(msg, Matches ,"setwhitelist")
				elseif CmdMatches and (CmdMatches:match('^remvip (.*)') or CmdMatches:match('^حذف مجاز (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^remvip (.*)') or CmdMatches:match('^حذف مجاز (.*)')
					UseridSet(msg, Matches ,"remwhitelist")
				elseif CmdMatches and (CmdMatches:match('^warn (.*)') or CmdMatches:match('^اخطار (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^warn (.*)') or CmdMatches:match('^اخطار (.*)')
					UseridSet(msg, Matches ,"warn")
				elseif CmdMatches and (CmdMatches:match('^unwarn (.*)') or CmdMatches:match('^حذف اخطار (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^unwarn (.*)') or CmdMatches:match('^حذف اخطار (.*)')
					UseridSet(msg, Matches ,"unwarn")
				
			elseif CmdMatches and (CmdMatches:match('^lock (.*)') or CmdMatches:match('^قفل (.*)')) and is_JoinChannel(msg) then
					local CmdEn = {
					string.match(CmdMatches, "^(lock) (.*)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(قفل) (.*)$")
					}
					if CmdEn[2] == "tgservice" or CmdFa[2] == "سرویس تلگرام" or CmdFa[2] == "سرویس" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
						Lock_Delmsg(msg, "mute_tgservice", "سرویس تلگرام")
						else
						Lock_Delmsg(msg, "mute_tgservice", "سرویس تلگرام")
						end
						elseif CmdEn[2] == "link" or CmdFa[2] == "لینک" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Link:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, 'lock_link', "لینک") 
					else
						Lock_Delmsg(msg, 'lock_link', "لینک") 
						end
						------------------------
					elseif CmdEn[2] == "tag" or CmdFa[2] == "تگ" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Tage:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, 'lock_tag', "تگ") 
						else
						Lock_Delmsg(msg, "lock_tag", "تگ")
						end
						---------------------
					elseif CmdEn[2] == "views" or CmdFa[2] == "ویو" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Viwe:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, 'lock_views', "ویو") 
						else
						Lock_Delmsg(msg, "lock_views", "ویو")
						end
					-----------------------------------
					elseif CmdEn[2] == "username" or CmdFa[2] == "نام کاربری" or CmdFa[2] == "یوزرنیم" then
						inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
						local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Usef:"..msg.to.id, 0, inline_query_cb, nil)
						Lock_Delmsge(msg, 'lock_username', "نام کاربری") 
						else
						Lock_Delmsg(msg, "lock_username", "نام کاربری")
						end
					---------------------------------------------------------
					elseif CmdEn[2] == "mention" or CmdFa[2] == "منشن" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
						local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Ment:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, 'lock_mention', "منشن") 
					else
						Lock_Delmsg(msg, "lock_mention", "منشن")
						end
					--------------------------------------------------
					elseif CmdEn[2] == "farsi" or CmdFa[2] == "فارسی" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Fars:"..msg.to.id, 0, inline_query_cb, nil)
						Lock_Delmsge(msg, 'lock_arabic', "فارسی") 
						else
						Lock_Delmsg(msg, "lock_arabic", "فارسی")
						end
					--------------------------------------------------------
					elseif CmdEn[2] == "english" or CmdFa[2] == "انگلیسی" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id) 
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Engl:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, 'lock_english', "انگلیسی") 
					else
						Lock_Delmsg(msg, "lock_english", "انگلیسی")
						end
					--------------------------------------------------------------------
					elseif CmdEn[2] == "edit" or CmdFa[2] == "ویرایش" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Edit:"..msg.to.id, 0, inline_query_cb, nil)
						Lock_Delmsge(msg, 'lock_edit', "ویرایش") 
					else
						Lock_Delmsg(msg, "lock_edit", "ویرایش")
						end
					
					elseif CmdEn[2] == "spam" or CmdFa[2] == "هرزنامه" or CmdFa[2] == "اسپم" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
						Lock_Delmsg(msg, "lock_spam", "هرزنامه")
						else
						Lock_Delmsg(msg, "lock_spam", "هرزنامه")
						end
					
					elseif CmdEn[2] == "flood" or CmdFa[2] == "پیام مکرر" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
						Lock_Delmsg(msg, "lock_flood", "پیام مکرر")
						else
						Lock_Delmsg(msg, "lock_flood", "پیام مکرر")
						end
					
					elseif CmdEn[2] == "bots" or CmdFa[2] == "ربات" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
						Lock_Delmsg(msg, "lock_bots", "ربات")
						else
						Lock_Delmsg(msg, "lock_bots", "ربات")
						end
					
					elseif CmdEn[2] == "bots pro" or CmdFa[2] == "اضافه کننده ربات" then
						if redis:get(Alpha..'lock_bots:'..msg.chat_id) == 'Pro' then
							local rfa = Source_Start.. "قفل اضافه کننده ربات فعال بود️❗\nحالت قفل :مسدود اضافه کننده ربات"
							--tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md')
						else
							local rfa = Source_Start.. "قفل اضافه کننده ربات غیرفعال شد\n"..Source_Start.." توسط\n*"..msg.from.id.."*-@"..check_markdown(msg.from.username or '').."\n"..Source_Start.." حالت قفل: مسدود اضافه کننده ربات"
							--tdbot.sendMessage(msg.chat_id , msg.id, 1, rfa, 0, 'md')
							redis:set(Alpha..'lock_bots:'..msg.chat_id, 'Pro')
						end
					elseif CmdEn[2] == "markdown" or CmdFa[2] == "فونت" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Font:"..msg.to.id, 0, inline_query_cb, nil)
                        Lock_Delmsge(msg, 'lock_markdown', "فونت") 					
					else
						Lock_Delmsg(msg, "lock_markdown", "فونت")
						end
					---------------------------------------
					elseif CmdEn[2] == "webpage" or CmdFa[2] == "وب" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Webe:"..msg.to.id, 0, inline_query_cb, nil)
						Lock_Delmsge(msg, 'lock_webpage', "وب") 	
						
						else
						Lock_Delmsg(msg, "lock_webpage", "وب")
						end
						---------------------------------------
					elseif CmdEn[2] == "tabchi" or CmdFa[2] == "تبچی" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
						Lock_Delmsg(msg, "lock_tabchi", "تبچی")
						else
						Lock_Delmsg(msg, "lock_tabchi", "تبچی")
						end
					elseif (CmdEn[2] == "pin" or CmdFa[2] == "سنجاق") and is_owner(msg) then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
						Lock_Delmsg(msg, "lock_pin", "سنجاق")
						else
						Lock_Delmsg(msg, "lock_pin", "سنجاق")
						end
					elseif CmdEn[2] == "join" or CmdFa[2] == "ورود" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					Lock_Delmsg(msg, "lock_join", "ورود")
						else
						Lock_Delmsg(msg, "lock_join", "ورود")
						end
					
					elseif CmdEn[2] == "gif" or CmdFa[2] == "گیف" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Gife:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, 'mute_gif', "گیف") 
					else
						Lock_Delmsg(msg, "mute_gif", "گیف")
						end
					elseif CmdEn[2] == "text" or CmdFa[2] == "متن" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Txte:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, 'mute_text', "متن") 
					else
						Lock_Delmsg(msg, "mute_text", "متن")
						end
					elseif CmdEn[2] == "photo" or CmdFa[2] == "عکس" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Phot:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, "mute_photo", "عکس")
					else
						Lock_Delmsg(msg, "mute_photo", "عکس")
						end
					elseif CmdEn[2] == "video" or CmdFa[2] == "فیلم" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Flim:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, "mute_video", "فیلم")
					else
					
						Lock_Delmsg(msg, "mute_video", "فیلم")
						end
					elseif CmdEn[2] == "video_note" or CmdFa[2] == "فیلم سلفی" or CmdFa[2] == "سلفی" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Self:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, "mute_video_note", "فیلم سلفی")
					else
						Lock_Delmsg(msg, "mute_video_note", "فیلم سلفی")
						end
					elseif CmdEn[2] == "audio" or CmdFa[2] == "اهنگ" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Musi:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, "mute_audio", "آهنگ")
					else
						Lock_Delmsg(msg, "mute_audio", "آهنگ")
						end
					elseif CmdEn[2] == "voice" or CmdFa[2] == "صدا" or CmdFa[2] == "ویس" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Vice:"..msg.to.id, 0, inline_query_cb, nil)
						Lock_Delmsge(msg, "mute_voice", "صدا")
						else
						Lock_Delmsg(msg, "mute_voice", "صدا")
						end
					elseif CmdEn[2] == "sticker" or CmdFa[2] == "استیکر" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Stic:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, "mute_sticker", "استیکر")
					else
						Lock_Delmsg(msg, "mute_sticker", "استیکر")
						end
					elseif CmdEn[2] == "contact" or CmdFa[2] == "مخاطب" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Cont:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, "mute_contact", "مخاطب")
					else
						Lock_Delmsg(msg, "mute_contact", "مخاطب")
						end
					elseif CmdEn[2] == "forward" or CmdFa[2] == "فوروارد کانال" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "FwdC:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, "mute_forward", "فوروارد کانال")
					else
						Lock_Delmsg(msg, "mute_forward", "فوروارد کانال")
						end
					elseif CmdEn[2] == "forward user" or CmdFa[2] == "فوروارد کاربر" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Fwdu:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, "mute_forwarduser", "فوروارد کاربر")
					else
						Lock_Delmsg(msg, "mute_forwarduser", "فوروارد کاربر")
						end
						
					elseif CmdEn[2] == "location" or CmdFa[2] == "موقعیت" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Maki:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, "mute_location", "موقعیت")
					else
						Lock_Delmsg(msg, "mute_location", "موقعیت")
						end
					elseif CmdEn[2] == "document" or CmdFa[2] == "فایل" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "File:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, "mute_document", "فایل")
					else
						Lock_Delmsg(msg, "mute_document", "فایل")
						end
					
					elseif CmdEn[2] == "inline" or CmdFa[2] == "کیبورد شیشه ای" or CmdFa[2] == "اینلاین" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Inli:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, "mute_inline", "کیبورد شیشهای")
					else
						Lock_Delmsg(msg, "mute_inline", "کیبورد شیشهای")
						end
					elseif CmdEn[2] == "game" or CmdFa[2] == "بازی" then
						Lock_Delmsg(msg, "mute_game", "بازی")
					elseif CmdEn[2] == "keyboard" or CmdFa[2] == "صفحه کلید"  or CmdFa[2] == "کیبورد" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							return 
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Keyb:"..msg.to.id, 0, inline_query_cb, nil)
					Lock_Delmsge(msg, "mute_keyboard", "صفحه کلید")
					else
						Lock_Delmsg(msg, "mute_keyboard", "صفحه کلید")
						end
					elseif CmdEn[2] == "cmds" or CmdFa[2] == "دستورات" then
						--tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start.. " قفل دستورات فعال شد.\n"..Source_Start.." توسط\n*"..msg.from.id.."* - @"..check_markdown(msg.from.username or '').."\n"..Source_Start.." حالت قفل :پاسخ ندادن ربات به دستورات", 1, 'md')
						redis:set(Alpha.."lock_cmd"..msg.chat_id,true)
					
					elseif CmdEn[2] == "all" or CmdFa[2] == "همه" then
					inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
					if inline == 'Enable' then
						Lock_Delmsg(msg, "mute_all", "همه")
					else
					Lock_Delmsg(msg, "mute_all", "همه")
					end
					end
					

					
				elseif CmdMatches and (CmdMatches:match('^ban (.*)') or CmdMatches:match('^مسدود (.*)')) and is_JoinChannel(msg) then
					local CmdEn = {
					string.match(CmdMatches, "^(ban) (.*)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(مسدود) (.*)$")
					}
					if CmdEn[2] == "link" or CmdFa[2] == "لینک" then
						Lock_Delmsg_kick(msg, 'lock_link', "لینک")
					elseif CmdEn[2] == "tag" or CmdFa[2] == "تگ" then
						Lock_Delmsg_kick(msg, "lock_tag", "تگ")
					elseif CmdEn[2] == "views" or CmdFa[2] == "ویو" then
						Lock_Delmsg_kick(msg, "lock_views", "ویو")
					elseif CmdEn[2] == "username" or CmdFa[2] == "نام کاربری" or CmdFa[2] == "یوزرنیم" then
						Lock_Delmsg_kick(msg, "lock_username", "نام کاربری")
					elseif CmdEn[2] == "mention" or CmdFa[2] == "منشن" then
						Lock_Delmsg_kick(msg, "lock_mention", "منشن")
					elseif CmdEn[2] == "farsi" or CmdFa[2] == "فارسی" then
						Lock_Delmsg_kick(msg, "lock_arabic", "فارسی")
					elseif CmdEn[2] == "english" or CmdFa[2] == "انگلیسی" then
						Lock_Delmsg_kick(msg, "lock_english", "انگلیسی")
					elseif CmdEn[2] == "edit" or CmdFa[2] == "ویرایش" then
						Lock_Delmsg_kick(msg, "lock_edit", "ویرایش")
					elseif CmdEn[2] == "markdown" or CmdFa[2] == "فونت" then
						Lock_Delmsg_kick(msg, "lock_markdown", "فونت")
					elseif CmdEn[2] == "webpage" or CmdFa[2] == "وب" then
						Lock_Delmsg_kick(msg, "lock_webpage", "وب")
					elseif CmdEn[2] == "gif" or CmdFa[2] == "گیف" then
						Lock_Delmsg_kick(msg, "mute_gif", "گیف")
					elseif CmdEn[2] == "text" or CmdFa[2] == "متن" then
						Lock_Delmsg_kick(msg, "mute_text", "متن")
					elseif CmdEn[2] == "photo" or CmdFa[2] == "عکس" then
						Lock_Delmsg_kick(msg, "mute_photo", "عکس")
					elseif CmdEn[2] == "video" or CmdFa[2] == "فیلم" then
						Lock_Delmsg_kick(msg, "mute_video", "فیلم")
					elseif CmdEn[2] == "video_note" or CmdFa[2] == "فیلم سلفی" or CmdFa[2] == "سلفی" then
						Lock_Delmsg_kick(msg, "mute_video_note", "فیلم سلفی")
					elseif CmdEn[2] == "audio" or CmdFa[2] == "اهنگ" then
						Lock_Delmsg_kick(msg, "mute_audio", "آهنگ")
					elseif CmdEn[2] == "voice" or CmdFa[2] == "صدا" or CmdFa[2] == "ویس" then
						Lock_Delmsg_kick(msg, "mute_voice", "صدا")
					elseif CmdEn[2] == "sticker" or CmdFa[2] == "استیکر" then
						Lock_Delmsg_kick(msg, "mute_sticker", "استیکر")
					elseif CmdEn[2] == "contact" or CmdFa[2] == "مخاطب" then
						Lock_Delmsg_kick(msg, "mute_contact", "مخاطب")
					elseif CmdEn[2] == "forward" or CmdFa[2] == "فوروارد کانال" then
						Lock_Delmsg_kick(msg, "mute_forward", "فوروارد کانال")
					elseif CmdEn[2] == "forward user" or CmdFa[2] == "فوروارد کاربر" then
						Lock_Delmsg_kick(msg, "mute_forwarduser", "فوروارد کاربر")
					elseif CmdEn[2] == "location" or CmdFa[2] == "موقعیت" then
						Lock_Delmsg_kick(msg, "mute_location", "موقعیت")
					elseif CmdEn[2] == "document" or CmdFa[2] == "فایل" then
						Lock_Delmsg_kick(msg, "mute_document", "فایل")
					elseif CmdEn[2] == "inline" or CmdFa[2] == "کیبورد شیشه ای" or CmdFa[2] == "اینلاین" then
						Lock_Delmsg_kick(msg, "mute_inline", "کیبورد شیشه ای")
					elseif CmdEn[2] == "game" or CmdFa[2] == "بازی" then
						Lock_Delmsg_kick(msg, "mute_game", "بازی")
					elseif CmdEn[2] == "keyboard" or CmdFa[2] == "صفحه کلید" or CmdFa[2] == "کیبورد" then
						Lock_Delmsg_kick(msg, "mute_keyboard", "صفحه کلید")
					end
				elseif CmdMatches and (CmdMatches:match('^mute (.*)') or CmdMatches:match('^سکوت (.*)')) and is_JoinChannel(msg) then
					local CmdEn = {
					string.match(CmdMatches, "^(mute) (.*)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(سکوت) (.*)$")
					}
					if CmdEn[2] == "link" or CmdFa[2] == "لینک" then
						Lock_Delmsg_mute(msg, 'lock_link', "لینک")
					elseif CmdEn[2] == "tag" or CmdFa[2] == "تگ" then
						Lock_Delmsg_mute(msg, "lock_tag", "تگ")
					elseif CmdEn[2] == "views" or CmdFa[2] == "ویو" then
						Lock_Delmsg_mute(msg, "lock_views", "ویو")
					elseif CmdEn[2] == "username" or CmdFa[2] == "نام کاربری" or CmdFa[2] == "یوزرنیم" then
						Lock_Delmsg_mute(msg, "lock_username", "نام کاربری")
					elseif CmdEn[2] == "mention" or CmdFa[2] == "منشن" then
						Lock_Delmsg_mute(msg, "lock_mention", "منشن")
					elseif CmdEn[2] == "farsi" or CmdFa[2] == "فارسی" then
						Lock_Delmsg_mute(msg, "lock_arabic", "فارسی")
					elseif CmdEn[2] == "english" or CmdFa[2] == "انگلیسی" then
						Lock_Delmsg_mute(msg, "lock_english", "انگلیسی")
					elseif CmdEn[2] == "edit" or CmdFa[2] == "ویرایش" then
						Lock_Delmsg_mute(msg, "lock_edit", "ویرایش")
					elseif CmdEn[2] == "markdown" or CmdFa[2] == "فونت" then
						Lock_Delmsg_mute(msg, "lock_markdown", "فونت")
					elseif CmdEn[2] == "webpage" or CmdFa[2] == "وب" then
						Lock_Delmsg_mute(msg, "lock_webpage", "وب")
					elseif CmdEn[2] == "gif" or CmdFa[2] == "گیف" then
						Lock_Delmsg_mute(msg, "mute_gif", "گیف")
					elseif CmdEn[2] == "text" or CmdFa[2] == "متن" then
						Lock_Delmsg_mute(msg, "mute_text", "متن")
					elseif CmdEn[2] == "photo" or CmdFa[2] == "عکس" then
						Lock_Delmsg_mute(msg, "mute_photo", "عکس")
					elseif CmdEn[2] == "video" or CmdFa[2] == "فیلم" then
						Lock_Delmsg_mute(msg, "mute_video", "فیلم")
					elseif CmdEn[2] == "video_note" or CmdFa[2] == "فیلم سلفی" or CmdFa[2] == "سلفی" then
						Lock_Delmsg_mute(msg, "mute_video_note", "فیلم سلفی")
					elseif CmdEn[2] == "audio" or CmdFa[2] == "اهنگ" then
						Lock_Delmsg_mute(msg, "mute_audio", "آهنگ")
					elseif CmdEn[2] == "voice" or CmdFa[2] == "صدا" or CmdFa[2] == "ویس" then
						Lock_Delmsg_mute(msg, "mute_voice", "صدا")
					elseif CmdEn[2] == "sticker" or CmdFa[2] == "استیکر" then
						Lock_Delmsg_mute(msg, "mute_sticker", "استیکر")
					elseif CmdEn[2] == "contact" or CmdFa[2] == "مخاطب" then
						Lock_Delmsg_mute(msg, "mute_contact", "مخاطب")
					elseif CmdEn[2] == "forward" or CmdFa[2] == "فوروارد کانال" then
						Lock_Delmsg_mute(msg, "mute_forward", "فوروارد کانال")
					elseif CmdEn[2] == "forward user" or CmdFa[2] == "فوروارد کاربر" then
						Lock_Delmsg_mute(msg, "mute_forwarduser", "فوروارد کاربر")
					elseif CmdEn[2] == "location" or CmdFa[2] == "موقعیت" then
						Lock_Delmsg_mute(msg, "mute_location", "موقعیت")
					elseif CmdEn[2] == "document" or CmdFa[2] == "فایل" then
						Lock_Delmsg_mute(msg, "mute_document", "فایل")
					elseif CmdEn[2] == "inline" or CmdFa[2] == "کیبورد شیشه ای" or CmdFa[2] == "اینلاین" then
						Lock_Delmsg_mute(msg, "mute_inline", "کیبورد شیشه ای")
					elseif CmdEn[2] == "game" or CmdFa[2] == "بازی" then
						Lock_Delmsg_mute(msg, "mute_game", "بازی")
					elseif CmdEn[2] == "keyboard" or CmdFa[2] == "صفحه کلید" or CmdFa[2] == "کیبورد" then
						Lock_Delmsg_mute(msg, "mute_keyboard", "صفحه کلید")
					end
				elseif CmdMatches and (CmdMatches:match('^unlock (.*)') or CmdMatches:match('^بازکردن (.*)') or CmdMatches:match('^باز کردن (.*)')) and is_JoinChannel(msg) then
					local CmdEn = {
					string.match(CmdMatches, "^(unlock) (.*)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(باز کردن) (.*)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(بازکردن) (.*)$")
					}
					if CmdEn[2] == 'auto' or CmdFa[2] == 'گروه' then
							redis:del(Alpha.."MuteAll"..msg.chat_id)
							--tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start..' کاربران عزیزم\nتوجه کنید گروه فوق\nبه صورت کامل باز شد!😃\n──══─✦─══──\nبازکننده:@'..check_markdown(msg.from.username or '')..'', 1, 'md')
						
						elseif CmdEn[2] == "auto" or CmdFa[2] == "خودکار" then
						redis:del(Alpha.."atolct1"..msg.to.id)
						redis:del(Alpha.."atolct2"..msg.to.id)
						redis:del(Alpha.."lc_ato:"..msg.to.id)
					--tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start..' کاربران عزیزم\nقفل خودکار گروه \nبه صورت کامل باز شد!😃\n──══─✦─══──\nبازکننده:@'..check_markdown(msg.from.username or '')..'', 1, 'md')

					elseif CmdEn[2] == "link" or CmdFa[2] == "لینک" then
						Unlock_Delmsg(msg, 'lock_link', "لینک")
					elseif CmdEn[2] == "tag" or CmdFa[2] == "تگ" then
						Unlock_Delmsg(msg, "lock_tag", "تگ")
					elseif CmdEn[2] == "views" or CmdFa[2] == "ویو" then
						Unlock_Delmsg(msg, "lock_views", "ویو")
					elseif CmdEn[2] == "username" or CmdFa[2] == "نام کاربری" or CmdFa[2] == "یوزرنیم" then
						Unlock_Delmsg(msg, "lock_username", "نام کاربری")
					elseif CmdEn[2] == "mention" or CmdFa[2] == "منشن" then
						Unlock_Delmsg(msg, "lock_mention", "منشن")
					elseif CmdEn[2] == "farsi" or CmdFa[2] == "فارسی" then
						Unlock_Delmsg(msg, "lock_arabic", "فارسی")
					elseif CmdEn[2] == "english" or CmdFa[2] == "انگلیسی" then
						Unlock_Delmsg(msg, "lock_english", "انگلیسی")
					elseif CmdEn[2] == "edit" or CmdFa[2] == "ویرایش" then
						Unlock_Delmsg(msg, 'lock_edit', "ویرایش")
					elseif CmdEn[2] == "spam" or CmdFa[2] == "هرزنامه" then
						Unlock_Delmsg(msg, 'lock_spam', "هرزنامه")
					elseif CmdEn[2] == "flood" or CmdFa[2] == "پیام مکرر" then
						Unlock_Delmsg(msg, 'lock_flood', "پیام مکرر")
					elseif CmdEn[2] == "bots" or CmdFa[2] == "ربات" then
						Unlock_Delmsg(msg, 'lock_bots', "ربات")
					elseif CmdEn[2] == "markdown" or CmdFa[2] == "فونت" then
						Unlock_Delmsg(msg, "lock_markdown", "فونت")
					elseif CmdEn[2] == "webpage" or CmdFa[2] == "وب" then
						Unlock_Delmsg(msg, "lock_webpage", "وب")
					elseif CmdEn[2] == "tabchi" or CmdFa[2] == "تبچی" then
						Unlock_Delmsg(msg, "lock_tabchi", "تبچی")
					elseif (CmdEn[2] == "pin" or CmdFa[2] == "سنجاق") and is_owner(msg) then
						Unlock_Delmsg(msg, 'lock_pin', "سنجاق")
					elseif CmdEn[2] == "join" or CmdFa[2] == "ورود" then
						Unlock_Delmsg(msg, 'lock_join', "ورود")
					elseif CmdEn[2] == "all" or CmdFa[2] == "همه" then
						Unlock_Delmsg(msg, "mute_all", "همه")
					elseif CmdEn[2] == "gif" or CmdFa[2] == "گیف" then
						Unlock_Delmsg(msg, "mute_gif", "گیف")
					elseif CmdEn[2] == "text" or CmdFa[2] == "متن" then
						Unlock_Delmsg(msg, "mute_text", "متن")
					elseif CmdEn[2] == "photo" or CmdFa[2] == "عکس" then
						Unlock_Delmsg(msg, "mute_photo", "عکس")
					elseif CmdEn[2] == "video" or CmdFa[2] == "فیلم" then
						Unlock_Delmsg(msg, "mute_video", "فیلم")
					elseif CmdEn[2] == "video_note" or CmdFa[2] == "فیلم سلفی" or CmdFa[2] == "سلفی" then
						Unlock_Delmsg(msg, "mute_video_note", "فیلم سلفی")
					elseif CmdEn[2] == "audio" or CmdFa[2] == "اهنگ" then
						Unlock_Delmsg(msg, "mute_audio", "آهنگ")
					elseif CmdEn[2] == "voice" or CmdFa[2] == "صدا"  or CmdFa[2] == "ویس" then
						Unlock_Delmsg(msg, "mute_voice", "صدا")
					elseif CmdEn[2] == "sticker" or CmdFa[2] == "استیکر" then
						Unlock_Delmsg(msg, "mute_sticker", "استیکر")
					elseif CmdEn[2] == "contact" or CmdFa[2] == "مخاطب" then
						Unlock_Delmsg(msg, "mute_contact", "مخاطب")
					elseif CmdEn[2] == "forward" or CmdFa[2] == "فوروارد کانال" then
						Unlock_Delmsg(msg, "mute_forward", "فوروارد کانال")
					elseif CmdEn[2] == "forward user" or CmdFa[2] == "فوروارد کاربر" then
						Unlock_Delmsg(msg, "mute_forwarduser", "فوروارد کاربر")
					elseif CmdEn[2] == "location" or CmdFa[2] == "موقعیت" then
						Unlock_Delmsg(msg, "mute_location", "موقعیت")
					elseif CmdEn[2] == "document" or CmdFa[2] == "فایل" then
						Unlock_Delmsg(msg, "mute_document", "فایل")
					elseif CmdEn[2] == "tgservice" or CmdFa[2] == "سرویس تلگرام" or CmdFa[2] == "سرویس" then
						Unlock_Delmsg(msg, "mute_tgservice", "سرویس تلگرام")
					elseif CmdEn[2] == "inline" or CmdFa[2] == "کیبورد شیشه ای" or CmdFa[2] == "اینلاین" then
						Unlock_Delmsg(msg, "mute_inline", "کیبورد شیشه ای")
					elseif CmdEn[2] == "game" or CmdFa[2] == "بازی" then
						Unlock_Delmsg(msg, "mute_game", "بازی")
					elseif CmdEn[2] == "keyboard" or CmdFa[2] == "صفحه کلید" or CmdFa[2] == "کیبورد" then
						Unlock_Delmsg(msg, "mute_keyboard", "صفحه کلید")
					elseif CmdEn[2] == "cmds" or CmdFa[2] == "دستورات" then
						--tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start.."قفل دستورات غیر فعال شد.\n"..Source_Start.." توسط\n *"..msg.from.id.."* - @"..check_markdown(msg.from.username or '').."", 1, 'md')
						redis:del(Alpha.."lock_cmd"..msg.chat_id)
					end
				end
				if msg.to.type == "channel" then
					if (CmdMatches == "gpinfo" or CmdMatches == "اطلاعات گروه") and is_JoinChannel(msg) then
						local function group_info(arg, data)
							if data.description and data.description ~= "" then
								des = check_markdown(data.description)
							else
								des = ""
							end
							ginfo = Source_Start.." _مشخصات گروه به صورت ذیل است_:\n_تعداد ادمین ها درگروه_ : *"..data.administrator_count.."*\n_تعداد ممبر گروه_: *"..data.member_count.."*\n_تعداد اعضای مسدود شده_: *"..data.banned_count.."*\n_تعداد اعضای سکوت شده_: *"..data.restricted_count.."*\n_بیوگرافی گروه_: "..des
							--tdbot.sendMessage(arg.chat_id, arg.msg_id, 1, ginfo, 1, 'md')
						end
						tdbot.getChannelFull(msg.to.id, group_info, {chat_id=msg.to.id,msg_id=msg.id})
					elseif CmdMatches and (CmdMatches:match('^setabout (.*)') or CmdMatches:match('^تنظیم درباره (.*)')) and is_JoinChannel(msg) then
						local Matches = CmdMatches:match('^setabout (.*)') or CmdMatches:match('^تنظیم درباره (.*)')
						tdbot.changeChannelDescription(msg.to.id, Matches, dl_cb, nil)
						redis:set(Alpha..msg.to.id..'about', Matches)
						text = Source_Start.. "_بیوگرافی گروه در سیستم ربات با موفقیت تنظیم شد._"
						--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
				end
				
				if CmdMatches == "report on" or CmdMatches == "ارسال گزارشات روشن" then
				redis:set(Alpha..'sendreport'..msg.chat_id,true)
				--tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.." _ارسال گزارشات گروه به پیوی مدیر گروه روشن شد_", 1, 'md')
				end
				
			if CmdMatches == "report off"  or CmdMatches == "ارسال گزارشات خاموش" then
				redis:del(Alpha.."sendreport",msg.chat_id)
				--tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.."_ارسال گزارشات گروه به پیوی مدیر گروه خاموش شد_❗️", 1, 'md')
				end
				
				if CmdMatches and (CmdMatches:match('^setwelcome (.*)') or CmdMatches:match('^تنظیم خوش آمدگویی (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^setwelcome (.*)') or CmdMatches:match('^تنظیم خوش آمدگویی (.*)')
					redis:set(Alpha..'setwelcome:'..msg.chat_id, Matches)
					text = Source_Start.."_متن پیام خوش آمدگویی با موفقیت درسیستم ربات تنظیم شد_ :\n*"..Matches.."*\n\n_مدیر عزیز شما میتوانید با استفاده از دستورات زیر متن خوش آمد گویی را تنظیم کنید_\n{*gpname*} نام گروه\n{*rules*}_نمایش قوانین گروه_\n{*time*} _ساعت به زبان انگلیسی_\n{*date*}  _تاریخ به زبان انگلیسی _\n{*timefa*} _ساعت به زبان فارسی _\n{*datefa*} _تاریخ به زبان فارسی _\n{*name*}  _نام کاربر جدید_\n{*username*} _نام کاربری کاربر جدید_\nاستفاده کنید"
					--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif CmdMatches and (CmdMatchesL:match('^[Ss][Ee][Tt][Nn][Aa][Mm][Ee] (.*)') or CmdMatchesL:match('^تنظیم نام (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatchesL:match('^[Ss][Ee][Tt][Nn][Aa][Mm][Ee] (.*)') or CmdMatchesL:match('^تنظیم نام (.*)')
					--tdbot.changeChatTitle(msg.to.id, Matches)
				elseif CmdMatches and (CmdMatches:match('^res (.*)') or CmdMatches:match('^کاربری (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^res (.*)') or CmdMatches:match('^کاربری (.*)')
					tdbot_function ({
					_ = "searchPublicChat",
					username = Matches
					}, action_by_username, {chat_id=msg.to.id,username=Matches,cmd="res"})
				elseif CmdMatches and (CmdMatches:match('^setrules (.*)') or CmdMatches:match('^تنظیم قوانین (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^setrules (.*)') or CmdMatches:match('^تنظیم قوانین (.*)')
					redis:set(Alpha..msg.to.id..'rules', Matches)
					text = Source_Start.. "_قوانین کروه با موفقیت در سیستم ربات ثبت وتنظیم شد._"
					--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					
					------------------------------------------------------------
					elseif CmdMatches and (CmdMatches:match('^setid (.*)') or CmdMatches:match('^تنظیم مدیر (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^setid (.*)') or CmdMatches:match('^تنظیم مدیر (.*)')
					redis:set(Alpha..msg.to.id..'idrep', Matches)
					text = Source_Start.. "_یوزرآیدی مدیر ثبت شد._"
					--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					-------------------------------------------------------------
				elseif CmdMatches and (CmdMatches:match('^whois (%d+)') or CmdMatches:match('^شناسه (%d+)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^whois (%d+)') or CmdMatches:match('^شناسه (%d+)')
					tdbot_function ({
					_ = "getUser",
					user_id = Matches,
					}, action_by_id, {chat_id=msg.to.id,user_id=Matches,cmd="whois"})
				elseif (CmdMatches == "warnlist" or CmdMatches == "لیست اخطار") and is_JoinChannel(msg) then
					local list = Source_Start..'لیست اخطار :\n'
					local empty = list
					for k,v in pairs (redis:hkeys(Alpha..msg.to.id..':warn')) do
						local user_name = redis:get(Alpha..'user_name:'..v) or "---"
						local cont = redis:hget(Alpha..msg.to.id..':warn', v)
						if user_name then
							list = list..k..'- '..check_markdown(user_name)..' [`'..v..'`] \n*اخطار : '..(cont - 1)..'*\n'
						else
							list = list..k..'- `'..v..'` \n*اخطار : '..(cont - 1)..'*\n'
						end
					end
					
				elseif (CmdMatches == 'setdow' or CmdMatches == 'تنظیم دانلود') and is_JoinChannel(msg) then
					if redis:get(Alpha..'Num1Time:'..msg.to.id) and not is_admin(msg) then
						--tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.."`اجرای این دستور هر 1 ساعت یک بار ممکن است.`", 1, 'md')
					else
						redis:setex(Alpha..'Num1Time:'..msg.to.id, 3600, true)
						redis:setex(Alpha..'AutoDownload:'..msg.to.id, 1200, true)
						local text = Source_Start..'*با موفقیت ثبت شد.*\n`مدیران و مالک گروه  میتواند به مدت 20 دقیقه از دستوراتی که نیاز به دانلود دارند استفاده کنند`\n*'..Source_Start..' نکته :* اجرای این دستور هر 1 ساعت یک بار ممکن است.'
						--tdbot.sendMessage(msg.chat_id, msg.id, 1, text, 1, 'md')
					end
				elseif (CmdMatches == "del" or CmdMatches == "حذف") and is_JoinChannel(msg) and msg.reply_id then
					del_msg(msg.to.id, msg.reply_id)
					del_msg(msg.to.id, msg.id)
				elseif CmdMatches and (CmdMatches:match('^خوش آمدگویی (.*)') or CmdMatches:match('^خوش آمدگویی (.*)')) and is_JoinChannel(msg) then
					local CmdEn = {
					string.match(CmdMatches, "^(خوش آمدگویی) (.*)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(خوش آمدگویی) (.*)$")
					}
					if CmdEn[2] == "enable" or CmdFa[2] == "روشن"  then
						welcome = redis:get(Alpha..'welcome:'..msg.chat_id)
						if welcome == 'Enable' then
							text = Source_Start.. "_خوش آمدگویی گروه در سیستم ربات فعال بود❗️_"
							--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
						else
							redis:set(Alpha..'welcome:'..msg.chat_id, 'Enable')
							text = Source_Start.. "_خوش آمدگویی گروه در سیستم ربات فعال شد✅_"
							--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
						end
					end
					if CmdEn[2] == "disable" or CmdFa[2] == "خاموش" then
						welcome = redis:get(Alpha..'welcome:'..msg.chat_id)
						if welcome == 'Enable' then
							redis:del(Alpha..'welcome:'..msg.chat_id)
							text = Source_Start.. "_خوش آمدگویی گروه در سیستم ربات غیرفعال شد️_❌"
							---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
						else
							text = Source_Start.. "_خوش آمدگویی گروه در سیستم ربات غیرفعال بود_❗️"
							---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
						end
					end
					
					elseif CmdMatches and (CmdMatches:match('^inlineset (.*)') or CmdMatches:match('^پنل حالت (.*)')) and is_JoinChannel(msg) then
					local CmdEn = {
					string.match(CmdMatches, "^(inlineset) (.*)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(پنل حالت) (.*)$")
					}
					if CmdEn[2] == "enable" or CmdFa[2] == "فعال"  then
						inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
						if inline == 'Enable' then
							text = Source_Start.. "_پنل حالت قفل ها از قبل فعال بود❗️_"
							---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
						else
							redis:set(Alpha..'inlineset:'..msg.chat_id, 'Enable')
							text = Source_Start.. "_پنل حالت قفل ها فعال شد.✅_"
							---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
						end
					end
					if CmdEn[2] == "disable" or CmdFa[2] == "غیرفعال" then
						inline = redis:get(Alpha..'inlineset:'..msg.chat_id)
						if inline == 'Enable' then
							redis:del(Alpha..'inlineset:'..msg.chat_id)
							text = Source_Start.. "_پنل حالت قفل ها غیرفعال شد_❌"
							--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
						else
							text = Source_Start.. "_پنل حالت قفل ها غیرفعال بود.❗️_"
							--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
						end
					end
					
					---------------------------------------
					
					-------------------------------------
					elseif CmdMatches == 'resetsettings' or CmdMatches == "ریست تنظیمات" then
				return resetsettings(msg)
				elseif CmdMatches == 'lock tabligh' or CmdMatches == "قفل تبلیغات" then
				return LockTablighat(msg)
				elseif CmdMatches == 'unlock tabligh' or CmdMatches == "بازکردن تبلیغات" then
				return UnLockTablighat(msg)
				elseif CmdMatches == 'lock media' or CmdMatches == "قفل رسانه" then
				return LockMedia(msg)
				elseif CmdMatches == 'unlock media' or CmdMatches == "بازکردن رسانه" then
				return UnLockMediaa(msg)
				elseif (CmdMatches == "pin" or CmdMatches == "سنجاق") and msg.reply_id and is_JoinChannel(msg) then
					local lock_pin = redis:get(Alpha..'lock_pin:'..msg.chat_id)
					if lock_pin == 'Enable' then
						if is_owner(msg) then
							tdbot.pinChannelMessage(msg.to.id, msg.reply_id, 1, dl_cb, nil)
							text = Source_Start.. "_پیام ارسال شده با موفقیت سنجاق شد_❗️"
							--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md') 
						elseif not is_owner(msg) then
							return
						end
					elseif not lock_pin then
						redis:set(Alpha..'pin_msg'..msg.chat_id, msg.reply_id)
						tdbot.pinChannelMessage(msg.to.id, msg.reply_id, 1, dl_cb, nil)
						text = Source_Start.. "پیام ارسال شده با موفقیت سنجاق شد_❗️"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
				elseif (CmdMatches == 'unpin' or CmdMatches == "حذف سنجاق") and is_JoinChannel(msg) then
					local lock_pin = redis:get(Alpha..'lock_pin:'..msg.chat_id)
					if lock_pin == 'Enable' then
						if is_owner(msg) then
							tdbot.unpinChannelMessage(msg.to.id, dl_cb, nil)
							text = Source_Start.. "_پیام ارسال شده با موفقیت حذف سنجاق شد️️_"
							---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
						elseif not is_owner(msg) then
							return
						end
					elseif not lock_pin then
						tdbot.unpinChannelMessage(msg.to.id, dl_cb, nil)
						text = Source_Start.." _پیام ارسال شده با موفقیت حذف سنجاق شد️️_"
					---	tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
-----------------------------------

					
				elseif CmdMatches and (CmdMatches:match('^mute (%d+) (%d+) (%d+)')) and is_JoinChannel(msg) then
					local matches = {
					string.match(CmdMatches, "^(mute) (%d+) (%d+) (%d+)$")
					}
						
				local hour = string.gsub(matches[1], "h", "")
                local num1 = tonumber(hour) * 3600
                local minutes = string.gsub(matches[2], "m", "")
                local num2 = tonumber(minutes) * 60
                local second = string.gsub(matches[3], "s", "")
                local num3 = tonumber(second)
                local num4 = tonumber(num1 + num2 + num3)
				local hash = 'mute_all:'..msg.chat_id
				redis:setex(Alpha.. hash, num4, true)
				---tdbot.sendMessage(msg.chat_id, msg.id, 1, "_قفل گروه زمانی با موفقیت تنظیم شد._\n *"..matches[1].."* ساعت *"..matches[2].."* دقیقه *"..matches[3].."*ثانیه\n توسط \n"..msg.from.id.."` - @"..check_markdown(msg.from.username or '').."", 1, 'md')

				
				elseif CmdMatches and (CmdMatches:match('^lockgp (%d+)[mhs]') or CmdMatches:match('^قفل گروه (%d+)[mhs]')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^lockgp (.*)') or CmdMatches:match('^قفل گروه (.*)')
					if Matches:match('(%d+)h') then
						time_match = Matches:match('(%d+)h')
						time = time_match * 3600
					end
					if Matches:match('(%d+)s') then
						time_match = Matches:match('(%d+)s')
						time = time_match
					end
					if Matches:match('(%d+)m') then
						time_match = Matches:match('(%d+)m')
						time = time_match * 60
					end
					local timelock = tonumber(time)
					redis:setex(Alpha..'mute_all:'..msg.to.id, timelock, true)
					---tdbot.sendMessage(msg.chat_id, msg.id, 1, "_قفل گروه زمانی با موفقیت تنظیم شد._\n *"..time.."*ثانیه\n توسط\n"..msg.from.id.."` - @"..check_markdown(msg.from.username or '').."", 1, 'md')
				
				
				elseif CmdMatches == 'آمار زمانی' and is_JoinChannel(msg) then
		  local time = redis:ttl(Alpha.. 'mute_all:'..msg.chat_id)
local days = math.floor(time / 86400)
time = time - days * 86400
local hour = math.floor(time /3600)
time = time - hour * 3600
local minute = math.floor(time / 60)
time = time - minute * 60
sec = time
          if tonumber(time) < 0 then
          --tdbot.sendMessage(msg.chat_id, msg.id, 1,'مدیر عزیز \nگروه فوق \nبه صورت کامل باز میباشد! ', 1,'md')
            else
			alpha = 'آمار تعطیلی گروه:\n[`'..hour..'`]ساعت:[`'..minute..'`]دقیقه:[`'..sec..'`]ثانیه\n می باشد!'
         --- tdbot.sendMessage(msg.chat_id, msg.id, 1,alpha , 1,'md')
          end
				elseif (CmdMatches == 'newlink' or CmdMatches == "لینک جدید") and is_JoinChannel(msg) then
					local function callback_link (arg, data)
						if not data.invite_link then
							---return tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start.." ⚠️_خطای پردازشی_\n_ربات آلفا در گروه ادمین نمی باشد لطفا مدیر گروه عزیز ربات رو ادمین کنید_❗️", 1, 'md')
						else
							redis:set(Alpha..msg.to.id..'linkgpset', data.invite_link)
							---return tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start.." _لینک قبلی گروه با موفقیت باطل شد ولینک جدید ساخته شد._", 1, 'md')
						end
					end
					tdbot.exportChatInviteLink(msg.to.id, callback_link, nil)
				elseif (CmdMatches == 'link' or CmdMatches == "لینک") and is_JoinChannel(msg) then
					local linkgp = redis:get(Alpha..msg.to.id..'linkgpset')
					if not linkgp then
						text = Source_Start.. "⚠️_خطای پردازشی_\n_ربات آلفا در گروه ادمین نمی باشد لطفا مدیر گروه عزیز ربات رو ادمین کنید_❗️"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
					text = Source_Start.."<b>لینک گروه :</b>\n"..linkgp
					return tdbot.sendMessage(msg.chat_id, msg.id, 1, text, 1, 'html')--]]
				elseif (CmdMatches == 'linkpv' or CmdMatches == "لینک خصوصی") and is_JoinChannel(msg) then
					if redis:get(Alpha..msg.from.id..'chkusermonshi') and not is_admin(msg) then
						---tdbot.sendMessage(msg.chat_id, msg.id, 1, "_کاربر عزیز به پیوی ربات آلفا مراجعه کرده وپیام ارسال کنید\nبعد ازارسال  به دستور لینک خصوصی را ارسال کنید_❗️", 1, 'md')
					else
						local linkgp = redis:get(Alpha..msg.to.id..'linkgpset')
						if not linkgp then
							text = Source_Start.."⚠️_خطای پردازشی_\n_ربات آلفا در گروه ادمین نمی باشد لطفا مدیر گروه عزیز ربات رو ادمین کنید_❗️"
							---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
						end
						tdbot.sendMessage(msg.sender_user_id, "", 1, "<b>لینک گروه </b> : <code>"..msg.to.title.."</code> :\n"..linkgp, 1, 'html')
						text = Source_Start.." _لینک جدید به پیوی شما ارسال شد_"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
				elseif CmdMatches and (CmdMatches:match('^setchar (%d+)') or CmdMatches:match('^حداکثر حروف مجاز (%d+)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^setchar (%d+)') or CmdMatches:match('^حداکثر حروف مجاز (%d+)')
					redis:set(Alpha..msg.to.id..'set_char', Matches)
					text = Source_Start.."_حداکثر حروف مجاز در پیام تنظیم شد به_ : *[ "..Matches.." ]*کاراکتر"
					--tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif CmdMatches and (CmdMatches:match('^setflood (%d+)') or CmdMatches:match('^تنظیم پیام رگباری (%d+)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^setflood (%d+)') or CmdMatches:match('^تنظیم پیام رگباری (%d+)')
					if tonumber(Matches) < 1 or tonumber(Matches) > 50 then
						text = Source_Start.." ⚠️_خطای پردازشی_\n_باید بین` *[2-50]* `تنظیم شود_❗️"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
					local flood_max = Matches
					redis:set(Alpha..msg.to.id..'num_msg_max', flood_max)
					text = Source_Start..'_تنظیم عددی پیام رگباری انجام شد به:_ *'..tonumber(Matches)..''
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif CmdMatches and (CmdMatches:match('^setfloodtime (%d+)') or CmdMatches:match('^تنظیم زمان رگباری (%d+)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^setfloodtime (%d+)') or CmdMatches:match('^تنظیم زمان رگباری (%d+)')
					if tonumber(Matches) < 2 or tonumber(Matches) > 10 then
						text = Source_Start.."️ ⚠️_خطای پردازشی_\n_باید بین *[2-10]* `تنظیم شود_"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
					local time_max = Matches
					redis:set(Alpha..msg.to.id..'time_check', time_max)
					text = Source_Start.." ⚠️_خطای پردازشی_\n_حداکثر زمان پیام رگباری تنظیم شد به_:*[ "..Matches.." ]*"
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif CmdMatches == "about" or CmdMatches == "درباره" then
					if not redis:get(Alpha..msg.to.id..'about') then
						text =  Source_Start.."⚠️_خطای پردازشی_\n _هیچ متنی برای بیوگرافی گروه ثبت نشده است_"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					else
						text = Source_Start.. "_درباره گروه_ :\n"..redis:get(Alpha..msg.to.id..'about')
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
				elseif CmdMatches and (CmdMatches:match('^setwarn (%d+)') or CmdMatches:match('^حداکثر اخطار (%d+)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^setwarn (%d+)') or CmdMatches:match('^حداکثر اخطار (%d+)')
					if tonumber(Matches) < 1 or tonumber(Matches) > 20 then
						text = Source_Start.."⚠️_خطای پردازشی_\n_لطفا عددی بین [1-20] را انتخاب کنید_"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
					local warn_max = Matches
					redis:set(Alpha..'max_warn:'..msg.to.id, warn_max)
					text = Source_Start.."_ماکسیمم اخطار برای کاربران تنظیم شد به_: *[ "..Matches.." ]*"
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					
			

				elseif CmdMatches and (CmdMatches:match('^rmsg (%d+)') or CmdMatches:match('^پاکسازی (%d+)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^rmsg (%d+)') or CmdMatches:match('^پاکسازی (%d+)')
					if tonumber(Matches) > 1000 then
						---tdbot.sendMessage(msg.chat_id,  msg.id, 0, Source_Start.."️ ⚠️_خطای پردازشی_\n_عددی بین [`1-1000`] را انتخاب کنید_", 0, "md")
					else
						local function cb(arg,data)
							for k,v in pairs(data.messages) do
								del_msg(msg.chat_id, v.id)
							end
						end
						tdbot.getChatHistory(msg.to.id, msg.id, 0,  Matches, 0, cb, nil)
						---tdbot.sendMessage(msg.chat_id,  msg.id, 0, Source_Start.. "_تعداد_\n *("..Matches..")* _پیام پاکسازی شد_", 0, "md")
					end

					
				elseif (CmdMatches == "Menu" or CmdMatches == "مدیریت") and is_JoinChannel(msg) then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							text = Source_Start.. "⚠️_خطای پردازشی_\n_ربات کمکی ربات خاموش می باشد❗️_"
							return tdbot.sendMessage(msg.to.id, msg.id, 0, text, 0, "md")
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Menu:"..msg.to.id, 0, inline_query_cb, nil)
				elseif (CmdMatches == "help" or CmdMatches == "راهنما") and is_JoinChannel(msg) then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							text = Source_Start.. "⚠️_خطای پردازشی_\n_ربات کمکی ربات خاموش می باشد❗️_"
							return tdbot.sendMessage(msg.to.id, msg.id, 0, text, 0, "md")
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Help:"..msg.to.id, 0, inline_query_cb, nil)
					
					elseif (CmdMatches == "lock join" or CmdMatches == "قفل اد اجباری") and is_JoinChannel(msg) then
					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							text = Source_Start.. "⚠️_خطای پردازشی_\n_ربات کمکی ربات خاموش می باشد❗️_"
							return tdbot.sendMessage(msg.to.id, msg.id, 0, text, 0, "md")
						end
					end
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Ljoi:"..msg.to.id, 0, inline_query_cb, nil)
				
					
				elseif (CmdMatches == "panelpv" or CmdMatches == "پنل خصوصی") and is_JoinChannel(msg) then
					if not redis:get(Alpha..msg.from.id..'chkusermonshi') and not is_admin(msg) then
						tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.." _پنل ربات به پیوی شما ارسال شد_\n_درصورت مشاهده نشدن پنل در پیوی ربات دوباره در گروه پنل را ارسال یا در خود پیوی ربات دستور پنل را ارسال کنید._❗️", 1, 'md')
					else
						local function inline_query_cb(arg, data)
							if data.results and data.results[0] then
								redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.from.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
							else
								text = Source_Start.. "⚠️_خطای پردازشی_\n_ربات کمکی ربات خاموش می باشد❗️_"
								return tdbot.sendMessage(msg.to.id, msg.id, 0, text, 0, "md")
							end
						end
						redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
						redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
						tdbot.getInlineQueryResults(Bot_idapi, msg.from.id, 0, 0, "Menu:"..msg.to.id, 0, inline_query_cb, nil)
						tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.." _پنل ربات به پیوی شما ارسال شد_\n_درصورت مشاهده نشدن پنل در پیوی ربات دوباره در گروه پنل را ارسال یا در خود پیوی ربات دستور پنل را ارسال کنید._❗️", 1, 'md')
					end
				elseif CmdMatches and (CmdMatches:match('^delbot (.*)') or CmdMatches:match('^پاکسازی خودکار (.*)')) and is_JoinChannel(msg) then
					local CmdEn = {
					string.match(CmdMatches, "^(delbot) (.*)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(پاکسازی خودکار) (.*)$")
					}
					if CmdEn[2] == "on" or CmdFa[2] == "فعال" then
						redis:set(Alpha.."delbot"..msg.to.id, true)
						redis:set(Alpha.."deltimebot"..msg.chat_id , 60)
						text = Source_Start.. "_پاکسازی خودکار پیام ربات فعال شد_✅\n_توسط_\n"..msg.from.id.."` - @"..check_markdown(msg.from.username or '')..""
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					elseif CmdEn[2] == "off" or CmdFa[2] == "غیرفعال" then
						redis:del(Alpha.."delbot"..msg.to.id)
						redis:del(Alpha.."deltimebot"..msg.chat_id)
						text = Source_Start.. "_پاکسازی خودکار پیام ربات غیر فعال شد_✅\n_توسط_\n"..msg.from.id.."` - @"..check_markdown(msg.from.username or '')..""
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
				elseif CmdMatches and (CmdMatches:match('^deltimebot (%d+)') or CmdMatches:match('^عدد پاکسازی (%d+)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^deltimebot (%d+)') or CmdMatches:match('^عدد پاکسازی (%d+)')
					if tonumber(Matches) < 10 or tonumber(Matches) > 300 then
						text = Source_Start.." ⚠️_خطای پردازشی_\nباید بین*[10 - 300]* تنظیم شود"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					else
						redis:set(Alpha.."deltimebot"..msg.chat_id , Matches)
						text = Source_Start.."_زمان پاکسازی پیام های ربات تنظیم شده به_: *[ "..Matches.." ]* ثانیه"
						---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
					end
				elseif CmdMatches and (CmdMatches:match('^(lock auto) (%d+):(%d+)-(%d+):(%d+)$') or CmdMatches:match('^(قفل خودکار) (%d+):(%d+)-(%d+):(%d+)$')) and is_JoinChannel(msg) then
					local CmdEn = {
					string.match(CmdMatches, "^(lock auto) (%d+):(%d+)-(%d+):(%d+)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(قفل خودکار) (%d+):(%d+)-(%d+):(%d+)$")
					}
					local Matches2 = CmdEn[2] or CmdFa[2]
					local Matches3 = CmdEn[3] or CmdFa[3]
					local Matches4 = CmdEn[4] or CmdFa[4]
					local Matches5 = CmdEn[5] or CmdFa[5]
					local End = Matches4..":"..Matches5
					local Start = Matches2..":"..Matches3
					if End == Start then
						---tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start.. '⚠️_خطای پردازشی_\n'..Source_Start..' _زمان اولیه شما با زمان ثانویه یکی می باشد از تکرار آن اجتناب کنید_❗️', 1, 'md')
					else
						--tdbot.sendMessage(msg.to.id, msg.id, 1, Source_Start..'_قفل خودکار زمانی گروه با موفقیت فعال شد._✅\n\n'..Source_Start..' _گروه شما در ساعت_ *'..Start..'* _الی_ *'..End..'* به صورت خودکار قفل خواهد شد.', 1, 'md')
						redis:set(Alpha.."atolct1"..msg.to.id,Start)
						redis:set(Alpha.."atolct2"..msg.to.id,End)
					end
					---------------------
					
					----------------------
				elseif CmdMatches and (CmdMatches:match('^mute (%d+) (.*)') or CmdMatches:match('^سکوت (%d+) (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^mute (%d+)') or CmdMatches:match('^سکوت (%d+)')
					local CmdEn = {
					string.match(CmdMatches, "^(mute) (%d+) (.*)$")
					}
					local CmdFa = {
					string.match(CmdMatches, "^(سکوت) (%d+) (.*)$")
					}
					local time = Matches
					if CmdEn[3] == "d" or CmdFa[3] == "روز" then
						local hour = tonumber(time) * 86400
						local timemute = tonumber(hour)
						local function Restricted(arg, data)
							if data.sender_user_id == our_id then
							--return tdbot.sendMessage(msg.chat_id, "", 0, Source_Start.. "_خطای دستوری_⚠️\n_من یک ربات هستم ودستور مدیران ربات را اجرا میکنم نه اینکه خودم رو محدود کنم_❗️", 0, "md")
							end
							if is_mod1(msg.chat_id, data.sender_user_id) then
						---return tdbot.sendMessage(msg.chat_id, "", 0, Source_Start.. "_️خطای دستوری_⚠️\n_کاربر معاون ربات یا مالک گروه می باشد نمیتوانم اخراج کنم توبه کن عزیزم_❗️", 0, "md")
							end
							tdbot.Restricted(msg.chat_id,data.sender_user_id,'Restricted',   {1,msg.date+timemute, 0, 0, 0,0})
							tdbot.sendMention(msg.chat_id,data.sender_user_id, data.id,Source_Start.. "کاربر \n[ "..data.sender_user_id.." ]\n  به مدت "..time.." ساعت سکوت شد",10,string.len(data.sender_user_id))
						end
						tdbot.getMessage(msg.chat_id, tonumber(msg.reply_to_message_id), Restricted, nil)
					elseif CmdEn[3] == "h" or CmdFa[3] == "ساعت" then
						local hour = tonumber(time) * 3600
						local timemute = tonumber(hour)
						local function Restricted(arg, data)
							if data.sender_user_id == our_id then
							---return tdbot.sendMessage(msg.chat_id, "", 0, Source_Start.. "_خطای دستوری_⚠️\n_من یک ربات هستم ودستور مدیران ربات را اجرا میکنم نه اینکه خودم رو محدود کنم_❗️", 0, "md")
							end
							if is_mod1(msg.chat_id, data.sender_user_id) then
						---return tdbot.sendMessage(msg.chat_id, "", 0, Source_Start.. "_️خطای دستوری_⚠️\n_کاربر معاون ربات یا مالک گروه می باشد نمیتوانم اخراج کنم توبه کن عزیزم_❗️", 0, "md")
							end
							tdbot.Restricted(msg.chat_id,data.sender_user_id,'Restricted',   {1,msg.date+timemute, 0, 0, 0,0})
							---tdbot.sendMention(msg.chat_id,data.sender_user_id, data.id,Source_Start.."کاربر \n[ "..data.sender_user_id.." ]\n  به مدت "..time.." ساعت سکوت شد",10,string.len(data.sender_user_id))
						end
						tdbot.getMessage(msg.chat_id, tonumber(msg.reply_to_message_id), Restricted, nil)
					elseif CmdEn[3] == "m" or CmdFa[3] == "دقیقه" then
						local minutes = tonumber(time) * 60
						local timemute = tonumber(minutes)
						local function Restricted(arg,data)
							if data.sender_user_id == our_id then
							---return tdbot.sendMessage(msg.chat_id, "", 0, Source_Start.. "_خطای دستوری_⚠️\n_من یک ربات هستم ودستور مدیران ربات را اجرا میکنم نه اینکه خودم رو محدود کنم_❗️", 0, "md")
							end
							if is_mod1(msg.chat_id, data.sender_user_id) then
						----return tdbot.sendMessage(msg.chat_id, "", 0, Source_Start.. "_️خطای دستوری_⚠️\n_کاربر معاون ربات یا مالک گروه می باشد نمیتوانم اخراج کنم توبه کن عزیزم_❗️", 0, "md")
							end
							tdbot.Restricted(msg.chat_id,data.sender_user_id,'Restricted',   {1,msg.date+timemute, 0, 0, 0,0})
							tdbot.sendMention(msg.chat_id,data.sender_user_id, data.id,Source_Start.."کاربر \n[ "..data.sender_user_id.." ] \n به مدت "..time.." دقیقه سکوت شد",10,string.len(data.sender_user_id))
						end
						tdbot.getMessage(msg.chat_id, tonumber(msg.reply_to_message_id), Restricted, nil)
					end
				elseif (CmdMatches == 'filterlist' or CmdMatches == "لیست فیلتر") and is_JoinChannel(msg) then
					return filter_list(msg)
				elseif (CmdMatches == "تنظیمات" or CmdMatches == "پنل تنظیمات") and is_JoinChannel(msg) then
					return group_settings(msg)
				elseif (CmdMatches == 'modlist' or CmdMatches == "لیست ترفیع") and is_JoinChannel(msg) then
					return modlist(msg)
				elseif (CmdMatches == "viplist" or CmdMatches == "لیست مجاز") and is_JoinChannel(msg) then
					return whitelist(msg)
				elseif CmdMatches and (CmdMatches:match('^filter (.*)') or CmdMatches:match('^فیلتر (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^filter (.*)') or CmdMatches:match('^فیلتر (.*)')
					return filter_word(msg, Matches)
				elseif CmdMatches and (CmdMatches:match('^unfilter (.*)') or CmdMatches:match('^حذف فیلتر (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^unfilter (.*)') or CmdMatches:match('^حذف فیلتر (.*)')
					return unfilter_word(msg, Matches)
				end
				
				if CmdMatches and CmdMatches:lower() == 'panel' or CmdMatches and CmdMatches:lower() == 'add' or CmdMatches and CmdMatches:lower() == 'help' or CmdMatches and CmdMatches:lower() == 'پنل'  then
	  local apisec = tonumber(797955997)
	    addChatMembers(msg.chat_id,{[0] = 797955997}) 
		end
				-------------------------------------
				function is_OwnChannel(msg)
	local linkch = redis:get(Alpha.."linkchset"..msg.chat_id)
		local url  = https.request('https://api.telegram.org/bot'..bot_token..'/getchatmember?chat_id=@Gapestaniran &user_id='..msg.sender_user_id)
		if res ~= 200 then end
		local joinenabel = redis:get(Alpha.."JoinEnabelCh"..msg.chat_id)
		JoinEnabelCh = json:decode(url)
		
		if (not JoinEnabelCh.ok or JoinEnabelCh.result.status == "left" or JoinEnabelCh.result.status == "kicked") and not JoinEnabelCh  then
			tdbot.deleteMessages(msg.chat_id, {[0] = msg.id})
			if redis:get(Alpha.."BoTMode") == "CliMode" then
				local function inline_query_cb(arg, data)
					if data.results and data.results[0] then
						tdbot.sendInlineQueryResultMessage(msg.chat_id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
					end
				end
				tdbot.getInlineQueryResults(Bot_idapi, msg.chat_id, 0, 0, "JoinCh", 0, inline_query_cb, nil)
			else
				tdbot.sendMessage(msg.chat_id, msg.id, 1, '_کاربر عزیز_\n@'..check_markdown(msg.from.username or '')..'\n_محدودیت اجباری کانال فعال می باشد.\n_کاربر عزیز برای استفاده ازدستورات ربات باید به کانال ما عضو بشوید️_', 1, 'md')
			end
		else
			return true
		end
	end
	if msg.content._ == "messageText" and is_OwnChannel(msg) then
	msg.text = msg.content.text
						msg.edited = false
						msg.pinned = false
	end
		
		if CmdMatches and (CmdMatches:match('^joinchannel (.*)') or CmdMatches:match('^عضویت کانال (.*)')) then
				local CmdEn = {
				string.match(CmdMatches, "^(joinchannel) (.*)$")
				}
				local CmdFa = {
				string.match(CmdMatches, "^(عضویت کانال) (.*)$")
				}
				if CmdEn[2] == "on" or CmdFa[2] == "فعال" then
					redis:del(Alpha.."JoinEnabelCh"..msg.chat_id)
					text = Source_Start.." _عضویت کانال برای این گروه فعال شد._"
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				elseif CmdEn[2] == "off" or CmdFa[2] == "غیرفعال" then
					redis:set(Alpha.."JoinEnabelCh"..msg.chat_id, true)
					text = Source_Start.. "_عضویت کانال برای این گروه غیر فعال شد._"
					---tdbot.sendMessage(msg.chat_id , msg.id, 1, text, 0, 'md')
				end		
				end
			end
		
				-------------------------------------------
if redis:get(Alpha.."lock_cmd"..msg.chat_id) and not is_mod(msg) then return false end
if (CmdMatches == "id"  or CmdMatches == "ایدی" or CmdMatches == "آیدی") and tonumber(msg.reply_to_message_id) == 0 then
if redis:get(Alpha.."lock_cmd"..msg.chat_id) and not is_mod(msg) then return else
local function getpro(arg, data)
if data.username then
username = "@"..check_markdown(data.username)
username = ""
end
local user_info_msgs = tonumber(redis:get(Alpha..'msgs:'..msg.sender_user_id..':'..msg.chat_id) or 0)-- پیام کاربر
local gap_info_msgs = tonumber(redis:get(Alpha..'msgs:'..msg.chat_id) or 0) -- پیام گروه
 Percent_ = tonumber(user_info_msgs) / tonumber(gap_info_msgs) * 100
 if Percent_ < 10 then
  Percent = "0" .. string.sub(Percent_, 1, 4)
 elseif Percent_ >= 10 then
        Percent = string.sub(Percent_, 1, 5)
      end
 if 10 >= tonumber(Percent) then
		if not lang then
          UsStatus = "ضعیف😴"
		  
       end
	   elseif tonumber(Percent) <= 20 then
        if not lang then
          UsStatus = "متوسط😬"
		   
end
elseif 100 >= tonumber(Percent) then
        if not lang then
          UsStatus = "فعال😜"
		  
end  
end
if not data.photos[0] then
--tdbot.sendMessage(msg.chat_id, msg.id, 1, '\n》 _نام کاربری_ : @'..msg.from.username or msg.from.first_name..'\n》 _آیدی عددی_↜❪ '..msg.sender_user_id..' ❫\n》 _فعالیت_↜❪ '.. UsStatus..'['..Percent..'%] ❫\n》 _تعداد پیام شما_↜❪ '..user_info_msgs..'_عددپیام_ ❫\n》 _تعداد پیام گروه_↜❪'..gap_info_msgs..'_عددپیام_ ❫', 1, 'md')
else
--tdbot.sendPhoto(msg.chat_id, msg.id, data.photos[0].sizes[1].photo.persistent_id, 0, {}, 0, 0,'》 آیدی گروه ↜'..msg.chat_id..'\n》 آیدی عددی↜❪ '..msg.sender_user_id..' ❫\n》 فعالیت شما↜❪ '.. UsStatus..'['..Percent..'%] ❫\n》 تعداد پیام شما↜❪ '..user_info_msgs..'عددپیام ❫\n》 تعداد پیام گروه↜❪'..gap_info_msgs..'عددپیام ❫\n ', 0, 0, 1, nil, dl_cb, nil)
end
end
assert(tdbot_function ({ 
					_ = "getUserProfilePhotos",
					user_id = msg.sender_user_id,
					offset = 0,
					limit = 1
					}, getpro, nil))
				end
			elseif (CmdMatches == "id" or CmdMatches == "ایدی" or CmdMatches == "آیدی") and tonumber(msg.reply_to_message_id) ~= 0 and is_mod(msg) then
				if redis:get(Alpha.."lock_cmd"..msg.chat_id) and not is_mod(msg) then return else
					assert(tdbot_function ({
					_ = "getMessage",
					chat_id = msg.chat_id,
					message_id = msg.reply_to_message_id 
					}, action_by_reply1, {chat_id=msg.chat_id,cmd="id"}))
				end
				elseif CmdMatches and (CmdMatches:match('^like (.*)') or CmdMatches:match('^نظرسنجی (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^like (.*)') or CmdMatches:match('^نظرسنجی (.*)')
					local function MaTaDoR(arg, data)
						tdbot.sendInlineQueryResultMessage(msg.chat_id, msg.id, 0, 1, data.inline_query_id, data.results[0].id)
					end
					tdbot.getInlineQueryResults(190601014, msg.chat_id, 0, 0, Matches, 0, MaTaDoR, nil)
				
				elseif CmdMatches and (CmdMatches:match('^ahang (.*)') or CmdMatches:match('^تیکه آهنگ (.*)')) and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^ahang (.*)') or CmdMatches:match('^تیکه آهنگ (.*)')
					local function MaTaDoR(arg, data)
						tdbot.sendInlineQueryResultMessage(msg.chat_id, msg.id, 0, 1, data.inline_query_id, data.results[0].id)
					end
					tdbot.getInlineQueryResults(117678843, msg.chat_id, 0, 0, Matches, 0, MaTaDoR, nil)
		
				elseif CmdMatches and CmdMatches:match('^پشتیبانی (.*)') and is_JoinChannel(msg) then
					local Matches = CmdMatches:match('^پشتیبانی (.*)')
					local linkgp = redis:get(Alpha..msg.to.id..'linkgpset')
					local url , res = http.request('https://enigma-dev.ir/api/time/')
		if res ~= 200 then
			return "No connection"
		end
		 local jdat = json:decode(url)
					local suppurt = 'سلام مدیر یک پیغام ازسمت یکی از گروه ها دارم این کاربر مشکل دارد فورا بررسی کنید!\nپیام کاربر :[`'..Matches..'`]\n\nلینک گروه :'..linkgp..' \n\n یوزرنیم درخواستی :'..check_markdown(msg.from.first_name or '')..'-@'..check_markdown(msg.from.username or '')..' \n\nنام گروه :`'..check_markdown(msg.to.title)..'`\nتاریخ درخواست:`'..jdat.FaDate.WordTwo..'`\nساعت درخواست:`'..jdat.EnTime.Number..'` '
					tdbot.sendMessage(gp_sudo , msg.id, 1,suppurt, 0, 'md')

					local function inline_query_cb(arg, data)
						if data.results and data.results[0] then
							redis:setex(Alpha.."ReqMenu:" .. msg.to.id .. ":" .. msg.from.id, 260, true) redis:setex(Alpha.."ReqMenu:" .. msg.to.id, 10, true) tdbot.sendInlineQueryResultMessage(msg.to.id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
						else
							text = Source_Start.. "⚠️_خطای پردازشی_\n_ربات کمکی ربات خاموش می باشد❗️_"
							return tdbot.sendMessage(msg.to.id, msg.id, 0, text, 0, "md")
						end
					end
					
					redis:set(Alpha.."TabchiUsername:"..msg.to.id, msg.from.first_name)
					redis:set(Alpha.."TabchiUserId:"..msg.to.id, msg.from.id)
					
										tdbot.getInlineQueryResults(Bot_idapi, msg.to.id, 0, 0, "Supp:"..msg.to.id, 0, inline_query_cb, nil)			
	
			
			
			
			end
		end
		function Delall(msg)
			local chat = msg.to.id
			local user = msg.from.id
			local is_channel = msg.to.type == "channel"
			if is_channel then
				del_msg(chat, tonumber(msg.id))
			elseif is_chat then
				kick_user(user, chat)
			end
		end
		function Warnall(msg,fa)
			local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
			local Source_Start = Emoji[math.random(#Emoji)]
			local chat = msg.to.id
			local user = msg.from.id
			local is_channel = msg.to.type == "channel"
			local hashwarn = chat..':warn'
			local warnhash = redis:hget(Alpha..hashwarn, user) or 1
			local max_warn = tonumber(redis:get(Alpha..'max_warn:'..chat) or 5)
			if is_channel then
				del_msg(chat, tonumber(msg.id))
				if tonumber(warnhash) == tonumber(max_warn) then
					tdbot.sendMessage(chat, "", 0, Source_Start.. "_کاربر_ \n@"..check_markdown(msg.from.username or '').."-*"..user.."\n"..Source_Start.."_به علت بی توجهی به اخطار های ربات از گروه مسدود شد_⛔️\n"..Source_Start.." _علت مسدود_:"..fa.."", 0, "md")
					kick_user(user, chat)
					redis:hdel(Alpha..hashwarn, user, '0')
				else
					redis:hset(Alpha..hashwarn, user, tonumber(warnhash) + 1)
					tdbot.sendMessage(chat, "", 0, Source_Start.."_کاربر_ \n@"..check_markdown(msg.from.username or '').."-*"..user.."\n"..Source_Start.." _به علت بی نظمی در گروه اخطار دریافت کرد_\n"..Source_Start.." _تعداد اخطار_: *"..warnhash.."*عدد\n"..Source_Start.." _ماکسیسم تنظیمی اخطار_:"..max_warn.."*عدد\n"..Source_Start.." _علت اخطار_:"..fa.."", 0, "md")
				end
			elseif is_chat then
				kick_user(user, chat)
			end
		end
		function Silentall(msg,fa)
			local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
			local Source_Start = Emoji[math.random(#Emoji)]
			local chat = msg.to.id
			local user = msg.from.id
			local is_channel = msg.to.type == "channel"
			timemutemsg = redis:get(Alpha.."TimeMuteset"..msg.to.id) or 3600
			local min = math.floor(timemutemsg / 60)
			if is_channel then
				del_msg(chat, tonumber(msg.id))
				tdbot.Restricted(msg.chat_id,msg.sender_user_id,'Restricted',   {1,msg.date+timemutemsg, 0, 0, 0,0})
			--	tdbot.sendMessage(chat, "", 0, Source_Start.."_کاربر_ \n@"..check_markdown(msg.from.username or '').."-`["..user.."]`\n"..Source_Start.." سکوت شد به مدت `"..min.."` دقیقه\n"..Source_Start.." _دلیل سکوت :_ `"..fa.."`", 0, "md")

			elseif is_chat then
				kick_user(user, chat)
			end
		end
		function Kickall(msg,fa)
			local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
			local Source_Start = Emoji[math.random(#Emoji)]
			local chat = msg.to.id
			local user = msg.from.id
			local is_channel = msg.to.type == "channel"
			if is_channel then
				del_msg(chat, tonumber(msg.id))
			--	tdbot.sendMessage(chat, "", 0, Source_Start.."_کاربر_\n@"..check_markdown(msg.from.username or '').." `["..user.."]`\nمسدود شد.\n_ دلیل مسدود :_ `"..fa.."`", 0, "md")
				redis:sadd(Alpha.."Banned:"..user,chat)
				kick_user(user, chat)
				sleep(1)
				channel_unblock(user, chat)
			elseif is_chat then
				kick_user(user, chat)
			end
		end
		function Tabchi(msg)
			local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
			local Source_Start = Emoji[math.random(#Emoji)]
			local chat = msg.to.id
			local user = msg.from.id
			local is_channel = msg.to.type == "channel"
			local hashwarn = chat..':warntabchi'
			local warnhash = redis:hget(Alpha..hashwarn, user) or 1
			local max_warn = tonumber(redis:get(Alpha..'max_warn_tabchi:'..chat) or 3)
			if is_channel then
				del_msg(chat, tonumber(msg.id))
				if tonumber(warnhash) == tonumber(max_warn) then
					tdbot.sendMessage(msg.chat_id, msg.id, 1, Source_Start.. "_کاربر_\n*"..user.."*-@"..check_markdown(msg.from.username or msg.from.first_name).."\n_به عنوان اکانت تبچی (تبلیغاتی)شناسایی واز گروه مسدود شد❗️_", 1, 'md')
					
					kick_user(user, chat)
					redis:hdel(Alpha..hashwarn, user, '0')
				else
					redis:hset(Alpha..hashwarn, user, tonumber(warnhash) + 1)
					if redis:get(Alpha.."BoTMode") == "CliMode" then
						if redis:get(Alpha.."TabchiUsername:"..chat) then
							redis:del(Alpha.."TabchiUsername:"..chat)
						end
						if redis:get(Alpha.."TabchiUserId:"..chat) then
							redis:del(Alpha.."TabchiUserId:"..chat)
						end
						local function inline_query_cb(arg, data)
							if data.results and data.results[0] then
								tdbot.sendInlineQueryResultMessage(msg.chat_id, msg.id, 0, 1, data.inline_query_id, data.results[0].id, dl_cb, nil)
							end
						end
						redis:set(Alpha.."TabchiUsername:"..chat, msg.from.username or msg.from.first_name)
						redis:set(Alpha.."TabchiUserId:"..chat, user)
						tdbot.getInlineQueryResults(Bot_idapi, msg.chat_id, 0, 0, "Tabchi:"..msg.chat_id, 0, inline_query_cb, nil)
					end
				end
			end
		end
		function Msg_checks(msg)
			local Emoji = {"⇚ ","⪼ ","✪ ","❃"}
			local Source_Start = Emoji[math.random(#Emoji)]
			local chat = msg.to.id
			local user = msg.from.id
			local is_channel = msg.to.type == "channel"
			local is_chat = msg.to.type == "chat"
			local auto_leave = 'auto_leave_bot'
			if not redis:get(Alpha..'autodeltime') then
				redis:setex(Alpha..'autodeltime', 14400, true)
				run_bash("rm -rf ~/.telegram-bot/cli/data/stickers/*")
				run_bash("rm -rf ~/.telegram-bot/cli/files/photos/*")
				run_bash("rm -rf ~/.telegram-bot/cli/files/animations/*")
				run_bash("rm -rf ~/.telegram-bot/cli/files/videos/*")
				run_bash("rm -rf ~/.telegram-bot/cli/files/music/*")
				run_bash("rm -rf ~/.telegram-bot/cli/files/voice/*")
				run_bash("rm -rf ~/.telegram-bot/cli/files/temp/*")
				run_bash("rm -rf ~/.telegram-bot/cli/data/temp/*")
				run_bash("rm -rf ~/.telegram-bot/cli/files/documents/*")
				run_bash("rm -rf ~/.telegram-bot/cli/data/profile_photos/*")
				run_bash("rm -rf ~/.telegram-bot/cli/files/video_notes/*")
				run_bash("rm -rf ./data/photos/files/*")
			end
			if is_channel or is_chat then
			if redis:get(Alpha.."CheckBot:"..msg.to.id) then
					if redis:get(Alpha..msg.to.id..'time_check') then
						TIME_CHECK = redis:get(Alpha..msg.to.id..'time_check') or 2
					end
				end
				lock_link = redis:get(Alpha..'lock_link:'..msg.chat_id)
				lock_join = redis:get(Alpha..'lock_join:'..msg.chat_id)
				lock_tag = redis:get(Alpha..'lock_tag:'..msg.chat_id)
				lock_username = redis:get(Alpha..'lock_username:'..msg.chat_id)
				lock_pin = redis:get(Alpha..'lock_pin:'..msg.chat_id)
				lock_arabic = redis:get(Alpha..'lock_arabic:'..msg.chat_id)
				lock_english = redis:get(Alpha..'lock_english:'..msg.chat_id)
				lock_mention = redis:get(Alpha..'lock_mention:'..msg.chat_id)
				lock_edit = redis:get(Alpha..'lock_edit:'..msg.chat_id)
				lock_spam = redis:get(Alpha..'lock_spam:'..msg.chat_id)
				lock_flood = redis:get(Alpha..'lock_flood:'..msg.chat_id)
				lock_markdown = redis:get(Alpha..'lock_markdown:'..msg.chat_id)
				lock_webpage = redis:get(Alpha..'lock_webpage:'..msg.chat_id)
				lock_welcome = redis:get(Alpha..'welcome:'..msg.chat_id)
				lock_views = redis:get(Alpha..'lock_views:'..msg.chat_id)
				lock_bots = redis:get(Alpha..'lock_bots:'..msg.chat_id)
				lock_tabchi = redis:get(Alpha..'lock_tabchi:'..msg.chat_id)
				mute_all = redis:get(Alpha..'mute_all:'..msg.chat_id)
				mute_gif = redis:get(Alpha..'mute_gif:'..msg.chat_id)
				mute_photo = redis:get(Alpha..'mute_photo:'..msg.chat_id)
				mute_sticker = redis:get(Alpha..'mute_sticker:'..msg.chat_id)
				mute_contact = redis:get(Alpha..'mute_contact:'..msg.chat_id)
				mute_inline = redis:get(Alpha..'mute_inline:'..msg.chat_id)
				mute_game = redis:get(Alpha..'mute_game:'..msg.chat_id)
				mute_text = redis:get(Alpha..'mute_text:'..msg.chat_id)
				mute_keyboard = redis:get(Alpha..'mute_keyboard:'..msg.chat_id)
				mute_forward = redis:get(Alpha..'mute_forward:'..msg.chat_id)
				mute_forwarduser = redis:get(Alpha..'mute_forwarduser:'..msg.chat_id)
				mute_location = redis:get(Alpha..'mute_location:'..msg.chat_id)
				mute_document = redis:get(Alpha..'mute_document:'..msg.chat_id)
				mute_voice = redis:get(Alpha..'mute_voice:'..msg.chat_id)
				mute_audio = redis:get(Alpha..'mute_audio:'..msg.chat_id)
				mute_video = redis:get(Alpha..'mute_video:'..msg.chat_id)
				mute_video_note = redis:get(Alpha..'mute_video_note:'..msg.chat_id)
				mute_tgservice = redis:get(Alpha..'mute_tgservice:'..msg.chat_id)
				if msg.adduser or msg.joinuser or msg.deluser then
					if mute_tgservice == 'Enable' then
						del_msg(chat, tonumber(msg.id))
					end
				end
				if not is_mod(msg) and not is_whitelist(msg.from.id, msg.to.id) and msg.from.id ~= our_id then
					if msg.adduser or msg.joinuser then
						if lock_join == 'Enable' then
							function join_kick(arg, data)
								kick_user(data.id, msg.to.id)
							end
							if msg.adduser then
								tdbot.getUser(msg.adduser, join_kick, nil)
							elseif msg.joinuser then
								tdbot.getUser(msg.joinuser, join_kick, nil)
							end
						end
					end
				end
				if msg.pinned and is_channel then
					if lock_pin == 'Enable' then
						if is_owner(msg) then
							return
						end
						if tonumber(msg.from.id) == our_id then
							return
						end
						local pin_msg = redis:get(Alpha..'pin_msg'..msg.chat_id)
						if pin_msg then
							tdbot.pinChannelMessage(msg.to.id, pin_msg, 1, dl_cb, nil)
						elseif not pin_msg then
							tdbot.unpinChannelMessage(msg.to.id, dl_cb, nil)
							redis:del(Alpha..'pin_msg'..msg.chat_id)
						end
						tdbot.sendMessage(msg.to.id, msg.id, 0, Source_Start.. '_کاربر_* `'..msg.from.id..'-@'..check_markdown(msg.from.username or '')..'\nشما اجازه دسترسی به سنجاق کردن پیام را ندارید\n\nپیام قبلی  شما سنجاق شد.', 0, "md")
					end
				end
				if not is_mod(msg) and not is_whitelist1(msg)  and msg.from.id ~= our_id then
					if redis:get(Alpha..'Lock_Gp:'..msg.to.id) then
						--Delall(msg)
					end
					
					if msg.edited then
						if lock_edit == 'Enable' then Delall(msg) elseif lock_edit == 'Warn' then Warnall(msg,"ویرایش") elseif lock_edit == 'Mute' then Silentall(msg,"ویرایش") elseif lock_edit == 'Kick' then Kickall(msg,"ویرایش") end
					end
					if msg.views ~= 0 then
						if lock_views == 'Enable' then Delall(msg) elseif lock_views == 'Warn' then Warnall(msg,"ویو") elseif lock_views == 'Mute' then Silentall(msg,"ویو") elseif lock_views == 'Kick' then Kickall(msg,"ویو") end
					end
					if msg.fwd_from_channel then
						if mute_forward == 'Enable' then Delall(msg) elseif mute_forward == 'Warn' then Warnall(msg,"فوروارد کانال") elseif mute_forward == 'Mute' then Silentall(msg,"فوروارد کانال") elseif mute_forward == 'Kick' then Kickall(msg,"فوروارد کانال") end
					end
					if msg.fwd_from_user then
						if mute_forward == 'Enable' then Delall(msg) elseif mute_forward == 'Warn' then Warnall(msg,"فوروارد کاربر") elseif mute_forward == 'Mute' then Silentall(msg,"فوروارد کاربر") elseif mute_forward == 'Kick' then Kickall(msg,"فوروارد کاربر") end
					end
					if msg.fwd_from_user or msg.fwd_from_channel then
						if lock_tabchi == 'Enable' then
							Tabchi(msg)
						end
					end
					if msg.photo then
						if mute_photo == 'Enable' then Delall(msg) elseif mute_photo == 'Warn' then Warnall(msg,"عکس") elseif mute_photo == 'Mute' then Silentall(msg,"عکس") elseif mute_photo == 'Kick' then Kickall(msg,"عکس") end
					end
					if msg.video then
						if mute_video == 'Enable' then Delall(msg) elseif mute_video == 'Warn' then Warnall(msg,"فیلم") elseif mute_video == 'Mute' then Silentall(msg,"فیلم") elseif mute_video == 'Kick' then Kickall(msg,"فیلم") end
					end
					if msg.video_note then
						if mute_video_note == 'Enable' then Delall(msg) elseif mute_video_note == 'Warn' then Warnall(msg,"فیلم سلفی") elseif mute_video_note == 'Mute' then Silentall(msg,"فیلم سلفی") elseif mute_video_note == 'Kick' then Kickall(msg,"فیلم سلفی") end
					end
					if msg.document then
						if mute_document == 'Enable' then Delall(msg) elseif mute_document == 'Warn' then Warnall(msg,"فایل") elseif mute_document == 'Mute' then Silentall(msg,"فایل") elseif mute_document == 'Kick' then Kickall(msg,"فایل") end
					end
					if msg.sticker then
						if mute_sticker == 'Enable' then Delall(msg) elseif mute_sticker == 'Warn' then Warnall(msg,"استیکر") elseif mute_sticker == 'Mute' then Silentall(msg,"استیکر") elseif mute_sticker == 'Kick' then Kickall(msg,"استیکر") end
					end
					if msg.animation then
						if mute_gif == 'Enable' then Delall(msg) elseif mute_gif == 'Warn' then Warnall(msg,"گیف") elseif mute_gif == 'Mute' then Silentall(msg,"گیف") elseif mute_gif == 'Kick' then Kickall(msg,"گیف") end
					end
					if msg.contact then
						if mute_contact == 'Enable' then Delall(msg) elseif mute_contact == 'Warn' then Warnall(msg,"مخاطب") elseif mute_contact == 'Mute' then Silentall(msg,"مخاطب") elseif mute_contact == 'Kick' then Kickall(msg,"مخاطب") end
					end
					if msg.location then
						if mute_location == 'Enable' then Delall(msg) elseif mute_location == 'Warn' then Warnall(msg,"موقعیت مکانی") elseif mute_location == 'Mute' then Silentall(msg,"موقعیت مکانی") elseif mute_location == 'Kick' then Kickall(msg,"موقعیت مکانی") end
					end
					if msg.voice then
						if mute_voice == 'Enable' then Delall(msg) elseif mute_voice == 'Warn' then Warnall(msg,"ویس") elseif mute_voice == 'Mute' then Silentall(msg,"ویس") elseif mute_voice == 'Kick' then Kickall(msg,"ویس") end
					end
					if msg.content then
						if msg.reply_markup and  msg.reply_markup._ == "replyMarkupInlineKeyboard" then
							if mute_keyboard == 'Enable' then Delall(msg) elseif  mute_keyboard == 'Warn' then Warnall(msg,"کیبورد شیشه ای") elseif  mute_keyboard == 'Mute' then Silentall(msg,"کیبورد شیشه ای") elseif  mute_keyboard == 'Kick' then Kickall(msg,"کیبورد شیشه ای") end
						end
					end
					if tonumber(msg.via_bot_user_id) ~= 0 then
						if mute_inline == 'Enable' then Delall(msg) elseif mute_inline == 'Warn' then Warnall(msg,"دکمه شیشه ای") elseif mute_inline == 'Mute' then Silentall(msg,"دکمه شیشه ای") elseif mute_inline == 'Kick' then Kickall(msg,"دکمه شیشه ای") end
					end
					if msg.game then
						if mute_game == 'Enable' then Delall(msg) elseif mute_game == 'Warn' then Warnall(msg,"بازی") elseif mute_game == 'Mute' then Silentall(msg,"بازی") elseif mute_game == 'Kick' then Kickall(msg,"بازی") end
					end
					if msg.audio then
						if mute_audio == 'Enable' then Delall(msg) elseif mute_audio == 'Warn' then Warnall(msg,"آهنگ") elseif mute_audio == 'Mute' then Silentall(msg,"آهنگ") elseif mute_audio == 'Kick' then Kickall(msg,"آهنگ") end
					end
					if msg.media.caption then
						local link_caption = msg.media.caption:match("[Tt][Ee][Ll][Ee][Gg][Rr][Aa][Mm].[Mm][Ee]/") or msg.media.caption:match("[Tt][Ee][Ll][Ee][Gg][Rr][Aa][Mm].[Dd][Oo][Gg]/") or msg.media.caption:match("[Tt].[Mm][Ee]/") or msg.media.caption:match("[Tt][Ll][Gg][Rr][Mm].[Mm][Ee]/")
						if link_caption and lock_link == 'Enable' then Delall(msg) elseif link_caption and lock_link == 'Warn' then Warnall(msg,"لینک") elseif link_caption and lock_link == 'Mute' then Silentall(msg,"لینک") elseif link_caption and lock_link == 'Kick' then Kickall(msg,"لینک") end
						local tag_caption = msg.media.caption:match("#")
						if tag_caption then
							if lock_tag == 'Enable' then Delall(msg) elseif lock_tag == 'Warn' then Warnall(msg,"تگ") elseif lock_tag == 'Mute' then Silentall(msg,"تگ") elseif lock_tag == 'Kick' then Kickall(msg,"تگ") end
						end
						local username_caption = msg.media.caption:match("@")
						if username_caption then
							if lock_username == 'Enable' then Delall(msg) elseif lock_username == 'Warn' then Warnall(msg,"تگ") elseif lock_username == 'Mute' then Silentall(msg,"تگ") elseif lock_username == 'Kick' then Kickall(msg,"تگ") end
						end
						if is_filter(msg, msg.media.caption) then
							Delall(msg)
						end
						local arabic_caption = msg.media.caption:match("[\216-\219][\128-\191]")
						if arabic_caption then
							if lock_arabic == 'Enable' then Delall(msg) elseif lock_arabic == 'Warn' then Warnall(msg,"فارسی") elseif lock_arabic == 'Mute' then Silentall(msg,"فارسی") elseif lock_arabic == 'Kick' then Kickall(msg,"فارسی") end
						end
						local english_caption = msg.media.caption:match("[A-Z]") or msg.media.caption:match("[a-z]")
						if english_caption then
							if lock_english == 'Enable' then Delall(msg) elseif lock_english == 'Warn' then Warnall(msg,"انگلیسی") elseif lock_english == 'Mute' then Silentall(msg,"انگلیسی") elseif lock_english == 'Kick' then Kickall(msg,"انگلیسی") end
						end
					end
					if msg.text and redis:get(Alpha.."CheckBot:"..msg.to.id) then
						local _nl, ctrl_chars = string.gsub(text, "%c", "")
						local _nl, real_digits = string.gsub(text, "%d", "")
						if not redis:get(Alpha..msg.to.id..'set_char') then
							sens = 400
						else
							sens = tonumber(redis:get(Alpha..msg.to.id..'set_char'))
						end
						if lock_spam == 'Enable' then
							if  string.len(msg.text) > sens or ctrl_chars > sens or real_digits > sens then
								Delall(msg)
							end
						end
						local link_msg = msg.text:match("[Tt][Ee][Ll][Ee][Gg][Rr][Aa][Mm].[Mm][Ee]/") or msg.text:match("[Tt][Ee][Ll][Ee][Gg][Rr][Aa][Mm].[Dd][Oo][Gg]/") or msg.text:match("[Tt].[Mm][Ee]/") or msg.text:match("[Tt][Ll][Gg][Rr][Mm].[Mm][Ee]/")
						if link_msg then
							if lock_link == 'Enable' then Delall(msg) elseif lock_link == 'Warn' then Warnall(msg,"لینک") elseif lock_link == 'Mute' then Silentall(msg,"لینک") elseif lock_link == 'Kick' then Kickall(msg,"لینک") end
						end
						local tag_msg = msg.text:match("#")
						if tag_msg then
							if lock_tag == 'Enable' then Delall(msg) elseif lock_tag == 'Warn' then Warnall(msg,"تگ") elseif lock_tag == 'Mute' then Silentall(msg,"تگ") elseif lock_tag == 'Kick' then Kickall(msg,"تگ") end
						end
						local username_msg = msg.text:match("@")
						if username_msg then
							if lock_username == 'Enable' then Delall(msg) elseif lock_username == 'Warn' then Warnall(msg,"نام کاربری") elseif lock_username == 'Mute' then Silentall(msg,"نام کاربری") elseif lock_username == 'Kick' then Kickall(msg,"نام کاربری") end
						end
						if is_filter(msg, msg.text) then
							Delall(msg)
						end
						local arabic_msg = msg.text:match("[\216-\219][\128-\191]")
						if arabic_msg then
							if lock_arabic == 'Enable' then Delall(msg) elseif lock_arabic == 'Warn' then Warnall(msg,"فارسی") elseif lock_arabic == 'Mute' then Silentall(msg,"فارسی") elseif lock_arabic == 'Kick' then Kickall(msg,"فارسی") end
						end
						local english_msg = msg.text:match("[A-Z]") or msg.text:match("[a-z]")
						if english_msg then
							if lock_english == 'Enable' then Delall(msg) elseif lock_english == 'Warn' then Warnall(msg,"انگلیسی") elseif lock_english == 'Mute' then Silentall(msg,"انگلیسی") elseif lock_english == 'Kick' then Kickall(msg,"انگلیسی") end
						end
						if msg.text:match("(.*)") then
							if mute_text == 'Enable'  then Delall(msg) elseif mute_text == 'Warn' then Warnall(msg,"متن") elseif mute_text == 'Mute' then Silentall(msg,"متن") elseif mute_text == 'Kick' then Kickall(msg,"متن") end
						end
					end

					if mute_all == 'Enable' then
						Delall(msg)
					end
					if msg.content and msg.content.entities then
						for k,entity in pairs(msg.content.entities) do
							if entity.type._ == "textEntityTypeMentionName" then
								if lock_mention == 'Enable' then Delall(msg) elseif lock_mention == 'Warn' then Warnall(msg,"منشن") elseif lock_mention == 'Mute' then Silentall(msg,"منشن") elseif lock_mention == 'Kick' then Kickall(msg,"منشن") end
							end
							if entity.type._ == "textEntityTypeUrl" or entity.type._ == "textEntityTypeTextUrl" then
								if lock_webpage == 'Enable' then Delall(msg) elseif lock_webpage == 'Warn' then Warnall(msg,"سایت") elseif lock_webpage == 'Mute' then Silentall(msg,"سایت") elseif lock_webpage == 'Kick' then Kickall(msg,"سایت") end
							end
							if msg.content and entity.type._ == "textEntityTypeBold" or entity.type._ == "textEntityTypeCode" or entity.type._ == "textEntityTypePre" or entity.type._ == "textEntityTypeItalic" then
								if lock_markdown == 'Enable' then Delall(msg) elseif lock_markdown == 'Warn' then Warnall(msg,"فونت") elseif lock_markdown == 'Mute' then Silentall(msg,"فونت") elseif lock_markdown == 'Kick' then Kickall(msg,"فونت") end
							end
						end
					end
					if msg.to.type ~= 'pv' then
						if lock_flood == 'Enable' and not is_mod(msg) and not is_whitelist(msg.from.id, msg.to.id) and not msg.adduser and msg.from.id ~= our_id then
							TIME_CHECK = redis:get(Alpha..msg.to.id..'time_check') or 2
							local hash = 'user:'..user..':msgs'
							local msgs = tonumber(redis:get(Alpha..hash) or 0)
							local NUM_MSG_MAX = tonumber(redis:get(Alpha..msg.to.id..'num_msg_max') or 5)
							if msgs > NUM_MSG_MAX then
								if msg.from.username then
									user_name = "@"..msg.from.username
								else
									user_name = msg.from.first_name
								end
								if redis:get(Alpha..'sender:'..user..':flood') then
									return
								else
									local floodmod = redis:get(Alpha..msg.to.id..'floodmod')
									if floodmod == "Mute" then
										del_msg(chat, msg.id)
										tdbot.deleteMessagesFromUser(msg.to.id,  user)
										silent_user(chat, user)
										tdbot.sendMessage(chat, msg.id, 0, Source_Start.."*کاربر* `"..user.."` - "..user_name.." *به دلیل ارسال پیام های مکرر سکوت شد*", 0, "md")
										redis:setex(Alpha..'sender:'..user..':flood', 30, true)
									else
										kick_user(user, chat)
										tdbot.deleteMessagesFromUser(msg.to.id,  user)
										tdbot.sendMessage(chat, msg.id, 0, Source_Start.."*کاربر* `"..user.."` - "..user_name.." *به دلیل ارسال پیام های مکرر اخراج شد*", 0, "md")
										redis:setex(Alpha..'sender:'..user..':flood', 30, true)
									end
								end
							end
							redis:setex(Alpha..hash, TIME_CHECK, msgs+1)
						end
					end
				end
			end
			if msg.text then
				if msg.text:match("(.*)") then
					
					if redis:get(Alpha.."delbot"..msg.to.id) and not redis:get(Alpha.."deltimebot2"..msg.to.id) and not is_mod(msg) then
						local time = redis:get(Alpha.."deltimebot"..msg.chat_id) or 60
						redis:setex(Alpha.."deltimebot2"..msg.to.id, time, true)
						tdbot.deleteMessagesFromUser(msg.to.id,  Bot_id)
					end
					if not redis:get(Alpha.."Autostartapi") and redis:get(Alpha.."BoTMode") == "CliMode" then
						redis:setex(Alpha.."Autostartapi", 120, true)
						function AutoStart(arg,data)
							if data.id then
								StartBot(data.id, data.id, "new")
							else
							end
						end
						tdbot_function ({
						_ = "searchPublicChat",
						username = UsernameApi
						}, AutoStart, nil)
					else
						return
					end
				end
			end
		end
		function msg_valid(msg)
			if msg.date and msg.date < os.time() - 60 then
				print('\27[36mOld Message\27[39m')
				return false
			end
			if is_banned((msg.sender_user_id or 0), msg.chat_id) then
				del_msg(msg.chat_id, tonumber(msg.id))
				kick_user((msg.sender_user_id or 0), msg.chat_id)
				return false
			end
			if is_gbanned((msg.sender_user_id or 0)) then
				del_msg(msg.chat_id, tonumber(msg.id))
				kick_user((msg.sender_user_id or 0), msg.chat_id)
				return false
			end
			return true
		end
		function file_cb(msg)
			if msg.content._ == "messagePhoto" then
				photo_id = ''
				local function get_cb(arg, data)
					if data.content then
						if data.content.photo.sizes[2] then
							photo_id = data.content.photo.sizes[2].photo.id
						else
							photo_id = data.content.photo.sizes[1].photo.id
						end
						tdbot.downloadFile(photo_id, 32, dl_cb, nil)
					end
				end
				assert (tdbot_function ({ _ = "getMessage", chat_id = msg.chat_id, message_id = msg.id }, get_cb, nil))
			elseif msg.content._ == "messageVideo" then
				video_id = ''
				local function get_cb(arg, data)
					if data.content then
						video_id = data.content.video.video.id
						tdbot.downloadFile(video_id, 32, dl_cb, nil)
					end
				end
				assert (tdbot_function ({ _ = "getMessage", chat_id = msg.chat_id, message_id = msg.id }, get_cb, nil))
			elseif msg.content._ == "messageAnimation" then
				anim_id, anim_name = '', ''
				local function get_cb(arg, data)
					if data.content then
						anim_id = data.content.animation.animation.id
						anim_name = data.content.animation.file_name
						tdbot.downloadFile(anim_id, 32, dl_cb, nil)
					end
				end
				assert (tdbot_function ({ _ = "getMessage", chat_id = msg.chat_id, message_id = msg.id }, get_cb, nil))
			elseif msg.content._ == "messageVoice" then
				voice_id = ''
				local function get_cb(arg, data)
					if data.content then
						voice_id = data.content.voice.voice.id
						tdbot.downloadFile(voice_id, 32, dl_cb, nil)
					end
				end
				assert (tdbot_function ({ _ = "getMessage", chat_id = msg.chat_id, message_id = msg.id }, get_cb, nil))
			elseif msg.content._ == "messageAudio" then
				audio_id, audio_name, audio_title = '', '', ''
				local function get_cb(arg, data)
					if data.content then
						audio_id = data.content.audio.audio.id
						audio_name = data.content.audio.file_name
						audio_title = data.content.audio.title
						tdbot.downloadFile(audio_id, 32, dl_cb, nil)
					end
				end
				assert (tdbot_function ({ _ = "getMessage", chat_id = msg.chat_id, message_id = msg.id }, get_cb, nil))
			elseif msg.content._ == "messageSticker" then
				sticker_id = ''
				local function get_cb(arg, data)
					if data.content then
						sticker_id = data.content.sticker.sticker.id
						tdbot.downloadFile(sticker_id, 32, dl_cb, nil)
					end
				end
				assert (tdbot_function ({ _ = "getMessage", chat_id = msg.chat_id, message_id = msg.id }, get_cb, nil))
			elseif msg.content._ == "messageDocument" then
				document_id, document_name = '', ''
				local function get_cb(arg, data)
					if data.content then
						document_id = data.content.document.document.id
						document_name = data.content.document.file_name
						tdbot.downloadFile(document_id, 32, dl_cb, nil)
					end
				end
				assert (tdbot_function ({ _ = "getMessage", chat_id = msg.chat_id, message_id = msg.id }, get_cb, nil))
			end
		end
		function tdbot_update_callback (data)
			if (data._ == "updateNewMessage") then
				local msg = data.message
				local d = data.disable_notification
				local chat = chats[msg.chat_id]
				local hash = 'msgs:'..(msg.sender_user_id or 0)..':'..msg.chat_id
				local gaps = 'msgs:'..(msg.chat_id or 0)
				redis:incr(Alpha..hash)
				redis:incr(Alpha..gaps)
				if not redis:get(Alpha.."Open:Chats"..msg.chat_id ) then
					openChat(msg.chat_id)
					redis:setex(Alpha.."Open:Chats"..msg.chat_id , 8, true)
				end
				
				if redis:get(Alpha..'markread') == 'on' then
					tdbot.viewMessages(msg.chat_id, {[0] = msg.id}, dl_cb, nil)
				end
				if ((not d) and chat) then
					if msg.content._ == "messageText" then
						do_notify (chat.title, msg.content.text)
					else
						do_notify (chat.title, msg.content._)
					end
				end
				if msg_valid(msg) then
					local AutoDownload = redis:get(Alpha..'AutoDownload:'..msg.chat_id)
					var_cb(msg, msg)
					if AutoDownload then
						file_cb(msg)
					end
					if msg.forward_info then
						if msg.forward_info._ == "messageForwardedFromUser" then
							msg.fwd_from_user = true
							
						elseif msg.forward_info._ == "messageForwardedPost" then
							msg.fwd_from_channel = true
						end
					end
					--[[if msg.sender_user_id  and redis:get(Alpha.. 'MuteAll:'..msg.chat_id) and not is_mod(msg) then
                     
                       
                         tdbot.deleteMessages(msg.chat_id, {[0] = msg.id})
                           end
                            if msg.sender_user_id  and not redis:get(Alpha.. 'MuteAll:'..msg.chat_id) then

                              redis:del(Alpha.. 'MuteAll:'..msg.chat_id)
                             
                                          
                                 end--]]
								 
						
					if msg.content._ == "messageText" then
						msg.text = msg.content.text
						msg.edited = false
						msg.pinned = false
					elseif msg.content._ == "messagePinMessage" then
						msg.pinned = true
					elseif msg.content._ == "messagePhoto" then
						msg.photo = true
					elseif msg.content._ == "messageVideo" then
						msg.video = true
						
					elseif msg.content._ == "messageVideoNote" then
						msg.video_note = true
						
					elseif msg.content._ == "messageAnimation" then
						msg.animation = true
						
					elseif msg.content._ == "messageVoice" then
						msg.voice = true
						
					elseif msg.content._ == "messageAudio" then
						msg.audio = true
						
					elseif msg.content._ == "messageSticker" then
						msg.sticker = true
						
					elseif msg.content._ == "messageContact" then
						msg.contact = true
						
					elseif msg.content._ == "messageDocument" then
						msg.document = true
						
					elseif msg.content._ == "messageLocation" then
						msg.location = true
					elseif msg.content._ == "messageGame" then
						msg.game = true
					elseif msg.content._ == "messageChatAddMembers" then
						for i=0,#msg.content.member_user_ids do
							msg.adduser = msg.content.member_user_ids[i]
						end
					elseif msg.content._ == "messageChatJoinByLink" then
						msg.joinuser = msg.sender_user_id
					elseif msg.content._ == "messageChatDeleteMember" then
						msg.deluser = true
						
					end
				end
			elseif data._ == "updateMessageEdited" then
				local function edited_cb(arg, data)
					msg = data
					msg.media = {}
					msg.text = msg.content.text
					msg.media.caption = msg.content.caption
					msg.edited = true
					if msg_valid(msg) then
						var_cb(msg, msg)
					end
				end
				assert (tdbot_function ({ _ = "getMessage", chat_id = data.chat_id, message_id = data.message_id }, edited_cb, nil))
				assert (tdbot_function ({_ = "openChat", chat_id = data.chat_id}, dl_cb, nil))
			elseif (data._ == "updateChat") then
				assert (tdbot_function ({_ = "openChat", chat_id = data.chat_id}, dl_cb, nil))
			elseif (data._ == "updateOption" and data.name == "my_id") then
				assert (tdbot_function ({_ = "openChat", chat_id = data.chat_id}, dl_cb, nil))
				assert (tdbot_function ({_ = 'openMessageContent', chat_id = data.chat_id, message_id = data.message_id}, dl_cb, nil))
				assert (tdbot_function ({_ = "getChats", offset_order="9223372036854775807", offset_chat_id=0, limit=20}, dl_cb, nil))
			end
		end
