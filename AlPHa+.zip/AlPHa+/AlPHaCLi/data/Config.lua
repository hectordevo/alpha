do local _ = {
  Alpha = "10",
  BotName = "Roobot",
  Bot_id = 818785209,
  Bot_idapi = 884488219,
  SUDO = 664556468,
  UsernameApi = "Toomplus888bot",
  UsernameCli = "roboot12",
  admins = {
    {
      664556468,
      "@Toompluss"
    }
  },
  bot_token = "884488219:AAEFb2uPRGgxpwuVZ0xypPXZpe9pZRfKaKs",
  channel_inline = "Toompluscch",
  channel_username = "Toompluscch",
  gp_sudo = 664556468,
  link_poshtibani = "https://t.me/joinchat/KzZ4S1X8_EsUw9comLkEow",
  linkpardakht = "https://t.me/toompluscch",
  sudo_username = "@Toompluss",
  sudo_users = {
    884488219,
    818785209
  },
  sudoinline_username = "toomplus",
  userpasswd = "toomplus"
}
return _
end