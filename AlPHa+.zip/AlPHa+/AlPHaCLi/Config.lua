--#    ___     __             __            ______    ____     ____           __ 
--#   /   |   / /    ____    / /_   ____ _ /_  __/   / __ \   / __ )  ____   / /_
--#  / /| |  / /    / __ \  / __ \ / __ `/  / /     / / / /  / __  | / __ \ / __/
--# / ___ | / /    / /_/ / / / / // /_/ /  / /     / /_/ /  / /_/ / / /_/ // /_  
--#/_/  |_|/_/    / .___/ /_/ /_/ \__,_/  /_/     /_____/  /_____/  \____/ \__/  
--#              /_/                                                             


do local _ = {
  BotName = "Nulli Plus", ---نام ربات
  Bot_id = 923815659,--- ایدی سودو
  Bot_idapi = 884488219,----idcli
  Alpha = "10", ----NumberDataBase
  SUDO = 923815659,--- ایدی سودو
  UsernameApi = "NulliPlusBot",-----userpanelapi
  UsernameCli = "NulliPlus", --usercli
  admins = {
    {
      923815659,
      "@NulliPlus"
    }
  },
  bot_token = "985273212:AAEef2oIAFt6YAd3hSxFbvJhhTZ4E8OuCc4", ---Token
  channel_inline = "NullHack",---linkchannel
  channel_username = "NullHack",---linkchannel
  gp_sudo = 923815659,--- ایدی سودو
  link_poshtibani = "https://t.me/joinchat/NxBO6xYr3S_489HBjm5NVA", --linksupport
  linkpardakht = "https://idpay.ir/PouriaZec", ---idpay
  sudo_username = "@Toompluss",--یوزرنیم سودو
  sudo_users = {
    923815659,923815659,765751442   -----[idsuod-idapi-idcli]
  }, 
  sudoinline_username = "isPython",--یوزرنیم سودو 
  userpasswd = "1313"
  
}
return _ 
end